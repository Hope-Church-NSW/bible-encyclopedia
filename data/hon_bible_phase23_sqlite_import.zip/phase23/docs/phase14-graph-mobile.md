# Phase 14 — Research Graph Visualization + Mobile Study Experience

Adds a visualization-ready graph layout layer and a mobile-first study state.

Graph:
- neighborhood retrieval
- renderable node positions
- UI-independent layout service
- offline-compatible relationship visualization

Mobile study:
- active section
- compact mode
- evidence panel state
- graph panel state

Core research flow:

Verse → Study → Encyclopedia → Original Word →
Cross Reference / Prophecy → Evidence → Source → Graph
