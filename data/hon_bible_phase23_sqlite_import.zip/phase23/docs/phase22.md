# Phase 22 — Production Persistence + Source/Evidence Repositories + Offline Cache

Adds a storage-independent persistence boundary, deterministic test database,
source and evidence repositories, and a local research-cache repository.

Flow:
Bible → Verse → Study → Encyclopedia → Evidence → Source
                         ↓
                    Local Cache

The abstraction is ready for a SQLite/Drift adapter in Phase 23.
