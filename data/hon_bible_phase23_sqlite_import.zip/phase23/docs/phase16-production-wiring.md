# Phase 16 — Production Repository Wiring + Flutter Research Screen

Production flow:

Bible verse → Knowledge Graph → Study → Encyclopedia → Original Language
→ Cross References → Sources → Flutter Research Screen

The production data source resolves relationships from the persisted graph.
The first Flutter screen provides navigation across the complete research
vertical slice and is ready for richer evidence, citations, RTL, and
localization layers.
