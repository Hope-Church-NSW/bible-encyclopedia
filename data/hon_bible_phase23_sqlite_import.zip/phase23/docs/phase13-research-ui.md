# Phase 13 — Graph-backed Research UI + Evidence-aware Navigation

UI-facing contracts now expose workspace trails, selected nodes/sources, relationship expansion and evidence-aware navigation. Routes can deep-link to research nodes while authoritative content remains in existing repositories.
