# Phase 18 — Production Evidence Panel + Citation Navigation + Study Rendering

Evidence → ranked citations → evidence panel state → selected citation → source navigation.

Study rendering carries identity, title, body, language, and citation IDs.
Citation navigation creates deterministic source deep-links.

The layer remains presentation-independent and is ready for the Flutter source detail screen and offline cache.
