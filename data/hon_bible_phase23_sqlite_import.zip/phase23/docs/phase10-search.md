# Phase 10 — Unified Search Engine + Ranking

Unified offline-first search across Bible verses, encyclopedia, people,
places, events, doctrines, original-language words, studies, sources and
cross references.

SQLite FTS5 provides local full-text indexing. Ranking begins with FTS5 BM25
and is structured for future boosts by exact title, reference, language,
document type, evidence confidence and review status.

The API is UI-independent and supports both Arabic RTL and English clients.
