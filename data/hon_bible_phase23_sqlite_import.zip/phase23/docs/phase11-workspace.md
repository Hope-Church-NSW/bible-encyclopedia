# Phase 11 — Research Workspace + Vertical Slice

A persistent research workspace can now begin at a Bible verse and grow into:

Bible → Verse → Study → Encyclopedia → Original Word →
Cross Reference / Prophecy → Source

The workspace stores typed nodes and references authoritative entities rather
than duplicating their content.

VerticalSliceService provides the first orchestration layer for starting a
workspace from a verse and attaching downstream research nodes.
