# Phase 17 — Evidence/Citation + Arabic RTL/English Localization

Adds authoritative citation records, deterministic citation ranking, and bilingual research vocabulary. Arabic is explicitly RTL; English is LTR.

Research labels: Verse/الآية, Study/الدراسة, Encyclopedia/الموسوعة, Original Language/اللغة الأصلية, Cross References/مراجع متقاطعة, Sources/المصادر, Evidence/الأدلة.
