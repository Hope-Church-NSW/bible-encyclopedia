import 'package:test/test.dart';
import '../../../lib/features/research_slice/ui/citation_navigation.dart';

void main() {
  test('citation navigation builds source route', () {
    const n = CitationNavigation(citationId: 'c1', sourceId: 'source-1');
    expect(n.route, '/source/source-1/citation/c1');
  });
}
