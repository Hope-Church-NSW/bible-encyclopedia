import 'package:test/test.dart';
import '../../../lib/features/evidence/models/evidence_citation.dart';
import '../../../lib/features/evidence/services/citation_service.dart';
import '../../../lib/features/evidence/services/evidence_panel_service.dart';

void main() {
  test('primary citations are prepared first', () {
    final service = EvidencePanelService(citations: CitationService());
    final result = service.prepare([
      const EvidenceCitation(id: 'secondary', sourceId: 's2', title: 'Secondary'),
      const EvidenceCitation(id: 'primary', sourceId: 's1', title: 'Primary', primary: true),
    ]);
    expect(result.first.id, 'primary');
  });

  test('citation selection is preserved', () {
    final service = EvidencePanelService(citations: CitationService());
    final state = service.open('verse', 'john-3-16');
    expect(service.selectCitation(state, 'primary').selectedCitationId, 'primary');
  });
}
