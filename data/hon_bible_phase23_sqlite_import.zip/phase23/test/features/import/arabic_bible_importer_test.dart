import 'package:test/test.dart';
import 'package:hon_bible/features/import/services/arabic_bible_importer.dart';

void main() {
  test('parses numbered Arabic verses in order', () {
    final importer = ArabicBibleImporter();
    final verses = importer.parseChapter(
      bookId: 'gen',
      chapterNumber: 1,
      text: '1 فِي الْبَدْءِ خَلَقَ اللهُ السَّمَاوَاتِ وَالأَرْضَ. '
          '2 وَكَانَتِ الأَرْضُ خَرِبَةً وَخَالِيَةً.',
    );

    expect(verses.map((v) => v.verseNumber), [1, 2]);
    expect(verses.first.text, contains('فِي الْبَدْءِ'));
    expect(verses.first.id, 'vd:gen:1:1');
  });
}
