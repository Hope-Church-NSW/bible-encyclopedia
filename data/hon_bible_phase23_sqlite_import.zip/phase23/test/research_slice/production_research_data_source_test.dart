import 'package:test/test.dart';

void main() {
  test('production wiring contract exists', () {
    expect(true, isTrue);
  });
}
