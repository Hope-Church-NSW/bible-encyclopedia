import 'package:test/test.dart';
import '../../lib/features/research_slice/services/end_to_end_research_service.dart';

class FakeDataSource implements ResearchSliceDataSource {
  Future<String> verseTitle(String id) async => 'John 3:16';
  Future<List<String>> studiesForVerse(String id) async => ['study-1'];
  Future<List<String>> encyclopediaForVerse(String id) async => ['encyclopedia-1'];
  Future<List<String>> originalWordsForVerse(String id) async => ['word-1'];
  Future<List<String>> crossReferencesForVerse(String id) async => ['cross-1'];
  Future<List<String>> sourcesForVerse(String id) async => ['source-1'];
}

void main() {
  test('loads complete Bible research vertical slice', () async {
    final result = await EndToEndResearchService(dataSource: FakeDataSource()).load('john-3-16');
    expect(result.verseTitle, 'John 3:16');
    expect(result.studyIds, ['study-1']);
    expect(result.encyclopediaIds, ['encyclopedia-1']);
    expect(result.originalWordIds, ['word-1']);
    expect(result.crossReferenceIds, ['cross-1']);
    expect(result.sourceIds, ['source-1']);
  });
}
