import 'package:test/test.dart';
import '../../../lib/core/localization/app_locale.dart';
import '../../../lib/core/localization/research_strings.dart';

void main() {
  test('Arabic labels and RTL are available', () {
    expect(ResearchStrings.get(AppLocale.arabic, 'verse'), 'الآية');
    expect(ResearchStrings.get(AppLocale.arabic, 'sources'), 'المصادر');
    expect(AppLocale.arabic.rtl, isTrue);
  });
  test('English labels are available', () {
    expect(ResearchStrings.get(AppLocale.english, 'verse'), 'Verse');
    expect(ResearchStrings.get(AppLocale.english, 'sources'), 'Sources');
    expect(AppLocale.english.rtl, isFalse);
  });
}
