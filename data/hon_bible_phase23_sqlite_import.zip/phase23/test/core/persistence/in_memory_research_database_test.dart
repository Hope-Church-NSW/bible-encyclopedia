import 'package:test/test.dart';
import '../../../lib/core/persistence/in_memory_research_database.dart';

void main() {
  test('persists and retrieves records', () async {
    final db = InMemoryResearchDatabase();
    await db.put('sources', 's1', {'id': 's1', 'title': 'Source One'});
    final row = await db.get('sources', 's1');
    expect(row?['title'], 'Source One');
  });

  test('filters records', () async {
    final db = InMemoryResearchDatabase();
    await db.put('cache', 'a', {'kind': 'study'});
    await db.put('cache', 'b', {'kind': 'source'});
    expect((await db.where('cache', 'kind', 'study')).length, 1);
  });
}
