import 'package:test/test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:hon_bible/core/persistence/sqlite_research_database.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  test('persists records and supports field filtering', () async {
    final db = SQLiteResearchDatabase(databasePath: inMemoryDatabasePath);
    await db.put('source', 's1', {'id': 's1', 'language': 'ar'});
    await db.put('source', 's2', {'id': 's2', 'language': 'en'});

    expect((await db.get('source', 's1'))?['language'], 'ar');
    expect(await db.where('source', 'language', 'ar'), [
      {'id': 's1', 'language': 'ar'},
    ]);

    await db.delete('source', 's1');
    expect(await db.get('source', 's1'), isNull);
    await db.close();
  });
}
