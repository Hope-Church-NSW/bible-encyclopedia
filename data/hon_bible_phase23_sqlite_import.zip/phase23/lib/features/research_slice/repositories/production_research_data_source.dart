import '../../knowledge_graph/services/knowledge_graph_service.dart';
import '../services/end_to_end_research_service.dart';

class ProductionResearchDataSource implements ResearchSliceDataSource {
  final KnowledgeGraphService graph;
  ProductionResearchDataSource({required this.graph});

  @override
  Future<String> verseTitle(String verseId) async => verseId;

  @override
  Future<List<String>> studiesForVerse(String verseId) =>
      _ids('study', verseId);

  @override
  Future<List<String>> encyclopediaForVerse(String verseId) =>
      _ids('encyclopedia', verseId);

  @override
  Future<List<String>> originalWordsForVerse(String verseId) =>
      _ids('original_word', verseId);

  @override
  Future<List<String>> crossReferencesForVerse(String verseId) =>
      _ids('cross_reference', verseId);

  @override
  Future<List<String>> sourcesForVerse(String verseId) =>
      _ids('source', verseId);

  Future<List<String>> _ids(String type, String verseId) async {
    final edges = await graph.related('verse', verseId);
    return edges.where((e) => e.toType == type).map((e) => e.toId).toList();
  }
}
