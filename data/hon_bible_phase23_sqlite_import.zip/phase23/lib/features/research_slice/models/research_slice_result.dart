class ResearchSliceResult {
  final String verseId;
  final String verseTitle;
  final List<String> studyIds;
  final List<String> encyclopediaIds;
  final List<String> originalWordIds;
  final List<String> crossReferenceIds;
  final List<String> sourceIds;

  const ResearchSliceResult({
    required this.verseId,
    required this.verseTitle,
    this.studyIds = const [],
    this.encyclopediaIds = const [],
    this.originalWordIds = const [],
    this.crossReferenceIds = const [],
    this.sourceIds = const [],
  });
}
