import '../models/research_slice_result.dart';

abstract class ResearchSliceDataSource {
  Future<String> verseTitle(String verseId);
  Future<List<String>> studiesForVerse(String verseId);
  Future<List<String>> encyclopediaForVerse(String verseId);
  Future<List<String>> originalWordsForVerse(String verseId);
  Future<List<String>> crossReferencesForVerse(String verseId);
  Future<List<String>> sourcesForVerse(String verseId);
}

class EndToEndResearchService {
  final ResearchSliceDataSource dataSource;
  EndToEndResearchService({required this.dataSource});

  Future<ResearchSliceResult> load(String verseId) async => ResearchSliceResult(
    verseId: verseId,
    verseTitle: await dataSource.verseTitle(verseId),
    studyIds: await dataSource.studiesForVerse(verseId),
    encyclopediaIds: await dataSource.encyclopediaForVerse(verseId),
    originalWordIds: await dataSource.originalWordsForVerse(verseId),
    crossReferenceIds: await dataSource.crossReferencesForVerse(verseId),
    sourceIds: await dataSource.sourcesForVerse(verseId),
  );
}
