class CitationNavigation {
  final String citationId;
  final String sourceId;
  const CitationNavigation({required this.citationId, required this.sourceId});
  String get route => '/source/$sourceId/citation/$citationId';
}
