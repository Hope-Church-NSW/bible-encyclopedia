import 'package:flutter/material.dart';
import '../models/research_slice_result.dart';
import 'research_screen_state.dart';

class ResearchScreen extends StatelessWidget {
  final ResearchSliceResult result;
  final ResearchScreenSection initialSection;

  const ResearchScreen({
    super.key,
    required this.result,
    this.initialSection = ResearchScreenSection.verse,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: ResearchScreenSection.values.length,
      initialIndex: initialSection.index,
      child: Scaffold(
        appBar: AppBar(
          title: Text(result.verseTitle),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Verse'),
              Tab(text: 'Study'),
              Tab(text: 'Encyclopedia'),
              Tab(text: 'Original'),
              Tab(text: 'Cross References'),
              Tab(text: 'Sources'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _IdsPanel(ids: [result.verseId]),
            _IdsPanel(ids: result.studyIds),
            _IdsPanel(ids: result.encyclopediaIds),
            _IdsPanel(ids: result.originalWordIds),
            _IdsPanel(ids: result.crossReferenceIds),
            _IdsPanel(ids: result.sourceIds),
          ],
        ),
      ),
    );
  }
}

class _IdsPanel extends StatelessWidget {
  final List<String> ids;
  const _IdsPanel({required this.ids});

  @override
  Widget build(BuildContext context) {
    if (ids.isEmpty) return const Center(child: Text('No linked records'));

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: ids.length,
      separatorBuilder: (_, __) => const Divider(),
      itemBuilder: (_, index) => ListTile(
        title: Text(ids[index]),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
