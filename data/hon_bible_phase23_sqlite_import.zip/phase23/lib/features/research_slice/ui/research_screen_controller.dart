import '../models/research_slice_result.dart';
import '../services/end_to_end_research_service.dart';
import 'research_screen_state.dart';

class ResearchScreenController {
  final EndToEndResearchService service;
  ResearchScreenController({required this.service});

  Future<ResearchSliceResult> load(String verseId) => service.load(verseId);

  ResearchScreenState select(
    ResearchScreenState state,
    ResearchScreenSection section,
  ) => state.copyWith(section: section);
}
