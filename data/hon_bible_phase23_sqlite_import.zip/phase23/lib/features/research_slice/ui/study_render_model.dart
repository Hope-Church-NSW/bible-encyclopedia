class StudyRenderModel {
  final String id;
  final String title;
  final String body;
  final String language;
  final List<String> citationIds;

  const StudyRenderModel({required this.id, required this.title, required this.body, this.language = 'en', this.citationIds = const []});
}
