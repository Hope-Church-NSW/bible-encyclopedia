enum ResearchScreenSection { verse, study, encyclopedia, originalLanguage, crossReferences, sources }

class ResearchScreenState {
  final String verseId;
  final ResearchScreenSection section;
  final bool loading;
  final String? error;

  const ResearchScreenState({
    required this.verseId,
    this.section = ResearchScreenSection.verse,
    this.loading = false,
    this.error,
  });

  ResearchScreenState copyWith({
    ResearchScreenSection? section,
    bool? loading,
    String? error,
  }) => ResearchScreenState(
    verseId: verseId,
    section: section ?? this.section,
    loading: loading ?? this.loading,
    error: error,
  );
}
