import '../../../core/localization/app_locale.dart';
import '../../../core/localization/research_strings.dart';

class LocalizedResearchLabels {
  final AppLocale locale;
  const LocalizedResearchLabels(this.locale);
  String get verse => ResearchStrings.get(locale, 'verse');
  String get study => ResearchStrings.get(locale, 'study');
  String get encyclopedia => ResearchStrings.get(locale, 'encyclopedia');
  String get original => ResearchStrings.get(locale, 'original');
  String get crossReferences => ResearchStrings.get(locale, 'crossReferences');
  String get sources => ResearchStrings.get(locale, 'sources');
  String get evidence => ResearchStrings.get(locale, 'evidence');
}
