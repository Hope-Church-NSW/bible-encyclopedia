import '../../../core/persistence/research_database.dart';

class ResearchCacheRepository {
  final ResearchDatabase database;
  ResearchCacheRepository({required this.database});

  Future<void> putJson(String key, String value) =>
      database.put('cache', key, {'key': key, 'value': value});

  Future<String?> getJson(String key) async =>
      (await database.get('cache', key))?['value'] as String?;

  Future<void> remove(String key) => database.delete('cache', key);
}
