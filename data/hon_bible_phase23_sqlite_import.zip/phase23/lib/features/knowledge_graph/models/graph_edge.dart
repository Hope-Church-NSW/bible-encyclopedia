enum GraphRelation { references, explains, supports, challenges, fulfills, parallels, mentions, locatedAt, occurredAt, authoredBy, derivedFrom, cites, contains, relatedTo }

class GraphEdge {
  final String id, fromType, fromId, toType, toId;
  final GraphRelation relation;
  final double weight;
  final String? note;
  const GraphEdge({required this.id, required this.fromType, required this.fromId, required this.toType, required this.toId, required this.relation, this.weight=1.0, this.note});
  Map<String,Object?> toMap()=>{'id':id,'from_type':fromType,'from_id':fromId,'to_type':toType,'to_id':toId,'relation':relation.name,'weight':weight,'note':note};
  factory GraphEdge.fromMap(Map<String,Object?> m)=>GraphEdge(id:m['id'] as String,fromType:m['from_type'] as String,fromId:m['from_id'] as String,toType:m['to_type'] as String,toId:m['to_id'] as String,relation:GraphRelation.values.byName(m['relation'] as String),weight:(m['weight'] as num?)?.toDouble()??1.0,note:m['note'] as String?);
}
