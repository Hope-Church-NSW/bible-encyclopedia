class GraphNode {
  final String type, id, label;
  final Map<String,Object?> metadata;
  const GraphNode({required this.type,required this.id,required this.label,this.metadata=const {}});
}
