import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/graph_edge.dart';
class KnowledgeGraphRepository {
 final AppDatabase database; KnowledgeGraphRepository({required this.database});
 Future<void> ensureSchema() async { final db=await database.database; await db.execute('CREATE TABLE IF NOT EXISTS graph_edges(id TEXT PRIMARY KEY,from_type TEXT NOT NULL,from_id TEXT NOT NULL,to_type TEXT NOT NULL,to_id TEXT NOT NULL,relation TEXT NOT NULL,weight REAL NOT NULL,note TEXT)'); await db.execute('CREATE INDEX IF NOT EXISTS idx_graph_from ON graph_edges(from_type,from_id)'); await db.execute('CREATE INDEX IF NOT EXISTS idx_graph_to ON graph_edges(to_type,to_id)'); await db.execute('CREATE INDEX IF NOT EXISTS idx_graph_relation ON graph_edges(relation)'); }
 Future<void> saveEdge(GraphEdge e) async { final db=await database.database; await db.insert('graph_edges',e.toMap(),conflictAlgorithm:ConflictAlgorithm.replace); }
 Future<List<GraphEdge>> outgoing(String t,String id) async { final db=await database.database; final r=await db.query('graph_edges',where:'from_type=? AND from_id=?',whereArgs:[t,id],orderBy:'weight DESC'); return r.map(GraphEdge.fromMap).toList(); }
 Future<List<GraphEdge>> incoming(String t,String id) async { final db=await database.database; final r=await db.query('graph_edges',where:'to_type=? AND to_id=?',whereArgs:[t,id],orderBy:'weight DESC'); return r.map(GraphEdge.fromMap).toList(); }
 Future<List<GraphEdge>> related(String t,String id,{int limit=100}) async { final db=await database.database; final r=await db.rawQuery('SELECT * FROM graph_edges WHERE (from_type=? AND from_id=?) OR (to_type=? AND to_id=?) ORDER BY weight DESC LIMIT ?',[t,id,t,id,limit.clamp(1,500)]); return r.map(GraphEdge.fromMap).toList(); }
}
