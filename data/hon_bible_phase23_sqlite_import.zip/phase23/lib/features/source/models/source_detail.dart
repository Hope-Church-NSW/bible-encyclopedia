class SourceDetail {
  final String id;
  final String title;
  final String? author;
  final String? publisher;
  final int? year;
  final String? language;
  final String? locator;

  const SourceDetail({
    required this.id,
    required this.title,
    this.author,
    this.publisher,
    this.year,
    this.language,
    this.locator,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'author': author,
        'publisher': publisher,
        'year': year,
        'language': language,
        'locator': locator,
      };
}
