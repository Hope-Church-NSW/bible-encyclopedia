import '../../../core/persistence/research_database.dart';
import '../models/source_detail.dart';

class SourceRepository {
  final ResearchDatabase database;
  SourceRepository({required this.database});

  Future<void> save(SourceDetail source) => database.put('sources', source.id, {
    'id': source.id, 'title': source.title, 'author': source.author,
    'publisher': source.publisher, 'year': source.year,
    'language': source.language, 'locator': source.locator,
  });

  Future<Map<String, Object?>?> find(String id) => database.get('sources', id);
}
