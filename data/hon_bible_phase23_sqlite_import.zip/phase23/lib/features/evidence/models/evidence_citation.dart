class EvidenceCitation {
  final String id;
  final String sourceId;
  final String title;
  final String? author;
  final String? locator;
  final String? quotation;
  final String language;
  final bool primary;

  const EvidenceCitation({
    required this.id,
    required this.sourceId,
    required this.title,
    this.author,
    this.locator,
    this.quotation,
    this.language = 'en',
    this.primary = false,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'source_id': sourceId,
    'title': title,
    'author': author,
    'locator': locator,
    'quotation': quotation,
    'language': language,
    'primary': primary ? 1 : 0,
  };
}
