class EvidencePanelState {
  final String subjectType;
  final String subjectId;
  final bool expanded;
  final String? selectedCitationId;

  const EvidencePanelState({
    required this.subjectType,
    required this.subjectId,
    this.expanded = true,
    this.selectedCitationId,
  });

  EvidencePanelState copyWith({bool? expanded, String? selectedCitationId}) => EvidencePanelState(
    subjectType: subjectType,
    subjectId: subjectId,
    expanded: expanded ?? this.expanded,
    selectedCitationId: selectedCitationId ?? this.selectedCitationId,
  );
}
