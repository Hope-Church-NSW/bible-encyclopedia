import '../../../core/persistence/research_database.dart';
import '../models/evidence_citation.dart';

class EvidenceRepository {
  final ResearchDatabase database;
  EvidenceRepository({required this.database});

  Future<void> save(EvidenceCitation citation) =>
      database.put('citations', citation.id, citation.toMap());

  Future<Map<String, Object?>?> find(String id) =>
      database.get('citations', id);
}
