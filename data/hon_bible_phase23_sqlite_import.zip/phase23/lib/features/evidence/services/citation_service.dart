import '../models/evidence_citation.dart';

class CitationService {
  List<EvidenceCitation> rank(List<EvidenceCitation> citations) {
    final result = [...citations];
    result.sort((a, b) {
      if (a.primary != b.primary) return a.primary ? -1 : 1;
      return a.title.compareTo(b.title);
    });
    return result;
  }
}
