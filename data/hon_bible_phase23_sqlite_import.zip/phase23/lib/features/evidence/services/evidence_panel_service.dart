import '../models/evidence_citation.dart';
import '../models/evidence_panel_state.dart';
import 'citation_service.dart';

class EvidencePanelService {
  final CitationService citations;
  EvidencePanelService({required this.citations});

  List<EvidenceCitation> prepare(List<EvidenceCitation> records) => citations.rank(records);
  EvidencePanelState open(String subjectType, String subjectId) => EvidencePanelState(subjectType: subjectType, subjectId: subjectId);
  EvidencePanelState selectCitation(EvidencePanelState state, String citationId) => state.copyWith(selectedCitationId: citationId);
  EvidencePanelState toggle(EvidencePanelState state) => state.copyWith(expanded: !state.expanded);
}
