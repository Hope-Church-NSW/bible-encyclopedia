import '../models/evidence_citation.dart';

class EvidencePanelViewModel {
  final String subjectId;
  final List<EvidenceCitation> citations;
  final String? selectedCitationId;

  const EvidencePanelViewModel({required this.subjectId, required this.citations, this.selectedCitationId});

  EvidenceCitation? get selected => citations.where((x) => x.id == selectedCitationId).firstOrNull;
}
