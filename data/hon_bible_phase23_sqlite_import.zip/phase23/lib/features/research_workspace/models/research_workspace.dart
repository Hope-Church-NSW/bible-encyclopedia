class ResearchWorkspace {
  final String id;
  final String title;
  final String? description;
  final String? rootVerseId;
  final String status;
  final DateTime updatedAt;

  const ResearchWorkspace({
    required this.id,
    required this.title,
    this.description,
    this.rootVerseId,
    this.status = 'active',
    required this.updatedAt,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'root_verse_id': rootVerseId,
    'status': status,
    'updated_at': updatedAt.toIso8601String(),
  };

  factory ResearchWorkspace.fromMap(Map<String, Object?> map) =>
      ResearchWorkspace(
        id: map['id'] as String,
        title: map['title'] as String,
        description: map['description'] as String?,
        rootVerseId: map['root_verse_id'] as String?,
        status: map['status'] as String? ?? 'active',
        updatedAt: DateTime.parse(map['updated_at'] as String),
      );
}
