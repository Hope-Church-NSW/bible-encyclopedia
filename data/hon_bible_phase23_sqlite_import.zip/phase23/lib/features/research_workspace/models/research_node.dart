enum ResearchNodeType {
  verse, study, encyclopedia, person, place, event,
  originalWord, crossReference, prophecy, source,
}

class ResearchNode {
  final String id;
  final String workspaceId;
  final ResearchNodeType type;
  final String entityId;
  final String title;
  final String? note;
  final int position;

  const ResearchNode({
    required this.id,
    required this.workspaceId,
    required this.type,
    required this.entityId,
    required this.title,
    this.note,
    this.position = 0,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'workspace_id': workspaceId,
    'node_type': type.name,
    'entity_id': entityId,
    'title': title,
    'note': note,
    'position': position,
  };

  factory ResearchNode.fromMap(Map<String, Object?> map) => ResearchNode(
    id: map['id'] as String,
    workspaceId: map['workspace_id'] as String,
    type: ResearchNodeType.values.byName(map['node_type'] as String),
    entityId: map['entity_id'] as String,
    title: map['title'] as String,
    note: map['note'] as String?,
    position: (map['position'] as num?)?.toInt() ?? 0,
  );
}
