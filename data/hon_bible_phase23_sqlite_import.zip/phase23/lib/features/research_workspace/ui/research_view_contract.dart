import '../models/research_node.dart';
import '../models/research_view_state.dart';
class ResearchViewModel { final ResearchViewState state; final List<ResearchNode> trail; final List<ResearchNode> related; const ResearchViewModel({required this.state,required this.trail,this.related=const []}); }
