import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/research_node.dart';
import '../models/research_workspace.dart';

class ResearchWorkspaceRepository {
  final AppDatabase database;
  ResearchWorkspaceRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS research_workspaces(
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        root_verse_id TEXT,
        status TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS research_nodes(
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        node_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        title TEXT NOT NULL,
        note TEXT,
        position INTEGER NOT NULL
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_research_nodes_workspace '
      'ON research_nodes(workspace_id, position)',
    );
  }

  Future<void> saveWorkspace(ResearchWorkspace workspace) async {
    final db = await database.database;
    await db.insert(
      'research_workspaces',
      workspace.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> saveNode(ResearchNode node) async {
    final db = await database.database;
    await db.insert(
      'research_nodes',
      node.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<ResearchWorkspace?> workspace(String id) async {
    final db = await database.database;
    final rows = await db.query(
      'research_workspaces',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : ResearchWorkspace.fromMap(rows.first);
  }

  Future<List<ResearchNode>> nodes(String workspaceId) async {
    final db = await database.database;
    final rows = await db.query(
      'research_nodes',
      where: 'workspace_id = ?',
      whereArgs: [workspaceId],
      orderBy: 'position ASC',
    );
    return rows.map(ResearchNode.fromMap).toList();
  }
}
