import '../../evidence/models/evidence_claim.dart';
import '../../evidence/repositories/evidence_repository.dart';
import '../../knowledge_graph/models/graph_edge.dart';
import '../../knowledge_graph/services/knowledge_graph_service.dart';
class EvidenceNavigationService { final KnowledgeGraphService graph; final EvidenceRepository evidence; EvidenceNavigationService({required this.graph,required this.evidence}); Future<List<GraphEdge>> relationships(String t,String id)=>graph.related(t,id); Future<List<EvidenceClaim>> evidenceFor(String t,String id)=>evidence.forSubject(t,id); Future<List<GraphEdge>> evidencePaths(String t,String id) async { final e=await graph.related(t,id); return e.where((x)=>x.relation==GraphRelation.cites||x.relation==GraphRelation.supports||x.relation==GraphRelation.derivedFrom).toList(); } }
