import '../models/research_node.dart';
import '../models/research_workspace.dart';
import 'research_workspace_service.dart';

class VerticalSliceService {
  final ResearchWorkspaceService workspace;
  VerticalSliceService({required this.workspace});

  Future<ResearchWorkspace> startFromVerse({
    required String workspaceId,
    required String title,
    required String verseId,
  }) async {
    final item = ResearchWorkspace(
      id: workspaceId,
      title: title,
      rootVerseId: verseId,
      updatedAt: DateTime.now(),
    );
    await workspace.create(item);
    await workspace.addNode(ResearchNode(
      id: '$workspaceId:verse:$verseId',
      workspaceId: workspaceId,
      type: ResearchNodeType.verse,
      entityId: verseId,
      title: 'Verse',
      position: 0,
    ));
    return item;
  }

  Future<void> attach({
    required String workspaceId,
    required ResearchNodeType type,
    required String entityId,
    required String title,
    String? note,
    required int position,
  }) => workspace.addNode(ResearchNode(
    id: '$workspaceId:${type.name}:$entityId',
    workspaceId: workspaceId,
    type: type,
    entityId: entityId,
    title: title,
    note: note,
    position: position,
  ));
}
