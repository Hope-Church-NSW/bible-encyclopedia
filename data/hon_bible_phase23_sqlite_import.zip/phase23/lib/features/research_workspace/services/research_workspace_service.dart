import '../models/research_node.dart';
import '../models/research_workspace.dart';
import '../repositories/research_workspace_repository.dart';

class ResearchWorkspaceService {
  final ResearchWorkspaceRepository repository;
  ResearchWorkspaceService({required this.repository});

  Future<void> initialize() => repository.ensureSchema();
  Future<void> create(ResearchWorkspace workspace) =>
      repository.saveWorkspace(workspace);
  Future<void> addNode(ResearchNode node) => repository.saveNode(node);
  Future<ResearchWorkspace?> open(String id) => repository.workspace(id);
  Future<List<ResearchNode>> nodes(String workspaceId) =>
      repository.nodes(workspaceId);
}
