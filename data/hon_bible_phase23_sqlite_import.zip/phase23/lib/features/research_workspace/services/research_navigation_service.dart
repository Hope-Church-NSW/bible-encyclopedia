import '../models/research_node.dart';
import '../models/research_workspace.dart';
import '../repositories/research_workspace_repository.dart';
class ResearchNavigationService { final ResearchWorkspaceRepository repository; ResearchNavigationService({required this.repository}); Future<ResearchWorkspace?> openWorkspace(String id)=>repository.workspace(id); Future<List<ResearchNode>> trail(String id)=>repository.nodes(id); Future<ResearchNode?> findNode(String workspaceId,String entityId) async { for(final n in await repository.nodes(workspaceId)){if(n.entityId==entityId)return n;} return null;} List<ResearchNode> orderedTrail(List<ResearchNode> n)=>[...n]..sort((a,b)=>a.position.compareTo(b.position)); }
