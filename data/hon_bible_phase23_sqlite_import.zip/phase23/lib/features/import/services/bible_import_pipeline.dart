import '../../../core/persistence/research_database.dart';
import '../models/bible_import_record.dart';

class BibleImportPipeline {
  final ResearchDatabase database;

  BibleImportPipeline({required this.database});

  Future<int> importVerses(Iterable<BibleImportRecord> records) async {
    var count = 0;
    for (final record in records) {
      await database.put('bible_verses', record.id, record.toMap());
      count++;
    }
    return count;
  }
}
