import '../models/bible_import_record.dart';

class ArabicBibleImporter {
  final String translationId;

  ArabicBibleImporter({this.translationId = 'vd'});

  List<BibleImportRecord> parseChapter({
    required String bookId,
    required int chapterNumber,
    required String text,
  }) {
    final normalized = text.replaceAll('\r\n', '\n').trim();
    if (normalized.isEmpty) return const [];

    final records = <BibleImportRecord>[];
    final matches = RegExp(
      r'(?:(?<=^)|(?<=[\s\n]))(\d{1,3})[\s.]+(.+?)(?=(?:\s+\d{1,3}[\s.]+)|\s*$)',
      multiLine: true,
      dotAll: true,
    ).allMatches(normalized);

    for (final match in matches) {
      final verseNumber = int.tryParse(match.group(1)!);
      final verseText = _clean(match.group(2)!);
      if (verseNumber == null || verseText.isEmpty) continue;
      records.add(BibleImportRecord(
        id: '$translationId:$bookId:$chapterNumber:$verseNumber',
        bookId: bookId,
        chapterNumber: chapterNumber,
        verseNumber: verseNumber,
        text: verseText,
        translationId: translationId,
      ));
    }
    records.sort((a, b) => a.verseNumber.compareTo(b.verseNumber));
    return records;
  }

  String _clean(String value) => value
      .replaceAll(RegExp(r'\s+'), ' ')
      .replaceAll(RegExp(r'\s+([،؛:؟.!»])'), r'\1')
      .trim();
}
