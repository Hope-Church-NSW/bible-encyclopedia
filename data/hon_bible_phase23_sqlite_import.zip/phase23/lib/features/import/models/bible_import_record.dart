class BibleImportRecord {
  final String id;
  final String bookId;
  final int chapterNumber;
  final int verseNumber;
  final String text;
  final String translationId;

  const BibleImportRecord({
    required this.id,
    required this.bookId,
    required this.chapterNumber,
    required this.verseNumber,
    required this.text,
    required this.translationId,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'book_id': bookId,
        'chapter_number': chapterNumber,
        'verse_number': verseNumber,
        'text': text,
        'translation_id': translationId,
      };
}
