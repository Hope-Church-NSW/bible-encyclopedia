import '../models/mobile_study_state.dart';

class MobileStudyService {
  MobileStudyState open(String workspaceId) => MobileStudyState(workspaceId: workspaceId);
  MobileStudyState selectSection(MobileStudyState state, int section) => state.copyWith(activeSection: section);
  MobileStudyState toggleEvidence(MobileStudyState state) => state.copyWith(evidencePanelOpen: !state.evidencePanelOpen);
  MobileStudyState toggleGraph(MobileStudyState state) => state.copyWith(graphPanelOpen: !state.graphPanelOpen);
}
