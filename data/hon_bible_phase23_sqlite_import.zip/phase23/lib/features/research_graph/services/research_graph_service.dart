import '../../knowledge_graph/models/graph_edge.dart';
import '../../knowledge_graph/services/knowledge_graph_service.dart';
import '../models/graph_layout.dart';
import 'graph_layout_service.dart';

class ResearchGraphService {
  final KnowledgeGraphService graph;
  final GraphLayoutService layout;
  ResearchGraphService({required this.graph, required this.layout});
  Future<GraphLayout> layoutFor(String workspaceId, String nodeType, String nodeId) async {
    final edges = await graph.related(nodeType, nodeId);
    return layout.arrange(workspaceId: workspaceId, edges: edges);
  }
  Future<List<GraphEdge>> neighborhood(String nodeType, String nodeId) => graph.related(nodeType, nodeId);
}
