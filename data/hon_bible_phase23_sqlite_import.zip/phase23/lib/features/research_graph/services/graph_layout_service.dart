import '../../knowledge_graph/models/graph_edge.dart';
import '../models/graph_layout.dart';

class GraphLayoutService {
  GraphLayout arrange({required String workspaceId, required List<GraphEdge> edges}) {
    final ids = <String>{};
    for (final edge in edges) {
      ids.add('${edge.fromType}:${edge.fromId}');
      ids.add('${edge.toType}:${edge.toId}');
    }
    final points = <GraphPoint>[];
    var index = 0;
    for (final id in ids) {
      final slot = index % 8;
      final ring = index ~/ 8;
      points.add(GraphPoint(nodeId: id, x: (slot - 3.5) * 90.0, y: ring * 120.0));
      index++;
    }
    return GraphLayout(workspaceId: workspaceId, points: points);
  }
}
