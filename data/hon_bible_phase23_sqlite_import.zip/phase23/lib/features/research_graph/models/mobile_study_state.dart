class MobileStudyState {
  final String workspaceId;
  final int activeSection;
  final bool compactMode;
  final bool evidencePanelOpen;
  final bool graphPanelOpen;
  const MobileStudyState({required this.workspaceId, this.activeSection = 0, this.compactMode = true, this.evidencePanelOpen = false, this.graphPanelOpen = false});
  MobileStudyState copyWith({int? activeSection, bool? compactMode, bool? evidencePanelOpen, bool? graphPanelOpen}) => MobileStudyState(workspaceId: workspaceId, activeSection: activeSection ?? this.activeSection, compactMode: compactMode ?? this.compactMode, evidencePanelOpen: evidencePanelOpen ?? this.evidencePanelOpen, graphPanelOpen: graphPanelOpen ?? this.graphPanelOpen);
}
