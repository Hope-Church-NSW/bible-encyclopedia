class GraphPoint {
  final String nodeId;
  final double x;
  final double y;
  const GraphPoint({required this.nodeId, required this.x, required this.y});
  Map<String, Object?> toMap() => {'node_id': nodeId, 'x': x, 'y': y};
}

class GraphLayout {
  final String workspaceId;
  final List<GraphPoint> points;
  const GraphLayout({required this.workspaceId, required this.points});
}
