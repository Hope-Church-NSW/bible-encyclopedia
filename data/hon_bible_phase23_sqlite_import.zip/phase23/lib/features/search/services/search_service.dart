import '../models/search_query.dart';
import '../models/search_result.dart';
import '../repositories/search_repository.dart';

class SearchService {
  final SearchRepository repository;
  SearchService({required this.repository});

  Future<void> initialize() => repository.ensureSchema();

  Future<void> index({
    required String id, required String type, required String title,
    required String body, String? language, String? referenceId,
    String status = 'published',
  }) => repository.indexDocument(
    id: id, documentType: type, title: title, body: body,
    language: language, referenceId: referenceId, status: status,
  );

  Future<List<SearchResult>> search(SearchQuery query) {
    final q = query.normalized();
    return repository.search(q.text, types: q.types, limit: q.limit);
  }
}
