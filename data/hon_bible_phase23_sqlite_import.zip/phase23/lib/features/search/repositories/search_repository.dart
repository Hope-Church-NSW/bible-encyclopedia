import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/search_result.dart';

class SearchRepository {
  final AppDatabase database;
  SearchRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS search_documents(
        id TEXT PRIMARY KEY, document_type TEXT NOT NULL,
        title TEXT NOT NULL, body TEXT NOT NULL,
        normalized_title TEXT NOT NULL, normalized_body TEXT NOT NULL,
        language TEXT, reference_id TEXT, status TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE VIRTUAL TABLE IF NOT EXISTS search_documents_fts
      USING fts5(id UNINDEXED, title, body,
        tokenize='unicode61 remove_diacritics 2')
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_search_type ON search_documents(document_type)');
  }

  Future<void> indexDocument({
    required String id, required String documentType,
    required String title, required String body,
    String? language, String? referenceId, String status = 'published',
  }) async {
    final db = await database.database;
    await db.insert('search_documents', {
      'id': id, 'document_type': documentType, 'title': title, 'body': body,
      'normalized_title': title.toLowerCase(), 'normalized_body': body.toLowerCase(),
      'language': language, 'reference_id': referenceId, 'status': status,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    await db.delete('search_documents_fts', where: 'id = ?', whereArgs: [id]);
    await db.insert('search_documents_fts', {'id': id, 'title': title, 'body': body});
  }

  Future<List<SearchResult>> search(String query, {Set<String> types = const {}, int limit = 30}) async {
    final db = await database.database;
    if (query.trim().isEmpty) return [];
    final q = query.trim().replaceAll(RegExp(r'["*]'), ' ').split(RegExp(r'\s+'))
      .where((x) => x.isNotEmpty).map((x) => '"$x*"').join(' AND ');
    final rows = await db.rawQuery('''
      SELECT d.id, d.document_type, d.title, d.body, d.language,
             d.reference_id, bm25(search_documents_fts) AS rank
      FROM search_documents_fts f
      JOIN search_documents d ON d.id = f.id
      WHERE search_documents_fts MATCH ? AND d.status = 'published'
      ORDER BY rank ASC LIMIT ?
    ''', [q, limit.clamp(1, 100)]);
    return rows.where((r) => types.isEmpty || types.contains(r['document_type'] as String)).map((r) {
      final rank = (r['rank'] as num?)?.toDouble() ?? 999.0;
      final body = r['body'] as String;
      return SearchResult(
        id: r['id'] as String,
        type: SearchResultType.values.firstWhere((x) => x.name == r['document_type'], orElse: () => SearchResultType.study),
        title: r['title'] as String,
        snippet: body.length > 220 ? '${body.substring(0, 220)}…' : body,
        score: 1.0 / (1.0 + rank.abs()),
        metadata: {'language': r['language'], 'reference_id': r['reference_id']},
      );
    }).toList();
  }
}
