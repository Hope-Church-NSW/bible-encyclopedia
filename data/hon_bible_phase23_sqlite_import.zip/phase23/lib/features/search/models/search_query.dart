class SearchQuery {
  final String text;
  final Set<String> types;
  final int limit;

  const SearchQuery({required this.text, this.types = const {}, this.limit = 30});

  SearchQuery normalized() => SearchQuery(
    text: text.trim().toLowerCase(), types: types, limit: limit.clamp(1, 100),
  );
}
