enum SearchResultType {
  verse, encyclopedia, person, place, event, doctrine,
  originalWord, study, source, crossReference,
}

class SearchResult {
  final String id;
  final SearchResultType type;
  final String title;
  final String snippet;
  final double score;
  final Map<String, Object?> metadata;

  const SearchResult({
    required this.id,
    required this.type,
    required this.title,
    required this.snippet,
    required this.score,
    this.metadata = const {},
  });
}
