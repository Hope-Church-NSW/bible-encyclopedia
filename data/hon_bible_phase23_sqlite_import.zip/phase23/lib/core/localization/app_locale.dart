enum AppLocale {
  arabic('ar', true),
  english('en', false);

  final String code;
  final bool rtl;
  const AppLocale(this.code, this.rtl);
}
