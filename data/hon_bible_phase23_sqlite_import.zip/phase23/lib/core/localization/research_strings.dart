import 'app_locale.dart';

class ResearchStrings {
  static const values = {
    AppLocale.english: {
      'verse': 'Verse', 'study': 'Study', 'encyclopedia': 'Encyclopedia',
      'original': 'Original Language', 'crossReferences': 'Cross References',
      'sources': 'Sources', 'evidence': 'Evidence',
      'noEvidence': 'No evidence available', 'primarySource': 'Primary source',
    },
    AppLocale.arabic: {
      'verse': 'الآية', 'study': 'الدراسة', 'encyclopedia': 'الموسوعة',
      'original': 'اللغة الأصلية', 'crossReferences': 'مراجع متقاطعة',
      'sources': 'المصادر', 'evidence': 'الأدلة',
      'noEvidence': 'لا توجد أدلة متاحة', 'primarySource': 'مصدر أولي',
    },
  };

  static String get(AppLocale locale, String key) =>
      values[locale]?[key] ?? values[AppLocale.english]![key] ?? key;
}
