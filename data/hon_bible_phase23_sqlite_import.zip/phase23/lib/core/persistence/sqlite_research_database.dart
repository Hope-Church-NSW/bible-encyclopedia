import 'dart:convert';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'research_database.dart';

class SQLiteResearchDatabase implements ResearchDatabase {
  static const _databaseName = 'hon_bible_research.db';
  static const _version = 2;

  final String? databasePath;
  Database? _database;

  SQLiteResearchDatabase({this.databasePath});

  Future<Database> get database async {
    _database ??= await _open();
    return _database!;
  }

  Future<Database> _open() async {
    final path = databasePath ??
        join(await getDatabasesPath(), _databaseName);
    return openDatabase(
      path,
      version: _version,
      onCreate: (db, version) => _createSchema(db),
      onUpgrade: (db, oldVersion, newVersion) =>
          _migrate(db, oldVersion, newVersion),
    );
  }

  Future<void> _createSchema(Database db) async {
    await db.execute('''
      CREATE TABLE research_records(
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        data_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY(table_name, record_id)
      )
    ''');
    await db.execute('''
      CREATE INDEX idx_research_records_table
      ON research_records(table_name)
    ''');
    await db.execute('''
      CREATE INDEX idx_research_records_updated
      ON research_records(updated_at)
    ''');
    await db.execute('''
      CREATE TABLE schema_meta(
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
    await db.insert('schema_meta', {
      'key': 'schema_version',
      'value': '1',
    });
  }

  Future<void> _migrate(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('''
        CREATE INDEX IF NOT EXISTS idx_research_records_updated
        ON research_records(updated_at)
      ''');
      await db.insert(
        'schema_meta',
        {'key': 'schema_version', 'value': '2'},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
  }

  @override
  Future<void> put(String table, String id, Map<String, Object?> data) async {
    final db = await database;
    final now = DateTime.now().toUtc().toIso8601String();
    final existing = await db.query(
      'research_records',
      columns: ['created_at'],
      where: 'table_name = ? AND record_id = ?',
      whereArgs: [table, id],
      limit: 1,
    );
    await db.insert(
      'research_records',
      {
        'table_name': table,
        'record_id': id,
        'data_json': jsonEncode(data),
        'created_at': existing.isEmpty ? now : existing.first['created_at'],
        'updated_at': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<Map<String, Object?>?> get(String table, String id) async {
    final db = await database;
    final rows = await db.query(
      'research_records',
      columns: ['data_json'],
      where: 'table_name = ? AND record_id = ?',
      whereArgs: [table, id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Map<String, Object?>.from(
      jsonDecode(rows.first['data_json']! as String) as Map,
    );
  }

  @override
  Future<List<Map<String, Object?>>> where(
    String table,
    String field,
    Object value,
  ) async {
    final db = await database;
    final rows = await db.query(
      'research_records',
      columns: ['data_json'],
      where: 'table_name = ?',
      whereArgs: [table],
      orderBy: 'updated_at ASC',
    );
    final result = <Map<String, Object?>>[];
    for (final row in rows) {
      final decoded = Map<String, Object?>.from(
        jsonDecode(row['data_json']! as String) as Map,
      );
      if (decoded[field] == value) result.add(decoded);
    }
    return result;
  }

  @override
  Future<void> delete(String table, String id) async {
    final db = await database;
    await db.delete(
      'research_records',
      where: 'table_name = ? AND record_id = ?',
      whereArgs: [table, id],
    );
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
