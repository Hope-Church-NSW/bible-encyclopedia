import 'research_database.dart';

class InMemoryResearchDatabase implements ResearchDatabase {
  final Map<String, Map<String, Map<String, Object?>>> _tables = {};

  @override
  Future<void> put(String table, String id, Map<String, Object?> data) async {
    _tables.putIfAbsent(table, () => {})[id] = Map.of(data);
  }

  @override
  Future<Map<String, Object?>?> get(String table, String id) async =>
      _tables[table]?[id];

  @override
  Future<List<Map<String, Object?>>> where(String table, String field, Object value) async =>
      (_tables[table]?.values ?? const <Map<String, Object?>>[])
          .where((row) => row[field] == value)
          .map(Map<String, Object?>.of)
          .toList();

  @override
  Future<void> delete(String table, String id) async => _tables[table]?.remove(id);
}
