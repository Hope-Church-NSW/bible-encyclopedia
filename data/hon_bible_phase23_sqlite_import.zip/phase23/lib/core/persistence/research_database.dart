abstract class ResearchDatabase {
  Future<void> put(String table, String id, Map<String, Object?> data);
  Future<Map<String, Object?>?> get(String table, String id);
  Future<List<Map<String, Object?>>> where(String table, String field, Object value);
  Future<void> delete(String table, String id);
}
