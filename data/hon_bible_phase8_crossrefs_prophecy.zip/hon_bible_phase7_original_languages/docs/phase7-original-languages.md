# Phase 7 — Hebrew / Greek Original Language Layer

Supports Hebrew, Aramaic, and Greek lexical records and verse-to-word links.

Flow:
Verse -> surface form -> lemma -> transliteration -> morphology -> lexical metadata -> source

The schema stores source identifiers so lexical material can be audited and licensed independently.
Strong's numbers are metadata identifiers and do not grant rights to reproduce copyrighted lexicon content.
Definitions and semantic notes require recorded provenance and review status before being presented as authoritative research material.
