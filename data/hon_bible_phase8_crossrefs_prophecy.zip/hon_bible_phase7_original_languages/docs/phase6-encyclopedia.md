# Phase 6 — Encyclopedia Engine

Structured encyclopedia entries are stored as original/licensed content
plus bibliographic references rather than copied third-party publications.

Each entry has:
- stable id
- title and normalized title
- category
- summary
- optional body
- review status

Entries can connect to Knowledge Graph nodes, allowing:
Encyclopedia → Verse / Person / Place / Event / Doctrine → Source.
