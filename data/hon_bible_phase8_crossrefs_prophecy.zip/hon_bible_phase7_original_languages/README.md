# Hope Of Nation Bible

نواة Flutter لتطبيق كتاب مقدس وموسوعة بحثية Offline-first.

## التشغيل

```bash
flutter pub get
flutter run
```

## الحالة الحالية

- SQLite foundation
- Bible books / verses
- Chapter reader
- Verse detail
- Chapter-level audio entry point
- RTL Arabic foundation
- Search entry point
- Studies / Encyclopedia / Sources schema

المرحلة التالية: Content Package Importer + Validator + FTS search index.
