import 'package:flutter/material.dart';
import 'features/home/home_page.dart';

class HonBibleApp extends StatelessWidget {
  const HonBibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hope Of Nation Bible',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF123E78)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}
