import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  Database? _db;

  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dbPath = join(await getDatabasesPath(), 'hon_bible.db');
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE bible_books(
            id TEXT PRIMARY KEY,
            name_ar TEXT NOT NULL,
            name_en TEXT NOT NULL,
            chapter_count INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE bible_verses(
            id TEXT PRIMARY KEY,
            book_id TEXT NOT NULL,
            chapter_number INTEGER NOT NULL,
            verse_number INTEGER NOT NULL,
            text TEXT NOT NULL,
            translation_id TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE studies(
            id TEXT PRIMARY KEY,
            title_ar TEXT NOT NULL,
            summary_ar TEXT,
            content_ar TEXT NOT NULL,
            status TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE encyclopedia_entries(
            id TEXT PRIMARY KEY,
            title_ar TEXT NOT NULL,
            summary_ar TEXT,
            content_ar TEXT NOT NULL,
            status TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE sources(
            id TEXT PRIMARY KEY,
            source_type TEXT NOT NULL,
            title TEXT NOT NULL,
            author TEXT,
            publisher TEXT,
            publication_year INTEGER,
            url TEXT,
            license TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE study_scripture_links(
            study_id TEXT NOT NULL,
            verse_id TEXT NOT NULL,
            PRIMARY KEY(study_id, verse_id)
          )
        ''');
        await db.execute('''
          CREATE TABLE encyclopedia_scripture_links(
            encyclopedia_id TEXT NOT NULL,
            verse_id TEXT NOT NULL,
            PRIMARY KEY(encyclopedia_id, verse_id)
          )
        ''');
        await db.execute('''
          CREATE TABLE citations(
            content_id TEXT NOT NULL,
            source_id TEXT NOT NULL,
            PRIMARY KEY(content_id, source_id)
          )
        ''');
        await db.execute('''
          CREATE TABLE highlights(
            id TEXT PRIMARY KEY,
            verse_id TEXT NOT NULL,
            color TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE notes(
            id TEXT PRIMARY KEY,
            verse_id TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
          )
        ''');
      },
    );
  }
}
