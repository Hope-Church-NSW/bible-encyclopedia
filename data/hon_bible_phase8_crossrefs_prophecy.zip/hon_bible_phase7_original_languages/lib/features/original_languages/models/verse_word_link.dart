class VerseWordLink {
  final String id;
  final String verseId;
  final String wordId;
  final int position;
  final String surfaceForm;
  final String? morphology;
  final String? semanticNote;
  final String? sourceId;

  const VerseWordLink({
    required this.id,
    required this.verseId,
    required this.wordId,
    required this.position,
    required this.surfaceForm,
    this.morphology,
    this.semanticNote,
    this.sourceId,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'verse_id': verseId,
    'word_id': wordId,
    'position': position,
    'surface_form': surfaceForm,
    'morphology': morphology,
    'semantic_note': semanticNote,
    'source_id': sourceId,
  };

  factory VerseWordLink.fromMap(Map<String, Object?> map) => VerseWordLink(
    id: map['id'] as String,
    verseId: map['verse_id'] as String,
    wordId: map['word_id'] as String,
    position: map['position'] as int,
    surfaceForm: map['surface_form'] as String,
    morphology: map['morphology'] as String?,
    semanticNote: map['semantic_note'] as String?,
    sourceId: map['source_id'] as String?,
  );
}
