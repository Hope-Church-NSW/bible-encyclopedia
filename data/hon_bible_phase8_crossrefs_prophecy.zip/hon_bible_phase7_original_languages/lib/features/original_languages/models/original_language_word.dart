enum OriginalLanguage { hebrew, aramaic, greek }

class OriginalLanguageWord {
  final String id;
  final String lemma;
  final String normalizedLemma;
  final String transliteration;
  final OriginalLanguage language;
  final String? strongsNumber;
  final String? morphology;
  final String? gloss;
  final String? definition;
  final String status;

  const OriginalLanguageWord({
    required this.id,
    required this.lemma,
    required this.normalizedLemma,
    required this.transliteration,
    required this.language,
    this.strongsNumber,
    this.morphology,
    this.gloss,
    this.definition,
    this.status = 'draft',
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'lemma': lemma,
    'normalized_lemma': normalizedLemma,
    'transliteration': transliteration,
    'language': language.name,
    'strongs_number': strongsNumber,
    'morphology': morphology,
    'gloss': gloss,
    'definition': definition,
    'status': status,
  };

  factory OriginalLanguageWord.fromMap(Map<String, Object?> map) =>
      OriginalLanguageWord(
        id: map['id'] as String,
        lemma: map['lemma'] as String,
        normalizedLemma: map['normalized_lemma'] as String,
        transliteration: map['transliteration'] as String,
        language: OriginalLanguage.values.byName(map['language'] as String),
        strongsNumber: map['strongs_number'] as String?,
        morphology: map['morphology'] as String?,
        gloss: map['gloss'] as String?,
        definition: map['definition'] as String?,
        status: map['status'] as String? ?? 'draft',
      );
}
