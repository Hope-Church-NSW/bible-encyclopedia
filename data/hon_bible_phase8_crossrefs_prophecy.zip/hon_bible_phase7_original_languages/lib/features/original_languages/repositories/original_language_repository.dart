import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/original_language_word.dart';
import '../models/verse_word_link.dart';

class OriginalLanguageRepository {
  final AppDatabase database;

  OriginalLanguageRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;

    await db.execute('''
      CREATE TABLE IF NOT EXISTS original_language_words(
        id TEXT PRIMARY KEY,
        lemma TEXT NOT NULL,
        normalized_lemma TEXT NOT NULL,
        transliteration TEXT NOT NULL,
        language TEXT NOT NULL,
        strongs_number TEXT,
        morphology TEXT,
        gloss TEXT,
        definition TEXT,
        status TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS verse_word_links(
        id TEXT PRIMARY KEY,
        verse_id TEXT NOT NULL,
        word_id TEXT NOT NULL,
        position INTEGER NOT NULL,
        surface_form TEXT NOT NULL,
        morphology TEXT,
        semantic_note TEXT,
        source_id TEXT
      )
    ''');

    await db.execute('CREATE INDEX IF NOT EXISTS idx_olw_lemma ON original_language_words(normalized_lemma)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_olw_language ON original_language_words(language)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_vwl_verse ON verse_word_links(verse_id, position)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_vwl_word ON verse_word_links(word_id)');
  }

  Future<void> upsertWord(OriginalLanguageWord word) async {
    final db = await database.database;
    await db.insert('original_language_words', word.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> linkWord(VerseWordLink link) async {
    final db = await database.database;
    await db.insert('verse_word_links', link.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<OriginalLanguageWord?> getWord(String id) async {
    final db = await database.database;
    final rows = await db.query('original_language_words', where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : OriginalLanguageWord.fromMap(rows.first);
  }

  Future<List<OriginalLanguageWord>> searchLemma(String query, {OriginalLanguage? language, int limit = 30}) async {
    final db = await database.database;
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];
    final where = <String>['normalized_lemma LIKE ?'];
    final args = <Object?>['%$q%'];
    if (language != null) { where.add('language = ?'); args.add(language.name); }
    final rows = await db.query('original_language_words', where: where.join(' AND '), whereArgs: args, orderBy: 'lemma COLLATE NOCASE ASC', limit: limit);
    return rows.map(OriginalLanguageWord.fromMap).toList();
  }

  Future<List<VerseWordLink>> wordsForVerse(String verseId) async {
    final db = await database.database;
    final rows = await db.query('verse_word_links', where: 'verse_id = ?', whereArgs: [verseId], orderBy: 'position ASC');
    return rows.map(VerseWordLink.fromMap).toList();
  }

  Future<List<VerseWordLink>> versesForWord(String wordId) async {
    final db = await database.database;
    final rows = await db.query('verse_word_links', where: 'word_id = ?', whereArgs: [wordId], orderBy: 'verse_id ASC, position ASC');
    return rows.map(VerseWordLink.fromMap).toList();
  }
}
