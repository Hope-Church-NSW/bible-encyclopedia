import '../models/original_language_word.dart';
import '../models/verse_word_link.dart';
import '../repositories/original_language_repository.dart';

class OriginalLanguageService {
  final OriginalLanguageRepository repository;
  OriginalLanguageService({required this.repository});

  Future<void> initialize() => repository.ensureSchema();
  Future<void> saveWord(OriginalLanguageWord word) => repository.upsertWord(word);
  Future<void> linkVerseWord(VerseWordLink link) => repository.linkWord(link);
  Future<OriginalLanguageWord?> word(String id) => repository.getWord(id);
  Future<List<OriginalLanguageWord>> searchLemma(String query, {OriginalLanguage? language, int limit = 30}) => repository.searchLemma(query, language: language, limit: limit);
  Future<List<VerseWordLink>> wordsInVerse(String verseId) => repository.wordsForVerse(verseId);
  Future<List<VerseWordLink>> occurrences(String wordId) => repository.versesForWord(wordId);
}
