import 'package:flutter/material.dart';
import '../bible/pages/bible_books_page.dart';
import '../search/pages/search_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('Hope Of Nation Bible')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'مكتبة كتابية وبحثية',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            _item(context, '📖 الكتاب المقدس', const BibleBooksPage()),
            _item(context, '🔎 البحث الموحد', const SearchPage()),
            _item(context, '📚 الموسوعة الكتابية', const SearchPage()),
            _item(context, '🎧 الكتاب المسموع', const SearchPage()),
            _item(context, '🧠 مساحة الباحث', const SearchPage()),
          ],
        ),
      ),
    );
  }

  Widget _item(BuildContext context, String title, Widget page) {
    return Card(
      child: ListTile(
        title: Text(title),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => page),
        ),
      ),
    );
  }
}
