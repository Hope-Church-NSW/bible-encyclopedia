enum ProphecyLinkType { direct, typological, thematic, promise, messianic, eschatological }

class ProphecyLink {
  final String id;
  final String prophecyVerseId;
  final String fulfillmentVerseId;
  final ProphecyLinkType type;
  final String? explanation;
  final String? sourceId;
  final double confidence;
  final String reviewStatus;

  const ProphecyLink({
    required this.id, required this.prophecyVerseId, required this.fulfillmentVerseId,
    required this.type, this.explanation, this.sourceId, this.confidence = 1.0,
    this.reviewStatus = 'unreviewed',
  });

  Map<String, Object?> toMap() => {
    'id': id, 'prophecy_verse_id': prophecyVerseId, 'fulfillment_verse_id': fulfillmentVerseId,
    'link_type': type.name, 'explanation': explanation, 'source_id': sourceId,
    'confidence': confidence, 'review_status': reviewStatus,
  };

  factory ProphecyLink.fromMap(Map<String, Object?> map) => ProphecyLink(
    id: map['id'] as String, prophecyVerseId: map['prophecy_verse_id'] as String,
    fulfillmentVerseId: map['fulfillment_verse_id'] as String,
    type: ProphecyLinkType.values.byName(map['link_type'] as String),
    explanation: map['explanation'] as String?, sourceId: map['source_id'] as String?,
    confidence: (map['confidence'] as num?)?.toDouble() ?? 1.0,
    reviewStatus: map['review_status'] as String? ?? 'unreviewed',
  );
}
