import '../models/prophecy_link.dart';
import '../repositories/prophecy_repository.dart';

class ProphecyService {
  final ProphecyRepository repository;
  ProphecyService({required this.repository});
  Future<void> initialize() => repository.ensureSchema();
  Future<void> save(ProphecyLink link) => repository.upsert(link);
  Future<List<ProphecyLink>> fulfillments(String verseId) => repository.fulfillments(verseId);
  Future<List<ProphecyLink>> fulfilledBy(String verseId) => repository.fulfilledBy(verseId);
}
