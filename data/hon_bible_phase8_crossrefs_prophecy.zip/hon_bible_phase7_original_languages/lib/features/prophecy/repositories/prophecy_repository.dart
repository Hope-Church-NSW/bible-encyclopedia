import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/prophecy_link.dart';

class ProphecyRepository {
  final AppDatabase database;
  ProphecyRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;
    await db.execute('''CREATE TABLE IF NOT EXISTS prophecy_links(
      id TEXT PRIMARY KEY, prophecy_verse_id TEXT NOT NULL,
      fulfillment_verse_id TEXT NOT NULL, link_type TEXT NOT NULL,
      explanation TEXT, source_id TEXT, confidence REAL NOT NULL,
      review_status TEXT NOT NULL)''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_prophecy_source ON prophecy_links(prophecy_verse_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_prophecy_fulfillment ON prophecy_links(fulfillment_verse_id)');
  }

  Future<void> upsert(ProphecyLink link) async {
    final db = await database.database;
    await db.insert('prophecy_links', link.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ProphecyLink>> fulfillments(String prophecyVerseId) async {
    final db = await database.database;
    final rows = await db.query('prophecy_links', where: 'prophecy_verse_id = ?',
      whereArgs: [prophecyVerseId], orderBy: 'confidence DESC, fulfillment_verse_id ASC');
    return rows.map(ProphecyLink.fromMap).toList();
  }

  Future<List<ProphecyLink>> fulfilledBy(String fulfillmentVerseId) async {
    final db = await database.database;
    final rows = await db.query('prophecy_links', where: 'fulfillment_verse_id = ?',
      whereArgs: [fulfillmentVerseId], orderBy: 'confidence DESC, prophecy_verse_id ASC');
    return rows.map(ProphecyLink.fromMap).toList();
  }
}
