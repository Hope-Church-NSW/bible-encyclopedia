import 'package:flutter/material.dart';
import '../models/bible_book.dart';
import '../repositories/bible_repository.dart';
import '../../../core/database/app_database.dart';
import 'verse_detail_page.dart';

class ChapterPage extends StatelessWidget {
  final BibleBook book;

  const ChapterPage({super.key, required this.book});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(book.nameAr)),
        body: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: book.chapterCount,
          itemBuilder: (_, i) {
            final chapter = i + 1;
            return FilledButton(
              onPressed: () async {
                final repo = BibleRepository(database: AppDatabase());
                final verses = await repo.getChapter(
                  bookId: book.id,
                  chapter: chapter,
                  translationId: 'ar',
                );
                if (!context.mounted) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => VerseDetailPage(
                      book: book,
                      chapter: chapter,
                      verses: verses,
                    ),
                  ),
                );
              },
              child: Text('$chapter'),
            );
          },
        ),
      ),
    );
  }
}
