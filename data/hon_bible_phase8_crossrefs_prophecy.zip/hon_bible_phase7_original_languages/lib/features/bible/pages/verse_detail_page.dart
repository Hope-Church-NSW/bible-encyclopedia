import 'package:flutter/material.dart';
import '../models/bible_book.dart';
import '../models/bible_verse.dart';

class VerseDetailPage extends StatelessWidget {
  final BibleBook book;
  final int chapter;
  final List<BibleVerse> verses;

  const VerseDetailPage({
    super.key,
    required this.book,
    required this.chapter,
    required this.verses,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('${book.nameAr} $chapter'),
          actions: [
            IconButton(
              tooltip: 'تشغيل الأصحاح',
              icon: const Icon(Icons.headphones),
              onPressed: () {},
            ),
          ],
        ),
        body: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: verses.length,
          itemBuilder: (_, i) {
            final verse = verses[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: InkWell(
                onTap: () => _openVerse(context),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(
                    '${verse.verseNumber} ${verse.text}',
                    style: const TextStyle(fontSize: 20, height: 1.8),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _openVerse(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Wrap(
            children: const [
              ListTile(
                leading: Icon(Icons.menu_book),
                title: Text('الدراسة'),
              ),
              ListTile(
                leading: Icon(Icons.library_books),
                title: Text('الموسوعة'),
              ),
              ListTile(
                leading: Icon(Icons.translate),
                title: Text('اللغة الأصلية'),
              ),
              ListTile(
                leading: Icon(Icons.link),
                title: Text('آيات مرتبطة'),
              ),
              ListTile(
                leading: Icon(Icons.palette),
                title: Text('تظليل'),
              ),
              ListTile(
                leading: Icon(Icons.note_add),
                title: Text('ملاحظة'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
