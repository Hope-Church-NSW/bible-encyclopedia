import 'package:flutter/material.dart';
import '../repositories/bible_repository.dart';
import '../../../core/database/app_database.dart';
import 'chapter_page.dart';

class BibleBooksPage extends StatefulWidget {
  const BibleBooksPage({super.key});

  @override
  State<BibleBooksPage> createState() => _BibleBooksPageState();
}

class _BibleBooksPageState extends State<BibleBooksPage> {
  final repository = BibleRepository(database: AppDatabase());
  late Future<List<dynamic>> books;

  @override
  void initState() {
    super.initState();
    books = repository.getBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الكتاب المقدس')),
        body: FutureBuilder<List<dynamic>>(
          future: books,
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final data = snapshot.data!;
            if (data.isEmpty) {
              return const Center(
                child: Text('لم يتم استيراد نص الكتاب المقدس بعد.'),
              );
            }
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (_, i) {
                final book = data[i];
                return ListTile(
                  title: Text(book.nameAr),
                  subtitle: Text(book.nameEn),
                  trailing: Text('${book.chapterCount}'),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChapterPage(book: book),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
