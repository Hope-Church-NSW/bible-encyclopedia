import '../../../core/database/app_database.dart';
import '../models/bible_book.dart';
import '../models/bible_verse.dart';

class BibleRepository {
  final AppDatabase database;

  BibleRepository({required this.database});

  Future<List<BibleBook>> getBooks() async {
    final db = await database.database;
    final rows = await db.query('bible_books', orderBy: 'id');
    return rows.map((r) => BibleBook(
      id: r['id'] as String,
      nameAr: r['name_ar'] as String,
      nameEn: r['name_en'] as String,
      chapterCount: r['chapter_count'] as int,
    )).toList();
  }

  Future<List<BibleVerse>> getChapter({
    required String bookId,
    required int chapter,
    required String translationId,
  }) async {
    final db = await database.database;
    final rows = await db.query(
      'bible_verses',
      where: 'book_id = ? AND chapter_number = ? AND translation_id = ?',
      whereArgs: [bookId, chapter, translationId],
      orderBy: 'verse_number',
    );
    return rows.map((r) => BibleVerse(
      id: r['id'] as String,
      bookId: r['book_id'] as String,
      chapterNumber: r['chapter_number'] as int,
      verseNumber: r['verse_number'] as int,
      text: r['text'] as String,
      translationId: r['translation_id'] as String,
    )).toList();
  }
}
