class BibleVerse {
  final String id;
  final String bookId;
  final int chapterNumber;
  final int verseNumber;
  final String text;
  final String translationId;

  const BibleVerse({
    required this.id,
    required this.bookId,
    required this.chapterNumber,
    required this.verseNumber,
    required this.text,
    required this.translationId,
  });
}
