class BibleBook {
  final String id;
  final String nameAr;
  final String nameEn;
  final int chapterCount;

  const BibleBook({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.chapterCount,
  });
}
