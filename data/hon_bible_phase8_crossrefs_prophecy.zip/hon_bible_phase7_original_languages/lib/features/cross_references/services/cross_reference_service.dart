import '../models/cross_reference.dart';
import '../repositories/cross_reference_repository.dart';

class CrossReferenceService {
  final CrossReferenceRepository repository;
  CrossReferenceService({required this.repository});
  Future<void> initialize() => repository.ensureSchema();
  Future<void> save(CrossReference reference) => repository.upsert(reference);
  Future<List<CrossReference>> forVerse(String verseId, {CrossReferenceType? type}) =>
      repository.forVerse(verseId, type: type);
}
