enum CrossReferenceType { parallel, quotation, allusion, thematic, lexical, historical, geographical }

class CrossReference {
  final String id;
  final String fromVerseId;
  final String toVerseId;
  final CrossReferenceType type;
  final String? explanation;
  final String? sourceId;
  final double confidence;
  final String reviewStatus;

  const CrossReference({
    required this.id,
    required this.fromVerseId,
    required this.toVerseId,
    required this.type,
    this.explanation,
    this.sourceId,
    this.confidence = 1.0,
    this.reviewStatus = 'unreviewed',
  });

  Map<String, Object?> toMap() => {
    'id': id, 'from_verse_id': fromVerseId, 'to_verse_id': toVerseId,
    'reference_type': type.name, 'explanation': explanation,
    'source_id': sourceId, 'confidence': confidence, 'review_status': reviewStatus,
  };

  factory CrossReference.fromMap(Map<String, Object?> map) => CrossReference(
    id: map['id'] as String,
    fromVerseId: map['from_verse_id'] as String,
    toVerseId: map['to_verse_id'] as String,
    type: CrossReferenceType.values.byName(map['reference_type'] as String),
    explanation: map['explanation'] as String?,
    sourceId: map['source_id'] as String?,
    confidence: (map['confidence'] as num?)?.toDouble() ?? 1.0,
    reviewStatus: map['review_status'] as String? ?? 'unreviewed',
  );
}
