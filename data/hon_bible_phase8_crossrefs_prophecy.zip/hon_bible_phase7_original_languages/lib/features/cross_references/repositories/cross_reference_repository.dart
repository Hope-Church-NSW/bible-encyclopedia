import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/cross_reference.dart';

class CrossReferenceRepository {
  final AppDatabase database;
  CrossReferenceRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;
    await db.execute('''CREATE TABLE IF NOT EXISTS cross_references(
      id TEXT PRIMARY KEY, from_verse_id TEXT NOT NULL, to_verse_id TEXT NOT NULL,
      reference_type TEXT NOT NULL, explanation TEXT, source_id TEXT,
      confidence REAL NOT NULL, review_status TEXT NOT NULL)''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_xref_from ON cross_references(from_verse_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_xref_to ON cross_references(to_verse_id)');
  }

  Future<void> upsert(CrossReference reference) async {
    final db = await database.database;
    await db.insert('cross_references', reference.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<CrossReference>> forVerse(String verseId, {CrossReferenceType? type}) async {
    final db = await database.database;
    final where = <String>['(from_verse_id = ? OR to_verse_id = ?)'];
    final args = <Object?>[verseId, verseId];
    if (type != null) { where.add('reference_type = ?'); args.add(type.name); }
    final rows = await db.query('cross_references', where: where.join(' AND '), whereArgs: args,
      orderBy: 'confidence DESC, to_verse_id ASC');
    return rows.map(CrossReference.fromMap).toList();
  }
}
