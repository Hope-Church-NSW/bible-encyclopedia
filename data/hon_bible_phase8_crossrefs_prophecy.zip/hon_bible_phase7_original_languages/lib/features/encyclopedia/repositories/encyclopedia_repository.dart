import 'package:sqflite/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../models/encyclopedia_entry.dart';

class EncyclopediaRepository {
  final AppDatabase database;
  EncyclopediaRepository({required this.database});

  Future<void> ensureSchema() async {
    final db = await database.database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS encyclopedia_entries(
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        normalized_title TEXT NOT NULL,
        entry_type TEXT NOT NULL,
        summary TEXT NOT NULL,
        body TEXT,
        status TEXT NOT NULL
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_encyclopedia_title '
      'ON encyclopedia_entries(normalized_title)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_encyclopedia_type '
      'ON encyclopedia_entries(entry_type)',
    );
  }

  Future<void> upsert(EncyclopediaEntry entry) async {
    final db = await database.database;
    await db.insert(
      'encyclopedia_entries',
      entry.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<EncyclopediaEntry?> getById(String id) async {
    final db = await database.database;
    final rows = await db.query(
      'encyclopedia_entries',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : EncyclopediaEntry.fromMap(rows.first);
  }

  Future<List<EncyclopediaEntry>> search(
    String query, {
    EncyclopediaEntryType? type,
    int limit = 30,
  }) async {
    final db = await database.database;
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];

    final where = <String>['normalized_title LIKE ?'];
    final args = <Object?>['%$q%'];

    if (type != null) {
      where.add('entry_type = ?');
      args.add(type.name);
    }

    final rows = await db.query(
      'encyclopedia_entries',
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'title COLLATE NOCASE ASC',
      limit: limit,
    );
    return rows.map(EncyclopediaEntry.fromMap).toList();
  }
}
