enum EncyclopediaEntryType {
  topic, person, place, event, doctrine, object, book, custom,
}

class EncyclopediaEntry {
  final String id;
  final String title;
  final String normalizedTitle;
  final EncyclopediaEntryType type;
  final String summary;
  final String? body;
  final String status;

  const EncyclopediaEntry({
    required this.id,
    required this.title,
    required this.normalizedTitle,
    required this.type,
    required this.summary,
    this.body,
    this.status = 'draft',
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'title': title,
    'normalized_title': normalizedTitle,
    'entry_type': type.name,
    'summary': summary,
    'body': body,
    'status': status,
  };

  factory EncyclopediaEntry.fromMap(Map<String, Object?> map) =>
      EncyclopediaEntry(
        id: map['id'] as String,
        title: map['title'] as String,
        normalizedTitle: map['normalized_title'] as String,
        type: EncyclopediaEntryType.values.byName(map['entry_type'] as String),
        summary: map['summary'] as String,
        body: map['body'] as String?,
        status: map['status'] as String? ?? 'draft',
      );
}
