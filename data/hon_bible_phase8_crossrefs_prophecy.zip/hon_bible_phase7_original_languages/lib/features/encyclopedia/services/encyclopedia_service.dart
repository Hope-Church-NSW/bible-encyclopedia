import '../../../core/knowledge/knowledge_graph_repository.dart';
import '../../../core/knowledge/knowledge_models.dart';
import '../models/encyclopedia_entry.dart';
import '../repositories/encyclopedia_repository.dart';

class EncyclopediaService {
  final EncyclopediaRepository repository;
  final KnowledgeGraphRepository graph;

  EncyclopediaService({
    required this.repository,
    required this.graph,
  });

  Future<void> initialize() async {
    await repository.ensureSchema();
    await graph.ensureSchema();
  }

  Future<void> saveEntry(EncyclopediaEntry entry) =>
      repository.upsert(entry);

  Future<EncyclopediaEntry?> getEntry(String id) =>
      repository.getById(id);

  Future<List<EncyclopediaEntry>> search(
    String query, {
    EncyclopediaEntryType? type,
    int limit = 30,
  }) =>
      repository.search(query, type: type, limit: limit);

  Future<void> linkEntryToNode({
    required EncyclopediaEntry entry,
    required KnowledgeNode node,
    required KnowledgeRelationType relation,
    String? sourceId,
    double confidence = 1.0,
  }) async {
    await repository.upsert(entry);
    await graph.upsertNode(node);

    final encyclopediaNode = KnowledgeNode(
      id: 'encyclopedia:${entry.id}',
      type: KnowledgeNodeType.encyclopedia,
      label: entry.title,
      summary: entry.summary,
      status: entry.status,
    );

    await graph.upsertNode(encyclopediaNode);
    await graph.upsertEdge(KnowledgeEdge(
      id: '${encyclopediaNode.id}::${relation.name}::${node.id}',
      fromNodeId: encyclopediaNode.id,
      toNodeId: node.id,
      relation: relation,
      sourceId: sourceId,
      confidence: confidence,
      reviewStatus: 'unreviewed',
    ));
  }
}
