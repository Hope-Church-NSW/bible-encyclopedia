import { getClientId } from "./client-id";
import * as offline from "./bundled-bible";

const BASE = process.env.EXPO_PUBLIC_BACKEND_URL || '';

async function req<T = any>(path: string, opts: RequestInit = {}): Promise<T> {
  const clientId = await getClientId();
  const res = await fetch(`${BASE}/api${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      'X-Client-Id': clientId,
      ...(opts.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${res.status}: ${body}`);
  }
  return res.json();
}

/** Wrap a bundled synchronous call in a promise so callers keep async ergonomics. */
function local<T>(fn: () => T): Promise<T> {
  return Promise.resolve().then(fn);
}

export const api = {
  // ==== Bible READS — 100% OFFLINE from bundled JSON ====
  books: () => local(() => offline.listBooks()),
  chapter: (bookId: string, chapter: number) =>
    local(() => offline.getChapter(bookId, chapter)),
  verseDetail: (bookId: string, chapter: number, verse: number) =>
    local(() => offline.getVerseDetail(bookId, chapter, verse)),
  places: () => local(() => offline.getPlaces()),
  verseOfDay: () => local(() => offline.getVerseOfDay()),
  search: (q: string, lang: 'en' | 'ar' = 'ar') =>
    local(() => offline.searchBible(q, lang)),
  readingPlans: () => local(() => offline.getReadingPlans()),
  church: () => local(() => offline.getChurch()),

  // ==== AI features — REQUIRE INTERNET (per agreement) ====
  commentary: (bookId: string, chapter: number, verse: number, author = "matta") =>
    req(`/commentary/${bookId}/${chapter}/${verse}?author=${author}`),
  commentaryAuthors: () =>
    local(() => ({
      authors: [
        { id: "matta", name_ar: "الأب متى المسكين", name_en: "Fr. Matta El-Meskeen" },
        { id: "menes", name_ar: "القس منيس عبد النور", name_en: "Rev. Menes Abdel-Nour" },
        { id: "macdonald", name_ar: "وليم مكدونالد", name_en: "William MacDonald" },
        { id: "newton", name_ar: "بنيامين بنكترتن", name_en: "Benjamin W. Newton" },
        { id: "kelly", name_ar: "وليم أدي", name_en: "William Kelly" },
      ],
    })),
  enrichVerse: (bookId: string, chapter: number, verse: number) =>
    req(`/bible/verse/${bookId}/${chapter}/${verse}/enrich`, { method: 'POST' }),
  chat: (session_id: string, message: string, language: 'en' | 'ar' = 'en') =>
    req('/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ session_id, message, language }),
    }),
  chatHistory: (session_id: string) => req(`/ai/history/${session_id}`),
  clearChat: (session_id: string) => req(`/ai/history/${session_id}`, { method: 'DELETE' }),

  // ==== Audio — thin YouTube redirect (needs internet to open external URL) ====
  audio: (bookId: string, chapter: number) => req(`/audio/${bookId}/${chapter}`),

  // ==== User-generated data — needs internet for cross-device consistency ====
  bookmarks: () => req('/bookmarks'),
  addBookmark: (body: { book_id: string; chapter: number; verse: number; label?: string }) =>
    req('/bookmarks', { method: 'POST', body: JSON.stringify(body) }),
  removeBookmark: (id: string) => req(`/bookmarks/${id}`, { method: 'DELETE' }),

  highlights: () => req('/highlights'),
  addHighlight: (body: { book_id: string; chapter: number; verse: number; color?: string }) =>
    req('/highlights', { method: 'POST', body: JSON.stringify(body) }),
  removeHighlight: (id: string) => req(`/highlights/${id}`, { method: 'DELETE' }),

  notes: () => req('/notes'),
  addNote: (body: { book_id: string; chapter: number; verse: number; text: string }) =>
    req('/notes', { method: 'POST', body: JSON.stringify(body) }),
  removeNote: (id: string) => req(`/notes/${id}`, { method: 'DELETE' }),

  prayers: () => req('/prayers'),
  addPrayer: (body: { title: string; body: string }) =>
    req('/prayers', { method: 'POST', body: JSON.stringify(body) }),
  togglePrayer: (id: string) => req(`/prayers/${id}/toggle`, { method: 'POST' }),
  removePrayer: (id: string) => req(`/prayers/${id}`, { method: 'DELETE' }),

  // Privacy — user data
  dataSummary: () => req('/user/data-summary'),
  deleteMyData: () => req('/user/data', { method: 'DELETE' }),
};
