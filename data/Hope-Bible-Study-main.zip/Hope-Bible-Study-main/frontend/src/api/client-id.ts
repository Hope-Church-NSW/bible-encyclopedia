import { storage } from "@/src/utils/storage";

let cached: string | null = null;

/**
 * Anonymous per-device identity used to scope user-generated content
 * (bookmarks, highlights, notes, prayer requests, AI chat history).
 *
 * The ID is generated once on first launch and persisted locally. It never
 * leaves the device except in the `X-Client-Id` request header.
 */
export async function getClientId(): Promise<string> {
  if (cached) return cached;
  const stored = await storage.getItem<string>("hcs-client-id", "");
  if (stored && stored.length >= 8) {
    cached = stored;
    return stored;
  }
  // Generate a URL-safe UUID-like identifier
  const id = "cid_" + genUuid().replace(/-/g, "");
  await storage.setItem("hcs-client-id", id);
  cached = id;
  return id;
}

export async function resetClientId(): Promise<string> {
  const id = "cid_" + genUuid().replace(/-/g, "");
  await storage.setItem("hcs-client-id", id);
  cached = id;
  return id;
}

function genUuid(): string {
  // RFC4122 v4 — works in RN + web without extra deps
  const b = new Uint8Array(16);
  if (typeof crypto !== "undefined" && (crypto as any).getRandomValues) {
    (crypto as any).getRandomValues(b);
  } else {
    for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  }
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0"));
  return `${h.slice(0, 4).join("")}-${h.slice(4, 6).join("")}-${h.slice(6, 8).join("")}-${h.slice(8, 10).join("")}-${h.slice(10, 16).join("")}`;
}
