/**
 * Bundled offline Bible dataset.
 * All 66 books × 31,105 verses (Arabic Van Dyke + English WEB) are packaged
 * inside the app binary. Zero network required to read Scripture.
 *
 * Only the following features need internet (per agreement):
 *   • AI chat (Ask AI)
 *   • AI commentary (تفسير) — Fr. Matta / Menes / MacDonald / Newton / Kelly
 *   • AI enrichment for verses not in the curated metadata
 *   • Church external links (Facebook / YouTube / etc.)
 */

/* eslint-disable @typescript-eslint/no-var-requires */

// --- Static book-registry (Metro requires literal require paths) ---
const BOOK_JSON: Record<string, any> = {
  gen: require("../../assets/data/gen.json"),
  exo: require("../../assets/data/exo.json"),
  lev: require("../../assets/data/lev.json"),
  num: require("../../assets/data/num.json"),
  deu: require("../../assets/data/deu.json"),
  jos: require("../../assets/data/jos.json"),
  jdg: require("../../assets/data/jdg.json"),
  rut: require("../../assets/data/rut.json"),
  "1sa": require("../../assets/data/1sa.json"),
  "2sa": require("../../assets/data/2sa.json"),
  "1ki": require("../../assets/data/1ki.json"),
  "2ki": require("../../assets/data/2ki.json"),
  "1ch": require("../../assets/data/1ch.json"),
  "2ch": require("../../assets/data/2ch.json"),
  ezr: require("../../assets/data/ezr.json"),
  neh: require("../../assets/data/neh.json"),
  est: require("../../assets/data/est.json"),
  job: require("../../assets/data/job.json"),
  psa: require("../../assets/data/psa.json"),
  pro: require("../../assets/data/pro.json"),
  ecc: require("../../assets/data/ecc.json"),
  sng: require("../../assets/data/sng.json"),
  isa: require("../../assets/data/isa.json"),
  jer: require("../../assets/data/jer.json"),
  lam: require("../../assets/data/lam.json"),
  ezk: require("../../assets/data/ezk.json"),
  dan: require("../../assets/data/dan.json"),
  hos: require("../../assets/data/hos.json"),
  jol: require("../../assets/data/jol.json"),
  amo: require("../../assets/data/amo.json"),
  oba: require("../../assets/data/oba.json"),
  jon: require("../../assets/data/jon.json"),
  mic: require("../../assets/data/mic.json"),
  nam: require("../../assets/data/nam.json"),
  hab: require("../../assets/data/hab.json"),
  zep: require("../../assets/data/zep.json"),
  hag: require("../../assets/data/hag.json"),
  zec: require("../../assets/data/zec.json"),
  mal: require("../../assets/data/mal.json"),
  mat: require("../../assets/data/mat.json"),
  mrk: require("../../assets/data/mrk.json"),
  luk: require("../../assets/data/luk.json"),
  joh: require("../../assets/data/joh.json"),
  act: require("../../assets/data/act.json"),
  rom: require("../../assets/data/rom.json"),
  "1co": require("../../assets/data/1co.json"),
  "2co": require("../../assets/data/2co.json"),
  gal: require("../../assets/data/gal.json"),
  eph: require("../../assets/data/eph.json"),
  phi: require("../../assets/data/phi.json"),
  col: require("../../assets/data/col.json"),
  "1th": require("../../assets/data/1th.json"),
  "2th": require("../../assets/data/2th.json"),
  "1ti": require("../../assets/data/1ti.json"),
  "2ti": require("../../assets/data/2ti.json"),
  tit: require("../../assets/data/tit.json"),
  phm: require("../../assets/data/phm.json"),
  heb: require("../../assets/data/heb.json"),
  jas: require("../../assets/data/jas.json"),
  "1pe": require("../../assets/data/1pe.json"),
  "2pe": require("../../assets/data/2pe.json"),
  "1jn": require("../../assets/data/1jn.json"),
  "2jn": require("../../assets/data/2jn.json"),
  "3jn": require("../../assets/data/3jn.json"),
  jud: require("../../assets/data/jud.json"),
  rev: require("../../assets/data/rev.json"),
};

const BOOKS: any[] = require("../../assets/data/books.json");
const META: any = require("../../assets/data/meta.json");

// --- Public accessors mirroring the backend REST shape ---
export function listBooks() {
  return BOOKS.map((b: any) => ({
    id: b.book_id,
    name_en: b.name_en,
    name_ar: b.name_ar,
    testament: b.testament,
    total_chapters: b.total_chapters,
  }));
}

export function getChapter(bookId: string, chapter: number) {
  const book = BOOKS.find((b: any) => b.book_id === bookId);
  const raw = BOOK_JSON[bookId];
  if (!book || !raw) throw new Error("Book not found");
  const verses = raw[String(chapter)];
  if (!verses) throw new Error("Chapter not found");
  return {
    book_id: bookId,
    book_name_en: book.name_en,
    book_name_ar: book.name_ar,
    testament: book.testament,
    chapter,
    verses: verses.map((v: any) => ({ number: v.n, ar: v.ar, en: v.en })),
    total_chapters: book.total_chapters,
    sections: (META.sections?.[bookId] || {})[String(chapter)] || [],
  };
}

export function getVerseDetail(bookId: string, chapter: number, verse: number) {
  const chData = getChapter(bookId, chapter);
  const v = chData.verses.find((x: any) => x.number === verse);
  if (!v) throw new Error("Verse not found");
  const refs = (META.cross_refs?.[bookId] || {})[String(chapter)]?.[String(verse)] || [];
  const words = (META.words?.[bookId] || {})[String(chapter)]?.[String(verse)] || [];
  const placeIds = (META.verse_places?.[bookId] || {})[String(chapter)]?.[String(verse)] || [];
  const places = (META.places || []).filter((p: any) => placeIds.includes(p.id));
  return {
    book_id: bookId,
    book_name_en: chData.book_name_en,
    book_name_ar: chData.book_name_ar,
    chapter,
    verse: v,
    cross_refs: refs,
    words,
    places,
  };
}

export function getVerseOfDay() {
  const daily = META.daily_verses || [];
  if (!daily.length) throw new Error("No daily verses");
  const dayIdx = Math.floor(Date.now() / 86400000) % daily.length;
  const ref = daily[dayIdx];
  const ch = getChapter(ref.book_id, ref.chapter);
  const verse = ch.verses.find((v: any) => v.number === ref.verse);
  return {
    book_id: ref.book_id,
    book_name_en: ch.book_name_en,
    book_name_ar: ch.book_name_ar,
    chapter: ref.chapter,
    verse,
  };
}

// ---- Memoized normalized search index (built lazily on first use) ----
type SearchEntry = {
  book_id: string;
  chapter: number;
  n: number;
  ar: string;
  en: string;
  ar_n: string;
  en_n: string;
};
let _searchIndex: SearchEntry[] | null = null;

function _buildIndex(): SearchEntry[] {
  if (_searchIndex) return _searchIndex;
  const idx: SearchEntry[] = [];
  for (const [bookId, chData] of Object.entries(BOOK_JSON)) {
    for (const chStr of Object.keys(chData as any)) {
      const chapter = parseInt(chStr, 10);
      const verses = (chData as any)[chStr] as any[];
      for (const v of verses) {
        idx.push({
          book_id: bookId,
          chapter,
          n: v.n,
          ar: v.ar || "",
          en: v.en || "",
          ar_n: normalize(v.ar || "", "ar"),
          en_n: normalize(v.en || "", "en"),
        });
      }
    }
  }
  _searchIndex = idx;
  return idx;
}

export function searchBible(q: string, lang: "en" | "ar" = "ar") {
  if (!q || q.trim().length < 2) return { results: [] };
  const needle = normalize(q, lang);
  const out: any[] = [];
  const bookMap = Object.fromEntries(BOOKS.map((b: any) => [b.book_id, b]));
  const idx = _buildIndex();
  const field: "ar_n" | "en_n" = lang === "ar" ? "ar_n" : "en_n";
  for (const e of idx) {
    if (e[field].includes(needle)) {
      const book = bookMap[e.book_id];
      out.push({
        book_id: e.book_id,
        book_name_en: book?.name_en || e.book_id,
        book_name_ar: book?.name_ar || "",
        chapter: e.chapter,
        verse: e.n,
        ar: e.ar,
        en: e.en,
      });
      if (out.length >= 50) break;
    }
  }
  return { results: out };
}

function normalize(s: string, lang: "en" | "ar"): string {
  if (lang === "en") return s.toLowerCase();
  return s
    .replace(/[\u064B-\u0652\u0670\u0640\u06D6-\u06ED]/g, "") // diacritics
    .replace(/[\u0623\u0625\u0622]/g, "\u0627")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0629/g, "\u0647")
    .toLowerCase();
}

export function getPlaces() {
  return { places: META.places || [] };
}

export function getReadingPlans() {
  return { plans: META.reading_plans || [] };
}

export function getChurch() {
  return META.church || {};
}
