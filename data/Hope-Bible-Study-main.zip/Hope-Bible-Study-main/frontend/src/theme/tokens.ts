/**
 * Hope Church Sydney — Design tokens
 * Royal Blue • Deep Red • Gold • White
 */

export const light = {
  surface: '#FFFFFF',
  onSurface: '#0F1419',
  surfaceSecondary: '#F7F9FC',
  onSurfaceSecondary: '#2D3748',
  surfaceTertiary: '#EDF2F7',
  onSurfaceTertiary: '#4A5568',
  surfaceInverse: '#0A0D14',
  onSurfaceInverse: '#FFFFFF',

  brand: '#002366',        // Royal Blue (deep)
  brandPrimary: '#0033A0', // Royal Blue
  onBrandPrimary: '#FFFFFF',
  brandSecondary: '#9B111E', // Deep Red
  onBrandSecondary: '#FFFFFF',
  brandTertiary: '#D4AF37',  // Gold
  onBrandTertiary: '#0A0D14',

  success: '#2D7A4A',
  warning: '#B7791F',
  error: '#C53030',
  info: '#2B6CB0',

  border: '#E2E8F0',
  borderStrong: '#CBD5E0',
  divider: '#EDF2F7',

  highlightGold: 'rgba(212, 175, 55, 0.28)',
  highlightBlue: 'rgba(0, 51, 160, 0.16)',
  highlightRed: 'rgba(155, 17, 30, 0.16)',
  highlightGreen: 'rgba(45, 122, 74, 0.18)',
};

export const dark = {
  surface: '#050814',
  onSurface: '#F7FAFC',
  surfaceSecondary: '#0F1626',
  onSurfaceSecondary: '#E2E8F0',
  surfaceTertiary: '#1A2436',
  onSurfaceTertiary: '#CBD5E0',
  surfaceInverse: '#FFFFFF',
  onSurfaceInverse: '#050814',

  brand: '#002366',
  brandPrimary: '#2D68FF',
  onBrandPrimary: '#FFFFFF',
  brandSecondary: '#D32F2F',
  onBrandSecondary: '#FFFFFF',
  brandTertiary: '#F1D570',
  onBrandTertiary: '#050814',

  success: '#48BB78',
  warning: '#F6AD55',
  error: '#FC8181',
  info: '#63B3ED',

  border: '#2D3748',
  borderStrong: '#4A5568',
  divider: '#1A202C',

  highlightGold: 'rgba(241, 213, 112, 0.24)',
  highlightBlue: 'rgba(45, 104, 255, 0.24)',
  highlightRed: 'rgba(211, 47, 47, 0.24)',
  highlightGreen: 'rgba(72, 187, 120, 0.22)',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 6,
  md: 12,
  lg: 20,
  pill: 999,
};

export const type = {
  sm: 12,
  base: 14,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  display: 40,
};

// Native serif fallbacks that carry an editorial feel
export const fonts = {
  display: 'Georgia',    // display serif
  serif: 'Georgia',
  body: 'System',
  arabic: 'System',
};
