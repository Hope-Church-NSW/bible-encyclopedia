import { useColorScheme } from 'react-native';
import { light, dark } from './tokens';

export function useTheme() {
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  return {
    isDark,
    c: isDark ? dark : light,
  };
}
