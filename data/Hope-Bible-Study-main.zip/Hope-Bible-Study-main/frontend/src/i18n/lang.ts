import { useEffect, useState, useCallback } from "react";
import { storage } from "@/src/utils/storage";

export type Lang = "ar" | "en";

const KEY = "hcs-lang";
let cached: Lang | null = null;
const listeners = new Set<(lang: Lang) => void>();

export async function getLang(): Promise<Lang> {
  if (cached) return cached;
  const saved = await storage.getItem<Lang>(KEY, "ar");
  cached = saved === "en" ? "en" : "ar";
  return cached;
}

export async function setLang(lang: Lang): Promise<void> {
  cached = lang;
  await storage.setItem(KEY, lang);
  listeners.forEach((l) => l(lang));
}

/** React hook that returns the current UI language and lets you switch it. */
export function useLang(): [Lang, (l: Lang) => Promise<void>] {
  const [lang, set] = useState<Lang>(cached ?? "ar");

  useEffect(() => {
    let mounted = true;
    if (!cached) getLang().then((l) => mounted && set(l));
    const listener = (l: Lang) => mounted && set(l);
    listeners.add(listener);
    return () => {
      mounted = false;
      listeners.delete(listener);
    };
  }, []);

  const change = useCallback(async (l: Lang) => {
    await setLang(l);
  }, []);

  return [lang, change];
}

/** Convenience helper. Pass either an object {en, ar} or two args. */
export function t(strings: { en: string; ar: string }, lang: Lang): string {
  return strings[lang];
}
