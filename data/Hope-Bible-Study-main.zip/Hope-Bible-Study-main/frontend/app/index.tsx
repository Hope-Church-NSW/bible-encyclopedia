import { useEffect, useRef } from "react";
import { View, Text, StyleSheet, Animated, Easing } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";

import { light } from "@/src/theme/tokens";

export default function Splash() {
  const router = useRouter();
  const scale = useRef(new Animated.Value(0.85)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const rays = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.spring(scale, {
          toValue: 1,
          friction: 6,
          tension: 40,
          useNativeDriver: true,
        }),
      ]),
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();

    Animated.loop(
      Animated.timing(rays, {
        toValue: 1,
        duration: 12000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();

    const t = setTimeout(() => router.replace("/(tabs)/home"), 2600);
    return () => clearTimeout(t);
  }, [opacity, scale, textOpacity, rays, router]);

  const spin = rays.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  return (
    <View style={styles.container} testID="splash-screen">
      <LinearGradient
        colors={[light.brand, light.brandPrimary, "#01123f"]}
        style={StyleSheet.absoluteFill}
      />
      <Animated.View
        style={[
          styles.logoWrap,
          { opacity, transform: [{ scale }] },
        ]}
      >
        <Animated.View style={{ transform: [{ rotate: spin }] }}>
          <View style={styles.glow} />
        </Animated.View>
        <Image
          source={require("../assets/images/brand/hope-church-logo.png")}
          style={styles.logo}
          contentFit="contain"
          testID="splash-logo"
        />
      </Animated.View>

      <Animated.View style={[styles.textBlock, { opacity: textOpacity }]}>
        <Text style={styles.title}>Hope Church Sydney</Text>
        <Text style={styles.titleAr}>كنيسة رجاء الأمم – سيدني</Text>
        <View style={styles.divider} />
        <Text style={styles.subtitle}>AI Bible Study Platform</Text>
        <Text style={styles.poweredBy}>Powered by Hope Church Sydney</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  logoWrap: {
    width: 220,
    height: 220,
    alignItems: "center",
    justifyContent: "center",
  },
  glow: {
    position: "absolute",
    width: 260,
    height: 260,
    borderRadius: 130,
    backgroundColor: "rgba(212, 175, 55, 0.16)",
    top: -20,
    left: -20,
  },
  logo: {
    width: 220,
    height: 220,
  },
  textBlock: {
    marginTop: 32,
    alignItems: "center",
    paddingHorizontal: 24,
  },
  title: {
    fontFamily: "Georgia",
    fontSize: 26,
    fontWeight: "700",
    color: "#FFFFFF",
    letterSpacing: 0.5,
    textAlign: "center",
  },
  titleAr: {
    fontSize: 20,
    color: "#F1D570",
    marginTop: 6,
    fontWeight: "600",
    textAlign: "center",
  },
  divider: {
    width: 80,
    height: 2,
    backgroundColor: "#D4AF37",
    marginVertical: 16,
    borderRadius: 1,
  },
  subtitle: {
    fontSize: 15,
    color: "rgba(255,255,255,0.85)",
    letterSpacing: 1.5,
    textTransform: "uppercase",
    fontWeight: "600",
  },
  poweredBy: {
    marginTop: 20,
    fontSize: 12,
    color: "rgba(255,255,255,0.6)",
    letterSpacing: 0.5,
    fontStyle: "italic",
  },
});
