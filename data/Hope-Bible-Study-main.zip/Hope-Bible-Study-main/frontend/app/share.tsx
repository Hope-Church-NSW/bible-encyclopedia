import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Share,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

const SHARE_URL =
  (typeof process !== "undefined" &&
    (process.env as any)?.EXPO_PUBLIC_BACKEND_URL) ||
  "https://hope-bible-study.preview.emergentagent.com";

const SHARE_MSG_EN =
  "Hope Church Sydney — AI Bible Study App. Read the Bible in Arabic & English, study with AI, and connect with the church. Download / open:";
const SHARE_MSG_AR =
  "كنيسة رجاء الأمم – سيدني | تطبيق الكتاب المقدس بالذكاء الاصطناعي. اقرأ الكتاب المقدس بالعربية والإنجليزية، وادرس بمساعدة الذكاء الاصطناعي، وتواصل مع الكنيسة. حمّل / افتح:";

export default function ShareScreen() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const router = useRouter();

  const doShare = async () => {
    try {
      Haptics.selectionAsync();
      const message = `${SHARE_MSG_EN}\n${SHARE_URL}\n\n${SHARE_MSG_AR}\n${SHARE_URL}`;
      if (Platform.OS === "web") {
        // Web fallback: use Navigator.share if available, else copy to clipboard
        const nav: any = typeof navigator !== "undefined" ? navigator : null;
        if (nav?.share) {
          await nav.share({
            title: "Hope Church Sydney Bible",
            text: message,
            url: SHARE_URL,
          });
        } else if (nav?.clipboard?.writeText) {
          await nav.clipboard.writeText(SHARE_URL);
        }
        return;
      }
      await Share.share({
        message,
        url: SHARE_URL,
        title: "Hope Church Sydney Bible",
      });
    } catch (e) {
      console.log("share err", e);
    }
  };

  const copyLink = async () => {
    Haptics.selectionAsync();
    if (Platform.OS === "web") {
      const nav: any = typeof navigator !== "undefined" ? navigator : null;
      if (nav?.clipboard?.writeText) {
        await nav.clipboard.writeText(SHARE_URL);
      }
    } else {
      // On native, share() with just URL works as effective copy
      await Share.share({ message: SHARE_URL });
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: c.surface }}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm, borderBottomColor: c.divider }]}>
        <Pressable
          onPress={() => router.back()}
          style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary }]}
          testID="share-back-btn"
        >
          <Feather name="chevron-left" size={20} color={c.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.onSurface }]}>Share the App</Text>
          <Text style={[styles.subtitle, { color: c.onSurfaceSecondary }]}>شارك التطبيق</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
        {/* QR card */}
        <View style={styles.qrCard} testID="share-qr-card">
          <LinearGradient
            colors={[c.brand, c.brandPrimary, "#01123f"]}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.qrBadge}>
            <Feather name="feather" size={10} color="#0A0D14" />
            <Text style={styles.qrBadgeTxt}>OFFICIAL QR</Text>
          </View>

          <View style={styles.qrWrap}>
            <Image
              source={require("../assets/images/brand/share-qr.jpg")}
              style={styles.qr}
              contentFit="contain"
              testID="share-qr-image"
            />
          </View>

          <Text style={styles.qrHint}>Scan to open the app</Text>
          <Text style={styles.qrHintAr}>امسح لفتح التطبيق</Text>

          <View style={styles.brandLine}>
            <View style={styles.gold} />
            <Text style={styles.brandTxt}>Hope Church Sydney · كنيسة رجاء الأمم</Text>
            <View style={styles.gold} />
          </View>
        </View>

        {/* Share URL card */}
        <View style={[styles.linkCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
          <View style={styles.linkRow}>
            <Feather name="link" size={16} color={c.brandTertiary} />
            <Text style={[styles.linkLabel, { color: c.onSurfaceTertiary }]}>APP URL</Text>
          </View>
          <Text style={[styles.linkText, { color: c.onSurface }]} numberOfLines={2} selectable testID="share-url-text">
            {SHARE_URL}
          </Text>
          <View style={styles.actionsRow}>
            <Pressable
              onPress={copyLink}
              style={[styles.actionBtn, { backgroundColor: c.surfaceTertiary, borderColor: c.border }]}
              testID="share-copy-btn"
            >
              <Feather name="copy" size={15} color={c.onSurface} />
              <Text style={{ color: c.onSurface, fontWeight: "700", fontSize: 13 }}>Copy Link</Text>
            </Pressable>
            <Pressable
              onPress={doShare}
              style={[styles.actionBtn, { backgroundColor: c.brand, borderColor: c.brand, flex: 1.4 }]}
              testID="share-native-btn"
            >
              <Feather name="share-2" size={15} color="#FFFFFF" />
              <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 13 }}>Share App</Text>
            </Pressable>
          </View>
        </View>

        {/* Suggested channels */}
        <Text style={[styles.sectionLabel, { color: c.onSurfaceTertiary }]}>SHARE WITH</Text>
        <View style={styles.suggested}>
          <ChannelChip icon="message-circle" label="WhatsApp" color="#25D366" onPress={doShare} testID="ch-whatsapp" />
          <ChannelChip icon="send" label="Telegram" color="#0088CC" onPress={doShare} testID="ch-telegram" />
          <ChannelChip icon="facebook" label="Facebook" color="#1877F2" onPress={doShare} testID="ch-facebook" />
          <ChannelChip icon="mail" label="Email" color={c.brandSecondary} onPress={doShare} testID="ch-email" />
        </View>

        {/* Footer */}
        <View style={{ alignItems: "center", marginTop: spacing.xl }}>
          <Image
            source={require("../assets/images/brand/hope-church-logo.png")}
            style={styles.footerLogo}
            contentFit="contain"
          />
          <Text style={[styles.footerPowered, { color: c.onSurfaceTertiary }]}>
            Produced and Sponsored by{"\n"}
            <Text style={{ color: c.onSurfaceSecondary, fontWeight: "700" }}>
              Hope Church Sydney · كنيسة رجاء الأمم
            </Text>
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function ChannelChip({
  icon,
  label,
  color,
  onPress,
  testID,
}: {
  icon: any;
  label: string;
  color: string;
  onPress: () => void;
  testID: string;
}) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[styles.channel, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
      testID={testID}
    >
      <View style={[styles.channelIcon, { backgroundColor: color }]}>
        <Feather name={icon} size={16} color="#FFFFFF" />
      </View>
      <Text style={[styles.channelLabel, { color: c.onSurface }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  title: { fontSize: 22, fontWeight: "700", fontFamily: "Georgia" },
  subtitle: { fontSize: 12, marginTop: 2 },

  qrCard: {
    borderRadius: radius.lg,
    padding: spacing.xl,
    alignItems: "center",
    overflow: "hidden",
    marginBottom: spacing.xl,
  },
  qrBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    alignSelf: "flex-start",
    backgroundColor: "#F1D570",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radius.pill,
    marginBottom: spacing.lg,
  },
  qrBadgeTxt: { fontSize: 10, fontWeight: "800", color: "#0A0D14", letterSpacing: 1 },
  qrWrap: {
    width: 220,
    height: 220,
    backgroundColor: "#FFFFFF",
    borderRadius: radius.md,
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    borderWidth: 3,
    borderColor: "#F1D570",
  },
  qr: { width: "100%", height: "100%" },
  qrHint: { color: "#FFFFFF", fontSize: 15, fontFamily: "Georgia", fontWeight: "700", marginTop: spacing.lg },
  qrHintAr: { color: "#F1D570", fontSize: 13, marginTop: 4, fontWeight: "600" },

  brandLine: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: spacing.lg,
    width: "100%",
    justifyContent: "center",
  },
  gold: { flex: 1, height: 1, backgroundColor: "rgba(212,175,55,0.5)" },
  brandTxt: { color: "rgba(255,255,255,0.85)", fontSize: 10, fontWeight: "700", letterSpacing: 0.5 },

  linkCard: {
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    padding: spacing.md,
    marginBottom: spacing.xl,
  },
  linkRow: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 6 },
  linkLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  linkText: { fontSize: 13, fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace", marginBottom: spacing.md },
  actionsRow: { flexDirection: "row", gap: spacing.sm },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },

  sectionLabel: { fontSize: 11, fontWeight: "800", letterSpacing: 1.5, marginBottom: spacing.sm },
  suggested: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  channel: {
    flexBasis: "48%",
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  channelIcon: {
    width: 32,
    height: 32,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  channelLabel: { fontSize: 13, fontWeight: "700" },

  footerLogo: { width: 48, height: 48, marginBottom: spacing.sm },
  footerPowered: { fontSize: 11, textAlign: "center", lineHeight: 18, fontStyle: "italic" },
});
