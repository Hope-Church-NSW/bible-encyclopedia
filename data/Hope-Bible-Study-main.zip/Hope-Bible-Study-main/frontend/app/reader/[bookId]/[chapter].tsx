import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
  Linking,
  Platform,
  Share,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";
import { storage } from "@/src/utils/storage";

type Verse = { number: number; ar: string; en: string };
type Section = { start: number; end: number; title_en: string; title_ar: string };
type Chapter = {
  book_id: string;
  book_name_en: string;
  book_name_ar: string;
  chapter: number;
  verses: Verse[];
  total_chapters: number;
  sections: Section[];
};

type Mode = "parallel" | "en" | "ar";

export default function Reader() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const router = useRouter();
  const { bookId, chapter } = useLocalSearchParams<{ bookId: string; chapter: string }>();
  const chNum = parseInt(chapter || "1", 10);

  const [ch, setCh] = useState<Chapter | null>(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<Mode>("parallel");  const [selected, setSelected] = useState<Verse | null>(null);
  const [verseDetail, setVerseDetail] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailTab, setDetailTab] = useState<"tafsir" | "refs" | "words" | "place" | "actions">("tafsir");
  const [tafsirAuthor, setTafsirAuthor] = useState<string>("matta");
  const [tafsirBody, setTafsirBody] = useState<string>("");
  const [tafsirLoading, setTafsirLoading] = useState(false);
  const [tafsirAuthorMeta, setTafsirAuthorMeta] = useState<any>(null);
  const [enriching, setEnriching] = useState(false);
  const [highlights, setHighlights] = useState<Record<number, { id: string; color: string }>>({});
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [noteText, setNoteText] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.chapter(bookId!, chNum);
      setCh(data);
    } catch (e: any) {
      Alert.alert("Chapter not available", "This chapter is not yet loaded. Try another chapter.");
      console.log("chapter err", e);
    } finally {
      setLoading(false);
    }
  }, [bookId, chNum]);

  // Load persisted highlights for this chapter
  const loadHighlights = useCallback(async () => {
    if (!bookId) return;
    try {
      const all = await api.highlights();
      const forChapter: Record<number, { id: string; color: string }> = {};
      for (const h of all) {
        if (h.book_id === bookId && h.chapter === chNum) {
          forChapter[h.verse] = { id: h.id, color: h.color || "gold" };
        }
      }
      setHighlights(forChapter);
    } catch (e) {
      console.log("highlights err", e);
    }
  }, [bookId, chNum]);

  useEffect(() => {
    load();
    loadHighlights();
  }, [load, loadHighlights]);

  // Persist reading mode across sessions
  useEffect(() => {
    (async () => {
      const saved = await storage.getItem<string>("reader-mode", "parallel");
      if (saved === "parallel" || saved === "en" || saved === "ar") {
        setMode(saved);
      }
    })();
  }, []);

  const changeMode = (m: Mode) => {
    setMode(m);
    storage.setItem("reader-mode", m);
    Haptics.selectionAsync();
  };

  const openAudio = async () => {
    if (!ch) return;
    try {
      Haptics.selectionAsync();
      const audio = await api.audio(ch.book_id, ch.chapter);
      if (audio?.url) Linking.openURL(audio.url).catch(() => {});
    } catch (e) {
      console.log("audio err", e);
    }
  };

  const openVerse = (v: Verse) => {
    Haptics.selectionAsync();
    setSelected(v);
    setDetailTab("tafsir");
    setVerseDetail(null);
    setTafsirBody("");
    if (ch) {
      setDetailLoading(true);
      api
        .verseDetail(ch.book_id, ch.chapter, v.number)
        .then((d) => setVerseDetail(d))
        .catch((e) => console.log("verse detail err", e))
        .finally(() => setDetailLoading(false));
      // Preload the default tafsir
      loadTafsir(v, tafsirAuthor);
    }
  };

  const loadTafsir = useCallback(async (v: Verse, author: string) => {
    if (!ch) return;
    const cacheKey = `tafsir:${ch.book_id}:${ch.chapter}:${v.number}:${author}`;
    setTafsirLoading(true);
    setTafsirBody("");

    // 1) Try local cache first — INSTANT display
    try {
      const cached = await storage.getItem<any>(cacheKey, null);
      if (cached && cached.body_ar) {
        setTafsirBody(cached.body_ar);
        setTafsirAuthorMeta({
          name_ar: cached.author_name_ar,
          name_en: cached.author_name_en,
          tradition_ar: cached.tradition_ar,
          disclaimer_ar: cached.disclaimer_ar,
        });
        setTafsirLoading(false);
        return; // done — no network call needed
      }
    } catch {}

    try {
      const r = await api.commentary(ch.book_id, ch.chapter, v.number, author);
      setTafsirBody(r.body_ar);
      setTafsirAuthorMeta({
        name_ar: r.author_name_ar,
        name_en: r.author_name_en,
        tradition_ar: r.tradition_ar,
        disclaimer_ar: r.disclaimer_ar,
      });
      // Persist locally for instant future access
      storage.setItem(cacheKey, {
        body_ar: r.body_ar,
        author_name_ar: r.author_name_ar,
        author_name_en: r.author_name_en,
        tradition_ar: r.tradition_ar,
        disclaimer_ar: r.disclaimer_ar,
      }).catch(() => {});
    } catch (e: any) {
      const msg = String(e?.message || "");
      setTafsirBody(
        msg.includes("429")
          ? "لقد تجاوزت الحد المسموح مؤقتاً. الرجاء المحاولة لاحقاً."
          : "تعذّر جلب التفسير الآن. الرجاء المحاولة مرة أخرى."
      );
    } finally {
      setTafsirLoading(false);
    }
  }, [ch]);

  const doEnrich = async () => {
    if (!selected || !ch || enriching) return;
    const cacheKey = `enrich:${ch.book_id}:${ch.chapter}:${selected.number}`;

    // 1) Try local cache first
    try {
      const cached = await storage.getItem<any>(cacheKey, null);
      if (cached && (cached.cross_refs || cached.words)) {
        setVerseDetail((prev: any) => ({
          ...(prev || { places: [] }),
          cross_refs: cached.cross_refs || [],
          words: cached.words || [],
        }));
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        return;
      }
    } catch {}

    try {
      setEnriching(true);
      Haptics.selectionAsync();
      const r = await api.enrichVerse(ch.book_id, ch.chapter, selected.number);
      setVerseDetail((prev: any) => ({
        ...(prev || { places: [] }),
        cross_refs: r.cross_refs || [],
        words: r.words || [],
      }));
      storage.setItem(cacheKey, {
        cross_refs: r.cross_refs || [],
        words: r.words || [],
      }).catch(() => {});
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      console.log("enrich err", e);
    } finally {
      setEnriching(false);
    }
  };

  const doHighlight = async (color: string) => {
    if (!selected || !ch) return;
    try {
      // if verse already highlighted, remove existing before adding new color
      const existing = highlights[selected.number];
      if (existing) {
        await api.removeHighlight(existing.id);
      }
      const created: any = await api.addHighlight({
        book_id: ch.book_id,
        chapter: ch.chapter,
        verse: selected.number,
        color,
      });
      setHighlights({
        ...highlights,
        [selected.number]: { id: created.id, color },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSelected(null);
    } catch (e) {
      console.log(e);
    }
  };

  const doRemoveHighlight = async () => {
    if (!selected) return;
    const existing = highlights[selected.number];
    if (!existing) return;
    try {
      await api.removeHighlight(existing.id);
      const next = { ...highlights };
      delete next[selected.number];
      setHighlights(next);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      setSelected(null);
    } catch (e) {
      console.log(e);
    }
  };

  const doShare = async () => {
    if (!selected || !ch) return;
    try {
      Haptics.selectionAsync();
      const url =
        (typeof process !== "undefined" && (process.env as any)?.EXPO_PUBLIC_BACKEND_URL) ||
        "https://hope-bible-study.preview.emergentagent.com";
      const message =
        `"${selected.en}"\n— ${ch.book_name_en} ${ch.chapter}:${selected.number}\n\n` +
        `«${selected.ar}»\n— ${ch.book_name_ar} ${ch.chapter}:${selected.number}\n\n` +
        `Hope Church Sydney Bible · ${url}/reader/${ch.book_id}/${ch.chapter}`;
      if (Platform.OS === "web") {
        const nav: any = typeof navigator !== "undefined" ? navigator : null;
        if (nav?.share) {
          await nav.share({ text: message, title: `${ch.book_name_en} ${ch.chapter}:${selected.number}` });
        } else if (nav?.clipboard?.writeText) {
          await nav.clipboard.writeText(message);
        }
      } else {
        await Share.share({ message });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      console.log("verse share err", e);
    }
  };

  const doBookmark = async () => {
    if (!selected || !ch) return;
    try {
      await api.addBookmark({
        book_id: ch.book_id,
        chapter: ch.chapter,
        verse: selected.number,
        label: `${ch.book_name_en} ${ch.chapter}:${selected.number}`,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSelected(null);
    } catch (e) {
      console.log(e);
    }
  };

  const doAskAI = () => {
    if (!selected || !ch) return;
    router.push({
      pathname: "/(tabs)/ai",
      params: {
        seed: `Please explain ${ch.book_name_en} ${ch.chapter}:${selected.number} — "${selected.en}"`,
      },
    });
    setSelected(null);
  };

  const doSaveNote = async () => {
    if (!selected || !ch || !noteText.trim()) return;
    try {
      await api.addNote({
        book_id: ch.book_id,
        chapter: ch.chapter,
        verse: selected.number,
        text: noteText.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setNoteText("");
      setShowNoteModal(false);
      setSelected(null);
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <View style={[styles.root, { backgroundColor: c.surface }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + spacing.sm, backgroundColor: c.surface, borderBottomColor: c.divider },
        ]}
      >
        <Pressable
          onPress={() => router.back()}
          style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary }]}
          testID="reader-back-btn"
        >
          <Feather name="chevron-left" size={20} color={c.onSurface} />
        </Pressable>
        <View style={{ flex: 1, alignItems: "center" }}>
          <Text style={[styles.headerTitle, { color: c.onSurface }]}>
            {ch ? `${ch.book_name_en} ${ch.chapter}` : "Loading…"}
          </Text>
          {ch && (
            <Text style={[styles.headerTitleAr, { color: c.onSurfaceSecondary }]}>
              {ch.book_name_ar} {ch.chapter}
            </Text>
          )}
        </View>
        <Pressable
          onPress={openAudio}
          style={[styles.iconBtn, { backgroundColor: c.brandSecondary }]}
          testID="reader-audio-btn"
        >
          <Feather name="headphones" size={18} color="#FFFFFF" />
        </Pressable>
      </View>

      {/* Mode chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}
        style={{ backgroundColor: c.surface }}
      >
        {(["parallel", "en", "ar"] as Mode[]).map((m) => (
          <Pressable
            key={m}
            onPress={() => changeMode(m)}
            testID={`mode-${m}`}
            style={[
              styles.chip,
              {
                backgroundColor: mode === m ? c.brand : c.surfaceSecondary,
                borderColor: mode === m ? c.brand : c.border,
              },
            ]}
          >
            <Text style={{ color: mode === m ? "#FFFFFF" : c.onSurfaceSecondary, fontWeight: "700", fontSize: 12 }}>
              {m === "parallel" ? "Parallel · متوازي" : m === "en" ? "English (WEB)" : "العربية (فاندايك)"}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={c.brandTertiary} />
        </View>
      ) : ch ? (
        <ScrollView
          contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}
        >
          {ch.verses.map((v) => {
            const hl = highlights[v.number];
            const bgColor = hl
              ? hl.color === "blue"
                ? c.highlightBlue
                : hl.color === "red"
                ? c.highlightRed
                : hl.color === "green"
                ? c.highlightGreen
                : c.highlightGold
              : undefined;
            const section = (ch.sections || []).find((s) => s.start === v.number);
            return (
              <View key={v.number}>
                {section && (
                  <View style={styles.sectionHead} testID={`section-${section.start}`}>
                    <View style={[styles.sectionLine, { backgroundColor: c.brandTertiary }]} />
                    <View>
                      <Text style={[styles.sectionTitle, { color: c.brand }]}>
                        {section.title_en}
                      </Text>
                      <Text style={[styles.sectionTitleAr, { color: c.brandTertiary }]}>
                        {section.title_ar}
                      </Text>
                    </View>
                  </View>
                )}
                <Pressable
                  onPress={() => openVerse(v)}
                  style={[
                    styles.verseBlock,
                    bgColor ? { backgroundColor: bgColor } : null,
                  ]}
                  testID={`verse-${v.number}`}
                >
              {mode !== "en" && (
                <View style={styles.verseLine}>
                  <Text style={[styles.verseNumAr, { color: c.brandTertiary }]}>{v.number}</Text>
                  <Text
                    style={[
                      styles.verseAr,
                      { color: c.onSurface },
                    ]}
                  >
                    {v.ar}
                  </Text>
                </View>
              )}
              {mode !== "ar" && (
                <View style={[styles.verseLine, mode === "parallel" && { marginTop: spacing.sm }]}>
                  <Text style={[styles.verseNumEn, { color: c.brandTertiary }]}>{v.number}</Text>
                  <Text
                    style={[
                      styles.verseEn,
                      { color: c.onSurface },
                    ]}
                  >
                    {v.en}
                  </Text>
                </View>
              )}
              {mode === "parallel" && v.number !== ch.verses[ch.verses.length - 1].number && (
                <View style={[styles.verseDivider, { backgroundColor: c.divider }]} />
              )}
            </Pressable>
              </View>
          );
          })}

          <View style={styles.chapterNav}>
            {chNum > 1 && (
              <Pressable
                onPress={() => router.replace(`/reader/${bookId}/${chNum - 1}`)}
                style={[styles.navBtn, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
              >
                <Feather name="chevron-left" size={16} color={c.onSurface} />
                <Text style={{ color: c.onSurface, fontWeight: "600" }}>Previous</Text>
              </Pressable>
            )}
            <View style={{ flex: 1 }} />
            {chNum < ch.total_chapters && (
              <Pressable
                onPress={() => router.replace(`/reader/${bookId}/${chNum + 1}`)}
                style={[styles.navBtn, { backgroundColor: c.brand }]}
              >
                <Text style={{ color: "#FFFFFF", fontWeight: "600" }}>Next</Text>
                <Feather name="chevron-right" size={16} color="#FFFFFF" />
              </Pressable>
            )}
          </View>
        </ScrollView>
      ) : (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}>
          <Text style={{ color: c.onSurfaceTertiary, textAlign: "center" }}>
            Chapter not available yet. Try another chapter or book.
          </Text>
        </View>
      )}

      {/* Verse action sheet */}
      <Modal
        visible={!!selected}
        transparent
        animationType="fade"
        onRequestClose={() => setSelected(null)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setSelected(null)}
        >
          <Pressable
            style={[styles.sheet, { backgroundColor: c.surface, borderColor: c.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.sheetHandle} />
            {selected && ch && (
              <>
                <Text style={[styles.sheetRef, { color: c.brandTertiary }]}>
                  {ch.book_name_en} {ch.chapter}:{selected.number}  ·  {ch.book_name_ar} {ch.chapter}:{selected.number}
                </Text>
                <Text style={[styles.sheetVerse, { color: c.onSurface }]} numberOfLines={4}>
                  {`\u201C${selected.en}\u201D`}
                </Text>

                {/* Sheet tabs — Arabic */}
                <View style={[styles.sheetTabs, { borderColor: c.divider }]}>
                  {([
                    { k: "tafsir", i: "book-open", l: "تفسير" },
                    { k: "refs", i: "link-2", l: "شواهد" },
                    { k: "words", i: "type", l: "مقارنة" },
                    { k: "place", i: "map-pin", l: "أماكن" },
                    { k: "actions", i: "edit-3", l: "أدوات" },
                  ] as const).map((t) => (
                    <Pressable
                      key={t.k}
                      onPress={() => {
                        setDetailTab(t.k);
                        if (t.k === "tafsir" && !tafsirBody && !tafsirLoading && selected) {
                          loadTafsir(selected, tafsirAuthor);
                        }
                      }}
                      style={[
                        styles.sheetTab,
                        detailTab === t.k && { borderBottomColor: c.brandTertiary },
                      ]}
                      testID={`sheet-tab-${t.k}`}
                    >
                      <Feather
                        name={t.i as any}
                        size={13}
                        color={detailTab === t.k ? c.brandTertiary : c.onSurfaceTertiary}
                      />
                      <Text
                        style={{
                          color: detailTab === t.k ? c.onSurface : c.onSurfaceTertiary,
                          fontWeight: "700",
                          fontSize: 11,
                          marginTop: 3,
                        }}
                      >
                        {t.l}
                      </Text>
                    </Pressable>
                  ))}
                </View>

                <View style={{ maxHeight: 340 }}>
                  <ScrollView>
                    {detailTab === "tafsir" && (
                      <View style={{ paddingTop: spacing.sm }}>
                        {/* Author picker */}
                        <ScrollView
                          horizontal
                          showsHorizontalScrollIndicator={false}
                          contentContainerStyle={{ gap: 6, paddingBottom: spacing.md }}
                        >
                          {[
                            { id: "matta", label: "متى المسكين" },
                            { id: "menes", label: "منيس عبد النور" },
                            { id: "macdonald", label: "وليم مكدونالد" },
                            { id: "newton", label: "بنيامين بنكترتن" },
                            { id: "kelly", label: "وليم أدي" },
                          ].map((a) => (
                            <Pressable
                              key={a.id}
                              onPress={() => {
                                setTafsirAuthor(a.id);
                                if (selected) loadTafsir(selected, a.id);
                              }}
                              testID={`tafsir-author-${a.id}`}
                              style={[
                                styles.authorChip,
                                {
                                  backgroundColor: tafsirAuthor === a.id ? c.brand : c.surfaceSecondary,
                                  borderColor: tafsirAuthor === a.id ? c.brand : c.border,
                                },
                              ]}
                            >
                              <Text
                                style={{
                                  color: tafsirAuthor === a.id ? "#FFFFFF" : c.onSurfaceSecondary,
                                  fontWeight: "700",
                                  fontSize: 12,
                                }}
                              >
                                {a.label}
                              </Text>
                            </Pressable>
                          ))}
                        </ScrollView>

                        {tafsirAuthorMeta && !tafsirLoading && (
                          <Text style={[styles.tafsirMeta, { color: c.brandTertiary }]}>
                            {tafsirAuthorMeta.tradition_ar}
                          </Text>
                        )}

                        {tafsirLoading ? (
                          <View style={{ paddingVertical: 30, alignItems: "center", gap: 10 }}>
                            <ActivityIndicator color={c.brandTertiary} />
                            <Text style={{ color: c.onSurfaceSecondary, fontSize: 12 }}>
                              يتم إعداد التفسير…
                            </Text>
                          </View>
                        ) : tafsirBody ? (
                          <>
                            <Text style={[styles.tafsirBody, { color: c.onSurface }]}>{tafsirBody}</Text>
                            {tafsirAuthorMeta?.disclaimer_ar ? (
                              <Text style={[styles.tafsirDisclaimer, { color: c.onSurfaceTertiary, borderColor: c.border }]}>
                                ⚠ {tafsirAuthorMeta.disclaimer_ar}
                              </Text>
                            ) : null}
                          </>
                        ) : (
                          <Text style={{ color: c.onSurfaceTertiary, textAlign: "center", paddingVertical: 20 }}>
                            اختر مفسّراً لعرض التفسير.
                          </Text>
                        )}
                      </View>
                    )}

                    {detailTab === "actions" && (
                      <>
                        <Text style={[styles.pickerLabel, { color: c.onSurfaceTertiary }]}>
                          HIGHLIGHT · تظليل
                        </Text>
                        <View style={styles.colorRow}>
                          <ColorSwatch color={c.highlightGold} ring={c.brandTertiary} active={highlights[selected.number]?.color === "gold"} onPress={() => doHighlight("gold")} testID="hl-color-gold" />
                          <ColorSwatch color={c.highlightBlue} ring={c.brandPrimary} active={highlights[selected.number]?.color === "blue"} onPress={() => doHighlight("blue")} testID="hl-color-blue" />
                          <ColorSwatch color={c.highlightRed} ring={c.brandSecondary} active={highlights[selected.number]?.color === "red"} onPress={() => doHighlight("red")} testID="hl-color-red" />
                          <ColorSwatch color={c.highlightGreen} ring={c.success} active={highlights[selected.number]?.color === "green"} onPress={() => doHighlight("green")} testID="hl-color-green" />
                          {highlights[selected.number] && (
                            <Pressable onPress={doRemoveHighlight} style={[styles.clearSwatch, { borderColor: c.borderStrong }]} testID="hl-clear-btn">
                              <Feather name="x" size={16} color={c.onSurfaceSecondary} />
                            </Pressable>
                          )}
                        </View>
                        <View style={styles.sheetActions}>
                          <ActionBtn icon="bookmark" label="Bookmark" onPress={doBookmark} testID="verse-bookmark-btn" />
                          <ActionBtn icon="file-text" label="Note" onPress={() => setShowNoteModal(true)} testID="verse-note-btn" />
                          <ActionBtn icon="share-2" label="Share" onPress={doShare} testID="verse-share-btn" />
                          <ActionBtn icon="message-circle" label="Ask AI" onPress={doAskAI} testID="verse-ai-btn" />
                        </View>
                      </>
                    )}

                    {detailTab === "refs" && (
                      <View style={{ paddingTop: spacing.sm }}>
                        {detailLoading ? (
                          <ActivityIndicator color={c.brandTertiary} />
                        ) : verseDetail?.cross_refs?.length ? (
                          verseDetail.cross_refs.map((r: any, i: number) => (
                            <Pressable
                              key={i}
                              onPress={() => {
                                setSelected(null);
                                router.replace(`/reader/${r.book_id}/${r.chapter}`);
                              }}
                              style={[styles.refRow, { borderColor: c.border, backgroundColor: c.surfaceSecondary }]}
                              testID={`ref-${i}`}
                            >
                              <View style={[styles.refBadge, { backgroundColor: c.brand }]}>
                                <Feather name="link-2" size={12} color="#F1D570" />
                              </View>
                              <View style={{ flex: 1 }}>
                                <Text style={{ color: c.onSurface, fontWeight: "700", fontSize: 13 }}>{r.label_en}</Text>
                                <Text style={{ color: c.onSurfaceSecondary, fontSize: 12, marginTop: 2 }}>{r.label_ar}</Text>
                              </View>
                              <Feather name="chevron-right" size={16} color={c.onSurfaceTertiary} />
                            </Pressable>
                          ))
                        ) : (
                          <View style={{ paddingVertical: 20, alignItems: "center", gap: 12 }}>
                            <Text style={{ color: c.onSurfaceTertiary, textAlign: "center" }}>
                              لا توجد شواهد مُعَدَّة يدوياً لهذه الآية.
                            </Text>
                            <Pressable
                              onPress={doEnrich}
                              disabled={enriching}
                              style={[styles.enrichBtn, { backgroundColor: c.brand, opacity: enriching ? 0.6 : 1 }]}
                              testID="enrich-refs-btn"
                            >
                              {enriching ? (
                                <ActivityIndicator size="small" color="#F1D570" />
                              ) : (
                                <Feather name="zap" size={14} color="#F1D570" />
                              )}
                              <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 13 }}>
                                {enriching ? "جاري التوليد…" : "توليد بالذكاء الاصطناعي"}
                              </Text>
                            </Pressable>
                          </View>
                        )}
                      </View>
                    )}

                    {detailTab === "words" && (
                      <View style={{ paddingTop: spacing.sm }}>
                        {detailLoading ? (
                          <ActivityIndicator color={c.brandTertiary} />
                        ) : verseDetail?.words?.length ? (
                          verseDetail.words.map((w: any, i: number) => (
                            <View
                              key={i}
                              style={[styles.wordCard, { borderColor: c.border, backgroundColor: c.surfaceSecondary }]}
                              testID={`word-${i}`}
                            >
                              <View style={styles.wordHeader}>
                                <Text style={[styles.wordOriginal, { color: c.brand }]}>{w.original}</Text>
                                <View style={[styles.strongChip, { backgroundColor: c.brandTertiary }]}>
                                  <Text style={{ color: "#0A0D14", fontWeight: "800", fontSize: 10, letterSpacing: 0.5 }}>
                                    {w.strong}
                                  </Text>
                                </View>
                              </View>
                              <Text style={[styles.wordTranslit, { color: c.onSurfaceSecondary }]}>
                                {w.translit} · {w.lang === "hebrew" ? "Hebrew · العبرية" : "Greek · اليونانية"}
                              </Text>
                              <Text style={[styles.wordMeaning, { color: c.onSurface }]}>{w.meaning_en}</Text>
                              <Text style={[styles.wordMeaningAr, { color: c.onSurface }]}>{w.meaning_ar}</Text>
                              <Text style={[styles.wordRoot, { color: c.onSurfaceTertiary }]}>
                                Root: {w.root_en}  ·  الجذر: {w.root_ar}
                              </Text>
                            </View>
                          ))
                        ) : (
                          <View style={{ paddingVertical: 20, alignItems: "center", gap: 12 }}>
                            <Text style={{ color: c.onSurfaceTertiary, textAlign: "center" }}>
                              لا توجد بيانات لغة أصلية لهذه الآية بعد.
                            </Text>
                            <Pressable
                              onPress={doEnrich}
                              disabled={enriching}
                              style={[styles.enrichBtn, { backgroundColor: c.brand, opacity: enriching ? 0.6 : 1 }]}
                              testID="enrich-words-btn"
                            >
                              {enriching ? (
                                <ActivityIndicator size="small" color="#F1D570" />
                              ) : (
                                <Feather name="zap" size={14} color="#F1D570" />
                              )}
                              <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 13 }}>
                                {enriching ? "جاري التوليد…" : "توليد بالذكاء الاصطناعي"}
                              </Text>
                            </Pressable>
                          </View>
                        )}
                      </View>
                    )}

                    {detailTab === "place" && (
                      <View style={{ paddingTop: spacing.sm }}>
                        {detailLoading ? (
                          <ActivityIndicator color={c.brandTertiary} />
                        ) : verseDetail?.places?.length ? (
                          verseDetail.places.map((p: any, i: number) => (
                            <Pressable
                              key={i}
                              onPress={() => {
                                setSelected(null);
                                router.push({ pathname: "/maps", params: { focus: p.id } });
                              }}
                              style={[styles.placeCard, { borderColor: c.border, backgroundColor: c.surfaceSecondary }]}
                              testID={`place-${p.id}`}
                            >
                              <View style={[styles.placeIcon, { backgroundColor: c.brandSecondary }]}>
                                <Feather name="map-pin" size={16} color="#FFFFFF" />
                              </View>
                              <View style={{ flex: 1 }}>
                                <Text style={{ color: c.onSurface, fontWeight: "700", fontSize: 14 }}>{p.name_en}</Text>
                                <Text style={{ color: c.onSurfaceSecondary, fontSize: 12, marginTop: 2 }}>{p.name_ar}</Text>
                                <Text style={{ color: c.brandTertiary, fontSize: 11, fontWeight: "700", marginTop: 4, letterSpacing: 0.5 }}>
                                  {p.event_en?.toUpperCase()}
                                </Text>
                                <Text style={{ color: c.onSurfaceTertiary, fontSize: 11, marginTop: 2 }}>
                                  {p.lat.toFixed(3)}, {p.lng.toFixed(3)}
                                </Text>
                              </View>
                              <Feather name="external-link" size={16} color={c.brandTertiary} />
                            </Pressable>
                          ))
                        ) : (
                          <View style={{ paddingVertical: 20, alignItems: "center", gap: 12 }}>
                            <Text style={{ color: c.onSurfaceTertiary, textAlign: "center" }}>
                              لا يوجد موقع مرتبط بهذه الآية.
                            </Text>
                            <Pressable
                              onPress={() => {
                                setSelected(null);
                                router.push("/maps");
                              }}
                              style={[styles.enrichBtn, { backgroundColor: c.brandSecondary }]}
                              testID="open-atlas-btn"
                            >
                              <Feather name="map" size={14} color="#FFFFFF" />
                              <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 13 }}>
                                افتح الأطلس الكتابي الكامل
                              </Text>
                            </Pressable>
                          </View>
                        )}
                      </View>
                    )}
                  </ScrollView>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Note editor */}
      <Modal
        visible={showNoteModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowNoteModal(false)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setShowNoteModal(false)}
        >
          <Pressable
            style={[styles.noteSheet, { backgroundColor: c.surface, borderColor: c.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            <Text style={[styles.sheetRef, { color: c.brandTertiary, marginBottom: spacing.sm }]}>
              Add a note
            </Text>
            <TextInput
              multiline
              placeholder="Type your reflection…"
              placeholderTextColor={c.onSurfaceTertiary}
              value={noteText}
              onChangeText={setNoteText}
              style={[
                styles.noteInput,
                { color: c.onSurface, backgroundColor: c.surfaceSecondary, borderColor: c.border },
              ]}
              testID="note-input"
            />
            <View style={{ flexDirection: "row", gap: spacing.md, marginTop: spacing.md }}>
              <Pressable
                onPress={() => setShowNoteModal(false)}
                style={[styles.noteBtn, { backgroundColor: c.surfaceSecondary }]}
              >
                <Text style={{ color: c.onSurface, fontWeight: "600" }}>Cancel</Text>
              </Pressable>
              <Pressable
                onPress={doSaveNote}
                style={[styles.noteBtn, { backgroundColor: c.brand, flex: 1 }]}
                testID="save-note-btn"
              >
                <Text style={{ color: "#FFFFFF", fontWeight: "700" }}>Save Note</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function ActionBtn({
  icon,
  label,
  onPress,
  testID,
}: {
  icon: any;
  label: string;
  onPress: () => void;
  testID: string;
}) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[styles.actionBtn, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
      testID={testID}
    >
      <Feather name={icon} size={18} color={c.brand} />
      <Text style={[styles.actionLabel, { color: c.onSurface }]}>{label}</Text>
    </Pressable>
  );
}

function ColorSwatch({
  color,
  ring,
  active,
  onPress,
  testID,
}: {
  color: string;
  ring: string;
  active: boolean;
  onPress: () => void;
  testID: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.swatch,
        { backgroundColor: color, borderColor: active ? ring : "transparent" },
      ]}
      testID={testID}
    >
      {active && <Feather name="check" size={14} color={ring} />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: { fontSize: 17, fontWeight: "700", fontFamily: "Georgia" },
  headerTitleAr: { fontSize: 12, marginTop: 1 },
  chip: {
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  verseBlock: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderRadius: radius.sm,
  },
  verseLine: { flexDirection: "row", alignItems: "flex-start" },
  verseNumAr: {
    fontSize: 12,
    fontWeight: "800",
    marginLeft: spacing.sm,
    marginTop: 8,
    minWidth: 22,
    textAlign: "right",
  },
  verseNumEn: { fontSize: 12, fontWeight: "800", marginRight: spacing.sm, marginTop: 6, minWidth: 22 },
  verseAr: {
    flex: 1,
    fontSize: 20,
    lineHeight: 36,
    fontWeight: "500",
    textAlign: "right",
    writingDirection: "rtl",
  },
  verseEn: {
    flex: 1,
    fontSize: 17,
    lineHeight: 28,
    fontFamily: "Georgia",
  },
  verseDivider: {
    height: StyleSheet.hairlineWidth,
    marginTop: spacing.md,
  },
  chapterNav: {
    flexDirection: "row",
    marginTop: spacing.xl,
    gap: spacing.md,
    alignItems: "center",
  },
  navBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "transparent",
  },

  modalBackdrop: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  sheet: {
    padding: spacing.lg,
    paddingBottom: spacing.xl + 20,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: 0,
  },
  sheetHandle: {
    alignSelf: "center",
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#94A3B8",
    opacity: 0.4,
    marginBottom: spacing.md,
  },
  sheetRef: { fontSize: 12, fontWeight: "800", letterSpacing: 1, textTransform: "uppercase" },
  sheetVerse: {
    fontSize: 16,
    fontStyle: "italic",
    fontFamily: "Georgia",
    marginTop: spacing.sm,
    lineHeight: 24,
    marginBottom: spacing.lg,
  },
  sheetActions: {
    flexDirection: "row",
    gap: spacing.sm,
    justifyContent: "space-between",
  },
  actionBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 6,
  },
  actionLabel: { fontSize: 11, fontWeight: "700" },

  pickerLabel: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.5,
    marginBottom: 10,
    marginTop: 4,
  },
  colorRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: spacing.lg,
    alignItems: "center",
  },
  swatch: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2.5,
    alignItems: "center",
    justifyContent: "center",
  },
  clearSwatch: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: "auto",
  },

  // Section titles
  sectionHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: spacing.xl,
    marginBottom: spacing.sm,
  },
  sectionLine: {
    width: 3,
    height: 32,
    borderRadius: 2,
  },
  sectionTitle: { fontSize: 14, fontWeight: "800", fontFamily: "Georgia", letterSpacing: 0.5 },
  sectionTitleAr: { fontSize: 12, marginTop: 1, fontWeight: "600" },

  // Sheet tabs
  sheetTabs: {
    flexDirection: "row",
    borderBottomWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  sheetTab: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },

  // Cross-reference row
  refRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  refBadge: {
    width: 30,
    height: 30,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },

  // Word study
  wordCard: {
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  wordHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  wordOriginal: { fontSize: 22, fontWeight: "700", fontFamily: "Georgia" },
  strongChip: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radius.pill,
  },
  wordTranslit: { fontSize: 12, fontStyle: "italic", marginBottom: 6 },
  wordMeaning: { fontSize: 14, lineHeight: 20, fontFamily: "Georgia" },
  wordMeaningAr: { fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 2 },
  wordRoot: { fontSize: 11, marginTop: 6, letterSpacing: 0.3 },

  // Place row
  placeCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  placeIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  // Tafsir (commentary)
  authorChip: {
    height: 34,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  tafsirMeta: {
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 0.5,
    marginBottom: spacing.sm,
    textAlign: "right",
    writingDirection: "rtl",
  },
  tafsirBody: {
    fontSize: 14,
    lineHeight: 26,
    textAlign: "right",
    writingDirection: "rtl",
    fontFamily: "Georgia",
  },
  tafsirDisclaimer: {
    fontSize: 11,
    lineHeight: 18,
    marginTop: spacing.md,
    paddingTop: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    textAlign: "right",
    writingDirection: "rtl",
  },
  enrichBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: spacing.lg,
    paddingVertical: 12,
    borderRadius: radius.pill,
  },

  noteSheet: {
    padding: spacing.lg,
    paddingBottom: spacing.xl + 20,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: 0,
  },
  noteInput: {
    minHeight: 120,
    borderRadius: radius.md,
    padding: spacing.md,
    fontSize: 15,
    textAlignVertical: "top",
    borderWidth: StyleSheet.hairlineWidth,
  },
  noteBtn: {
    alignItems: "center",
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    flex: 1,
  },
});
