import { useCallback, useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Platform,
} from "react-native";
import { WebView } from "react-native-webview";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

type Place = {
  id: string;
  name_en: string;
  name_ar: string;
  lat: number;
  lng: number;
  testament: string;
  description_en: string;
  description_ar: string;
  event_en: string;
  event_ar: string;
  related_refs: { book_id: string; chapter: number; verse: number; label_en: string; label_ar: string }[];
};

const buildMapHtml = (places: Place[], focusId?: string, dark = false) => {
  const focus = places.find((p) => p.id === focusId) || places[0];
  const center = focus ? [focus.lat, focus.lng] : [31.7683, 35.2137]; // Jerusalem
  const zoom = focusId ? 8 : 5;
  const bg = dark ? "#050814" : "#F7F9FC";
  const tiles = dark
    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
    : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png";

  return `<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
  html,body,#map{height:100%;margin:0;padding:0;background:${bg};font-family:Georgia,serif;}
  .marker-pin{width:28px;height:36px;background:#9B111E;border-radius:14px 14px 14px 2px;transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2px solid #D4AF37;box-shadow:0 2px 6px rgba(0,0,0,0.35);}
  .marker-pin.focused{background:#D4AF37;border-color:#9B111E;}
  .marker-pin span{transform:rotate(45deg);color:#fff;font-weight:800;font-size:11px;}
  .marker-pin.focused span{color:#0A0D14;}
  .leaflet-popup-content{margin:8px 12px;font-family:Georgia,serif;}
  .leaflet-popup-content h4{margin:0 0 4px;color:#0033A0;font-size:15px;}
  .leaflet-popup-content .ar{color:#D4AF37;font-size:13px;margin-bottom:6px;}
  .leaflet-popup-content .event{color:#9B111E;font-weight:700;font-size:11px;letter-spacing:1px;text-transform:uppercase;}
</style></head><body>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
  const map = L.map('map', {zoomControl: true}).setView([${center[0]}, ${center[1]}], ${zoom});
  L.tileLayer('${tiles}', {maxZoom:16, subdomains:'abcd', attribution:'© OSM · CARTO'}).addTo(map);
  const places = ${JSON.stringify(places)};
  const focusId = ${JSON.stringify(focusId || "")};
  places.forEach(p => {
    const isFocus = p.id === focusId;
    const icon = L.divIcon({
      className: 'custom-marker',
      html: '<div class="marker-pin' + (isFocus ? ' focused' : '') + '"><span>' + (p.testament === 'OT' ? 'OT' : p.testament === 'NT' ? 'NT' : '✝') + '</span></div>',
      iconSize: [28, 36],
      iconAnchor: [14, 36],
    });
    const html = '<h4>' + p.name_en + '</h4><div class="ar">' + p.name_ar + '</div><div class="event">' + (p.event_en||'') + '</div><p style="font-size:12px;margin:6px 0 0;color:#2D3748;">' + p.description_en + '</p>';
    L.marker([p.lat, p.lng], {icon}).addTo(map).bindPopup(html);
  });
  if (focusId) {
    const fp = places.find(x => x.id === focusId);
    if (fp) setTimeout(() => map.openPopup(map.eachLayer(l => l instanceof L.Marker && l.getLatLng().lat === fp.lat)), 300);
  }
</script></body></html>`;
};

export default function MapsScreen() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const router = useRouter();
  const { focus } = useLocalSearchParams<{ focus?: string }>();
  const [places, setPlaces] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"ALL" | "OT" | "NT">("ALL");
  const [selected, setSelected] = useState<string | undefined>(
    typeof focus === "string" ? focus : undefined
  );

  const load = useCallback(async () => {
    try {
      const r = await api.places();
      setPlaces(r.places);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    if (filter === "ALL") return places;
    return places.filter((p) => p.testament === filter || p.testament === "BOTH");
  }, [places, filter]);

  const focusPlace = selected ? places.find((p) => p.id === selected) : undefined;

  const html = useMemo(
    () => buildMapHtml(filtered, selected, isDark),
    [filtered, selected, isDark]
  );

  return (
    <View style={{ flex: 1, backgroundColor: c.surface }}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm, backgroundColor: c.surface, borderBottomColor: c.divider }]}>
        <Pressable
          onPress={() => router.back()}
          style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary }]}
          testID="maps-back-btn"
        >
          <Feather name="chevron-left" size={20} color={c.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.onSurface }]}>Biblical Atlas</Text>
          <Text style={[styles.subtitle, { color: c.onSurfaceSecondary }]}>الخرائط الكتابية · {places.length} locations</Text>
        </View>
      </View>

      {/* Filter chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}
        style={{ maxHeight: 60 }}
      >
        {(["ALL", "OT", "NT"] as const).map((f) => (
          <Pressable
            key={f}
            onPress={() => setFilter(f)}
            style={[
              styles.chip,
              { backgroundColor: filter === f ? c.brand : c.surfaceSecondary, borderColor: filter === f ? c.brand : c.border },
            ]}
            testID={`maps-filter-${f}`}
          >
            <Text style={{ color: filter === f ? "#FFFFFF" : c.onSurfaceSecondary, fontWeight: "700", fontSize: 12 }}>
              {f === "ALL" ? "All Locations" : f === "OT" ? "Old Testament" : "New Testament"}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={c.brandTertiary} />
        </View>
      ) : (
        <>
          {/* Interactive map */}
          <View style={styles.mapWrap}>
            {Platform.OS === "web" ? (
              // react-native-webview isn't supported on web — use an iframe with the same HTML
              // @ts-ignore — iframe is a DOM element on web only
              <iframe
                title="Biblical Atlas"
                srcDoc={html}
                style={{ width: "100%", height: "100%", border: "none", background: c.surface }}
                data-testid="biblical-atlas-iframe"
              />
            ) : (
              <WebView
                originWhitelist={["*"]}
                source={{ html }}
                style={{ flex: 1, backgroundColor: c.surface }}
                scrollEnabled={false}
                testID="biblical-atlas-webview"
              />
            )}
          </View>

          {/* Focused location details */}
          {focusPlace && (
            <View style={[styles.focusCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
              <View style={styles.focusHead}>
                <View style={[styles.pinIcon, { backgroundColor: c.brandSecondary }]}>
                  <Feather name="map-pin" size={16} color="#FFFFFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: c.onSurface, fontFamily: "Georgia", fontSize: 18, fontWeight: "700" }}>{focusPlace.name_en}</Text>
                  <Text style={{ color: c.brandTertiary, fontSize: 13, fontWeight: "600" }}>{focusPlace.name_ar}</Text>
                </View>
                <Pressable onPress={() => setSelected(undefined)} testID="focus-close-btn">
                  <Feather name="x" size={18} color={c.onSurfaceTertiary} />
                </Pressable>
              </View>
              <Text style={[styles.focusEvent, { color: c.brandSecondary }]}>
                {focusPlace.event_en?.toUpperCase()}
              </Text>
              <Text style={[styles.focusDesc, { color: c.onSurface }]}>{focusPlace.description_en}</Text>
              <Text style={[styles.focusDescAr, { color: c.onSurfaceSecondary }]}>{focusPlace.description_ar}</Text>
              {focusPlace.related_refs?.length > 0 && (
                <View style={{ marginTop: spacing.sm, flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                  {focusPlace.related_refs.map((r, i) => (
                    <Pressable
                      key={i}
                      onPress={() => router.push(`/reader/${r.book_id}/${r.chapter}`)}
                      style={[styles.refPill, { borderColor: c.brand, backgroundColor: c.surface }]}
                      testID={`focus-ref-${i}`}
                    >
                      <Feather name="link-2" size={11} color={c.brand} />
                      <Text style={{ color: c.brand, fontWeight: "700", fontSize: 11 }}>{r.label_en}</Text>
                    </Pressable>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* Locations list */}
          {!focusPlace && (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}
              style={styles.listRow}
            >
              {filtered.map((p) => (
                <Pressable
                  key={p.id}
                  onPress={() => setSelected(p.id)}
                  style={[styles.locCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
                  testID={`loc-${p.id}`}
                >
                  <View style={[styles.locBadge, { backgroundColor: p.testament === "OT" ? c.brandPrimary : p.testament === "NT" ? c.brandSecondary : c.brandTertiary }]}>
                    <Text style={{ color: p.testament === "BOTH" ? "#0A0D14" : "#FFFFFF", fontWeight: "800", fontSize: 10 }}>
                      {p.testament === "BOTH" ? "OT/NT" : p.testament}
                    </Text>
                  </View>
                  <Text style={{ color: c.onSurface, fontFamily: "Georgia", fontWeight: "700", fontSize: 14 }} numberOfLines={1}>{p.name_en}</Text>
                  <Text style={{ color: c.onSurfaceSecondary, fontSize: 12 }} numberOfLines={1}>{p.name_ar}</Text>
                  <Text style={{ color: c.brandTertiary, fontSize: 10, fontWeight: "700", marginTop: 4, letterSpacing: 0.5 }} numberOfLines={1}>
                    {p.event_en?.toUpperCase()}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  title: { fontSize: 22, fontWeight: "700", fontFamily: "Georgia" },
  subtitle: { fontSize: 12, marginTop: 2 },

  chip: {
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },

  mapWrap: {
    flex: 1,
    marginHorizontal: spacing.lg,
    borderRadius: radius.md,
    overflow: "hidden",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(0,0,0,0.1)",
    minHeight: 300,
  },

  focusCard: {
    margin: spacing.lg,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  focusHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    marginBottom: spacing.sm,
  },
  pinIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  focusEvent: { fontSize: 11, fontWeight: "800", letterSpacing: 1.2, marginBottom: 8 },
  focusDesc: { fontSize: 13, lineHeight: 20, fontFamily: "Georgia" },
  focusDescAr: { fontSize: 12, lineHeight: 20, marginTop: 6, textAlign: "right" },
  refPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },

  listRow: { maxHeight: 130 },
  locCard: {
    width: 160,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    flexShrink: 0,
  },
  locBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: radius.sm,
    marginBottom: 8,
  },
});
