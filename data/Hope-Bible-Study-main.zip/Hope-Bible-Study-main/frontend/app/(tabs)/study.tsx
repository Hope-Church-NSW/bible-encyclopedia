import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

type Tab = "bookmarks" | "highlights" | "notes" | "prayer";

export default function StudyScreen() {
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const router = useRouter();

  const [tab, setTab] = useState<Tab>("bookmarks");
  const [loading, setLoading] = useState(true);
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [highlights, setHighlights] = useState<any[]>([]);
  const [notes, setNotes] = useState<any[]>([]);
  const [prayers, setPrayers] = useState<any[]>([]);
  const [showAddPrayer, setShowAddPrayer] = useState(false);
  const [prTitle, setPrTitle] = useState("");
  const [prBody, setPrBody] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [b, h, n, p] = await Promise.all([
        api.bookmarks(),
        api.highlights(),
        api.notes(),
        api.prayers(),
      ]);
      setBookmarks(b);
      setHighlights(h);
      setNotes(n);
      setPrayers(p);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, tab]);

  const savePrayer = async () => {
    if (!prTitle.trim() || !prBody.trim()) return;
    try {
      await api.addPrayer({ title: prTitle.trim(), body: prBody.trim() });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setPrTitle("");
      setPrBody("");
      setShowAddPrayer(false);
      load();
    } catch (e) {
      console.log(e);
    }
  };

  const tabs: { key: Tab; label: string; icon: any }[] = [
    { key: "bookmarks", label: "Bookmarks", icon: "bookmark" },
    { key: "highlights", label: "Highlights", icon: "edit-3" },
    { key: "notes", label: "Notes", icon: "file-text" },
    { key: "prayer", label: "Prayer", icon: "heart" },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: c.surface }}>
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + spacing.sm, backgroundColor: c.surface, borderBottomColor: c.divider },
        ]}
      >
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.onSurface }]}>My Study</Text>
          <Text style={[styles.subtitle, { color: c.onSurfaceSecondary }]}>
            Bookmarks · Highlights · Notes · Prayer
          </Text>
        </View>
        {tab === "prayer" && (
          <Pressable
            onPress={() => setShowAddPrayer(true)}
            style={[styles.addBtn, { backgroundColor: c.brand }]}
            testID="add-prayer-btn"
          >
            <Feather name="plus" size={16} color="#FFFFFF" />
            <Text style={{ color: "#FFFFFF", fontWeight: "700", fontSize: 12 }}>Prayer</Text>
          </Pressable>
        )}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}
        style={{ backgroundColor: c.surface, maxHeight: 60 }}
      >
        {tabs.map((t) => (
          <Pressable
            key={t.key}
            onPress={() => setTab(t.key)}
            testID={`study-tab-${t.key}`}
            style={[
              styles.chip,
              {
                backgroundColor: tab === t.key ? c.brand : c.surfaceSecondary,
                borderColor: tab === t.key ? c.brand : c.border,
              },
            ]}
          >
            <Feather name={t.icon} size={12} color={tab === t.key ? "#FFFFFF" : c.onSurfaceSecondary} />
            <Text style={{ color: tab === t.key ? "#FFFFFF" : c.onSurfaceSecondary, fontWeight: "700", fontSize: 12 }}>
              {t.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={c.brandTertiary} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
          {tab === "bookmarks" && (
            <List
              items={bookmarks}
              empty="No bookmarks yet. Tap any verse and Bookmark to save it."
              render={(bm) => (
                <Pressable
                  key={bm.id}
                  onPress={() => router.push(`/reader/${bm.book_id}/${bm.chapter}`)}
                  style={[styles.card, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
                >
                  <Feather name="bookmark" size={18} color={c.brandTertiary} />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.cardRef, { color: c.brand }]}>
                      {bm.label || `${bm.book_id.toUpperCase()} ${bm.chapter}:${bm.verse}`}
                    </Text>
                    <Text style={[styles.cardMeta, { color: c.onSurfaceTertiary }]}>
                      Saved {new Date(bm.created_at).toLocaleDateString()}
                    </Text>
                  </View>
                  <Pressable onPress={async () => { await api.removeBookmark(bm.id); load(); }} testID={`del-bm-${bm.id}`}>
                    <Feather name="x" size={16} color={c.onSurfaceTertiary} />
                  </Pressable>
                </Pressable>
              )}
            />
          )}

          {tab === "highlights" && (
            <List
              items={highlights}
              empty="No highlights yet. Tap a verse and pick a highlight color."
              render={(h) => {
                const swatchBg =
                  h.color === "blue"
                    ? c.highlightBlue
                    : h.color === "red"
                    ? c.highlightRed
                    : h.color === "green"
                    ? c.highlightGreen
                    : c.highlightGold;
                const swatchRing =
                  h.color === "blue"
                    ? c.brandPrimary
                    : h.color === "red"
                    ? c.brandSecondary
                    : h.color === "green"
                    ? c.success
                    : c.brandTertiary;
                return (
                  <Pressable
                    key={h.id}
                    onPress={() => router.push(`/reader/${h.book_id}/${h.chapter}`)}
                    style={[styles.card, { backgroundColor: swatchBg, borderColor: c.border }]}
                  >
                    <View style={[styles.hlDot, { backgroundColor: swatchRing }]} />
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.cardRef, { color: c.brand }]}>
                        {h.book_id.toUpperCase()} {h.chapter}:{h.verse}
                      </Text>
                      <Text style={[styles.cardMeta, { color: c.onSurfaceTertiary }]}>
                        {(h.color || "gold").toUpperCase()} · {new Date(h.created_at).toLocaleDateString()}
                      </Text>
                    </View>
                    <Pressable onPress={async () => { await api.removeHighlight(h.id); load(); }} testID={`del-hl-${h.id}`}>
                      <Feather name="x" size={16} color={c.onSurfaceTertiary} />
                    </Pressable>
                  </Pressable>
                );
              }}
            />
          )}

          {tab === "notes" && (
            <List
              items={notes}
              empty="No notes yet. Tap a verse and Note to reflect on it."
              render={(n) => (
                <Pressable
                  key={n.id}
                  onPress={() => router.push(`/reader/${n.book_id}/${n.chapter}`)}
                  style={[styles.noteCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
                >
                  <Text style={[styles.cardRef, { color: c.brand }]}>
                    {n.book_id.toUpperCase()} {n.chapter}:{n.verse}
                  </Text>
                  <Text style={{ color: c.onSurface, fontSize: 14, lineHeight: 20, marginTop: 6 }}>{n.text}</Text>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
                    <Text style={[styles.cardMeta, { color: c.onSurfaceTertiary }]}>
                      {new Date(n.created_at).toLocaleDateString()}
                    </Text>
                    <Pressable onPress={async () => { await api.removeNote(n.id); load(); }} testID={`del-note-${n.id}`}>
                      <Feather name="trash-2" size={14} color={c.onSurfaceTertiary} />
                    </Pressable>
                  </View>
                </Pressable>
              )}
            />
          )}

          {tab === "prayer" && (
            <List
              items={prayers}
              empty="No prayer requests yet. Add one to start your prayer journal."
              render={(p) => (
                <View key={p.id} style={[styles.noteCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                    <Feather
                      name={p.answered ? "check-circle" : "heart"}
                      size={16}
                      color={p.answered ? c.success : c.brandSecondary}
                    />
                    <Text style={[styles.cardRef, { color: c.onSurface, flex: 1 }]}>{p.title}</Text>
                  </View>
                  <Text style={{ color: c.onSurfaceSecondary, fontSize: 14, marginTop: 6, lineHeight: 20 }}>
                    {p.body}
                  </Text>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
                    <Pressable
                      onPress={async () => { await api.togglePrayer(p.id); load(); }}
                      style={[styles.prBtn, { borderColor: c.border }]}
                      testID={`toggle-prayer-${p.id}`}
                    >
                      <Text style={{ color: c.onSurfaceSecondary, fontSize: 12, fontWeight: "700" }}>
                        {p.answered ? "Mark unanswered" : "Mark answered"}
                      </Text>
                    </Pressable>
                    <Pressable onPress={async () => { await api.removePrayer(p.id); load(); }} testID={`del-prayer-${p.id}`}>
                      <Feather name="trash-2" size={14} color={c.onSurfaceTertiary} />
                    </Pressable>
                  </View>
                </View>
              )}
            />
          )}
        </ScrollView>
      )}

      {/* Add prayer modal */}
      <Modal visible={showAddPrayer} transparent animationType="slide" onRequestClose={() => setShowAddPrayer(false)}>
        <Pressable style={styles.backdrop} onPress={() => setShowAddPrayer(false)}>
          <Pressable style={[styles.sheet, { backgroundColor: c.surface, borderColor: c.border }]} onPress={(e) => e.stopPropagation()}>
            <Text style={{ color: c.brandTertiary, fontSize: 12, fontWeight: "800", letterSpacing: 1 }}>NEW PRAYER REQUEST</Text>
            <TextInput
              placeholder="Title (e.g. Wisdom for a decision)"
              placeholderTextColor={c.onSurfaceTertiary}
              value={prTitle}
              onChangeText={setPrTitle}
              style={[styles.field, { color: c.onSurface, backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
              testID="prayer-title-input"
            />
            <TextInput
              multiline
              placeholder="Write your prayer…"
              placeholderTextColor={c.onSurfaceTertiary}
              value={prBody}
              onChangeText={setPrBody}
              style={[styles.field, { minHeight: 120, textAlignVertical: "top", color: c.onSurface, backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
              testID="prayer-body-input"
            />
            <View style={{ flexDirection: "row", gap: spacing.md, marginTop: spacing.md }}>
              <Pressable onPress={() => setShowAddPrayer(false)} style={[styles.btn, { backgroundColor: c.surfaceSecondary }]}>
                <Text style={{ color: c.onSurface, fontWeight: "600" }}>Cancel</Text>
              </Pressable>
              <Pressable onPress={savePrayer} style={[styles.btn, { backgroundColor: c.brand, flex: 1 }]} testID="save-prayer-btn">
                <Text style={{ color: "#FFFFFF", fontWeight: "700" }}>Save Prayer</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function List({ items, render, empty }: { items: any[]; render: (i: any) => any; empty: string }) {
  const { c } = useTheme();
  if (items.length === 0) {
    return (
      <View style={{ paddingVertical: 60, alignItems: "center", paddingHorizontal: 24 }}>
        <View style={[styles.emptyIcon, { backgroundColor: c.surfaceSecondary }]}>
          <Feather name="inbox" size={22} color={c.onSurfaceTertiary} />
        </View>
        <Text style={{ color: c.onSurfaceTertiary, textAlign: "center", marginTop: 12, fontSize: 13, lineHeight: 20 }}>
          {empty}
        </Text>
      </View>
    );
  }
  return <>{items.map(render)}</>;
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  title: { fontSize: 24, fontWeight: "700", fontFamily: "Georgia" },
  subtitle: { fontSize: 12, marginTop: 2 },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: spacing.md,
    height: 36,
    borderRadius: radius.pill,
  },
  chip: {
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    flexShrink: 0,
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  noteCard: {
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  cardRef: { fontSize: 13, fontWeight: "800", letterSpacing: 0.5 },
  cardMeta: { fontSize: 11, marginTop: 2 },
  hlDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  emptyIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  prBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },

  backdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.5)" },
  sheet: {
    padding: spacing.lg,
    paddingBottom: spacing.xl + 20,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  field: {
    padding: spacing.md,
    fontSize: 15,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  btn: {
    alignItems: "center",
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    flex: 1,
  },
});
