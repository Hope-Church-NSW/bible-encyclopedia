import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  RefreshControl,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { storage } from "@/src/utils/storage";
import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius, type as tt } from "@/src/theme/tokens";

const HERO_BG =
  "https://images.unsplash.com/photo-1536704382439-da99b6ccc0cf?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MDV8MHwxfHNlYXJjaHwyfHxvcGVuJTIwYmlibGUlMjB3YXJtJTIwbGlnaHQlMjBnb2xkJTIwYWNjZW50fGVufDB8fHx8MTc4MzU5NjkzNnww&ixlib=rb-4.1.0&q=85";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const router = useRouter();

  const [vod, setVod] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [church, setChurch] = useState<any>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [readerLang, setReaderLang] = useState<"parallel" | "en" | "ar">("parallel");

  useEffect(() => {
    (async () => {
      const saved = await storage.getItem<string>("reader-mode", "parallel");
      if (saved === "parallel" || saved === "en" || saved === "ar") setReaderLang(saved);
    })();
  }, []);

  const toggleLang = async () => {
    const next = readerLang === "ar" ? "en" : readerLang === "en" ? "parallel" : "ar";
    setReaderLang(next);
    await storage.setItem("reader-mode", next);
    Haptics.selectionAsync();
  };

  const load = useCallback(async () => {
    try {
      const [v, p, ch] = await Promise.all([
        api.verseOfDay(),
        api.readingPlans(),
        api.church(),
      ]);
      setVod(v);
      setPlans(p.plans || []);
      setChurch(ch);
    } catch (e) {
      console.log("home load err", e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const goToVerse = () => {
    if (!vod) return;
    Haptics.selectionAsync();
    router.push(`/reader/${vod.book_id}/${vod.chapter}`);
  };

  return (
    <View style={[styles.root, { backgroundColor: c.surface }]}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + spacing.md,
          paddingBottom: 100,
        }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.brandTertiary} />
        }
      >
        {/* Header */}
        <View style={styles.header} testID="home-header">
          <View style={styles.brandRow}>
            <Image
              source={require("../../assets/images/brand/hope-church-logo.png")}
              style={styles.brandLogo}
              contentFit="contain"
            />
            <View style={{ flex: 1, marginLeft: spacing.md }}>
              <Text style={[styles.brandName, { color: c.onSurface }]}>Hope Church Sydney</Text>
              <Text style={[styles.brandNameAr, { color: c.onSurfaceSecondary }]}>
                كنيسة رجاء الأمم – سيدني
              </Text>
            </View>
            <Pressable
              onPress={toggleLang}
              style={[styles.langBtn, { backgroundColor: c.brand }]}
              testID="home-lang-toggle"
              accessibilityLabel="Toggle Bible language"
            >
              <Feather name="globe" size={13} color="#F1D570" />
              <Text style={styles.langBtnTxt}>
                {readerLang === "ar" ? "العربية" : readerLang === "en" ? "English" : "AR · EN"}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => router.push("/about")}
              style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary, marginLeft: 8 }]}
              testID="home-about-btn"
            >
              <Feather name="info" size={18} color={c.brandPrimary} />
            </Pressable>
            <Pressable
              onPress={() => router.push("/share")}
              style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary, marginLeft: 8 }]}
              testID="home-share-btn"
            >
              <Feather name="share-2" size={18} color={c.brandSecondary} />
            </Pressable>
            <Pressable
              onPress={() => router.push("/(tabs)/ai")}
              style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary, marginLeft: 8 }]}
              testID="home-open-ai-btn"
            >
              <Feather name="message-circle" size={18} color={c.brandTertiary} />
            </Pressable>
          </View>
        </View>

        {loading ? (
          <View style={{ paddingVertical: 60, alignItems: "center" }}>
            <ActivityIndicator color={c.brandTertiary} />
          </View>
        ) : (
          <>
            {/* Verse of the Day Hero */}
            {vod && vod.verse && (
              <Pressable
                onPress={goToVerse}
                style={styles.hero}
                testID="verse-of-day-card"
              >
                <Image
                  source={{ uri: HERO_BG }}
                  style={StyleSheet.absoluteFill}
                  contentFit="cover"
                  transition={400}
                />
                <LinearGradient
                  colors={["rgba(0,35,102,0.35)", "rgba(0,35,102,0.85)", "rgba(0,17,50,0.98)"]}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.heroContent}>
                  <View style={styles.heroBadge}>
                    <Feather name="sun" size={12} color="#0A0D14" />
                    <Text style={styles.heroBadgeTxt}>Verse of the day</Text>
                  </View>
                  <Text style={styles.heroVerseAr} numberOfLines={4}>
                    {vod.verse.ar}
                  </Text>
                  <Text style={styles.heroVerseEn} numberOfLines={5}>
                    {vod.verse.en}
                  </Text>
                  <View style={styles.heroFooter}>
                    <Text style={styles.heroRef}>
                      {vod.book_name_en} {vod.chapter}:{vod.verse.number} · {vod.book_name_ar}
                    </Text>
                    <Feather name="arrow-right" size={16} color="#F1D570" />
                  </View>
                </View>
              </Pressable>
            )}

            {/* Quick actions */}
            <View style={styles.quickRow}>
              <QuickAction
                icon="book-open"
                label="Bible"
                onPress={() => router.push("/(tabs)/bible")}
                testID="qa-bible"
                color={c.brandPrimary}
              />
              <QuickAction
                icon="map"
                label="Atlas"
                onPress={() => router.push("/maps")}
                testID="qa-atlas"
                color={c.brandSecondary}
              />
              <QuickAction
                icon="bookmark"
                label="Study"
                onPress={() => router.push("/(tabs)/study")}
                testID="qa-study"
                color={c.brandTertiary}
                dark
              />
              <QuickAction
                icon="heart"
                label="Church"
                onPress={() => router.push("/(tabs)/church")}
                testID="qa-church"
                color={c.brandPrimary}
              />
            </View>

            {/* Reading Plans */}
            <SectionHeader title="Reading Plans" subtitle="Guided journeys through Scripture" />
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
              style={{ marginBottom: spacing.xl }}
            >
              {plans.map((p) => (
                <Pressable
                  key={p.id}
                  onPress={() => router.push(`/reader/${p.days[0].ref.split(' ')[0].toLowerCase().slice(0,3) === 'joh' ? 'joh' : p.days[0].ref.toLowerCase().slice(0,3)}/${p.days[0].ref.split(' ').pop()}`)}
                  style={[styles.planCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
                  testID={`plan-${p.id}`}
                >
                  <View style={[styles.planIcon, { backgroundColor: c.brandTertiary + "30" }]}>
                    <Feather name="book" size={18} color={c.brandTertiary} />
                  </View>
                  <Text style={[styles.planTitle, { color: c.onSurface }]} numberOfLines={2}>
                    {p.title_en}
                  </Text>
                  <Text style={[styles.planTitleAr, { color: c.onSurfaceSecondary }]} numberOfLines={1}>
                    {p.title_ar}
                  </Text>
                  <Text style={[styles.planDays, { color: c.brandTertiary }]}>
                    {p.days.length} days
                  </Text>
                </Pressable>
              ))}
            </ScrollView>

            {/* Sermon preview */}
            {church?.sermons?.[0] && (
              <>
                <SectionHeader title="Latest Sermon" subtitle="From Pastor Ashraf" />
                <Pressable
                  onPress={() => router.push("/(tabs)/church")}
                  style={[styles.sermonCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
                  testID="latest-sermon-card"
                >
                  <View style={[styles.sermonIcon, { backgroundColor: c.brandSecondary + "20" }]}>
                    <Feather name="mic" size={22} color={c.brandSecondary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.sermonTitle, { color: c.onSurface }]} numberOfLines={1}>
                      {church.sermons[0].title_en}
                    </Text>
                    <Text style={[styles.sermonTitleAr, { color: c.onSurfaceSecondary }]} numberOfLines={1}>
                      {church.sermons[0].title_ar}
                    </Text>
                    <Text style={[styles.sermonMeta, { color: c.onSurfaceTertiary }]}>
                      {church.sermons[0].speaker} · {church.sermons[0].date}
                    </Text>
                  </View>
                  <Feather name="chevron-right" size={20} color={c.onSurfaceTertiary} />
                </Pressable>
              </>
            )}

            {/* AI CTA */}
            <Pressable
              onPress={() => router.push("/(tabs)/ai")}
              style={[styles.aiCta, { backgroundColor: c.brand }]}
              testID="home-ai-cta"
            >
              <LinearGradient
                colors={[c.brand, c.brandPrimary]}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              <View style={styles.aiCtaLeft}>
                <View style={styles.aiCtaBadge}>
                  <Feather name="zap" size={12} color="#0A0D14" />
                  <Text style={styles.aiCtaBadgeTxt}>AI Assistant</Text>
                </View>
                <Text style={styles.aiCtaTitle}>Ask the Bible anything</Text>
                <Text style={styles.aiCtaSubtitle}>
                  Verse explanations · word studies · sermon prep
                </Text>
              </View>
              <View style={styles.aiCtaArrow}>
                <Feather name="arrow-right" size={20} color="#F1D570" />
              </View>
            </Pressable>

            <Text style={[styles.footer, { color: c.onSurfaceTertiary }]}>
              Produced and Sponsored by{"\n"}
              <Text style={{ fontWeight: "700", color: c.onSurfaceSecondary }}>
                Hope Church Sydney · كنيسة رجاء الأمم – سيدني
              </Text>
            </Text>
          </>
        )}
      </ScrollView>
    </View>
  );
}

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const { c } = useTheme();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: c.onSurface }]}>{title}</Text>
      {subtitle ? (
        <Text style={[styles.sectionSubtitle, { color: c.onSurfaceTertiary }]}>{subtitle}</Text>
      ) : null}
    </View>
  );
}

function QuickAction({
  icon,
  label,
  onPress,
  testID,
  color,
  dark,
}: {
  icon: any;
  label: string;
  onPress: () => void;
  testID: string;
  color: string;
  dark?: boolean;
}) {
  const { c } = useTheme();
  return (
    <Pressable onPress={onPress} style={styles.qaItem} testID={testID}>
      <View style={[styles.qaIcon, { backgroundColor: color }]}>
        <Feather name={icon} size={20} color={dark ? "#0A0D14" : "#FFFFFF"} />
      </View>
      <Text style={[styles.qaLabel, { color: c.onSurface }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  brandRow: { flexDirection: "row", alignItems: "center" },
  brandLogo: { width: 44, height: 44 },
  brandName: { fontSize: 16, fontWeight: "700", letterSpacing: 0.2 },
  brandNameAr: { fontSize: 12, marginTop: 2 },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  langBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    height: 32,
    borderRadius: radius.pill,
  },
  langBtnTxt: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 0.5,
  },

  hero: {
    marginHorizontal: spacing.lg,
    marginTop: spacing.md,
    height: 300,
    borderRadius: radius.lg,
    overflow: "hidden",
  },
  heroContent: {
    flex: 1,
    padding: spacing.xl,
    justifyContent: "flex-end",
  },
  heroBadge: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#F1D570",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: radius.pill,
    marginBottom: spacing.md,
    gap: 6,
  },
  heroBadgeTxt: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
    color: "#0A0D14",
  },
  heroVerseAr: {
    fontSize: 17,
    color: "#FFFFFF",
    textAlign: "right",
    lineHeight: 30,
    fontWeight: "600",
    writingDirection: "rtl",
  },
  heroVerseEn: {
    marginTop: spacing.sm,
    fontSize: 15,
    color: "rgba(255,255,255,0.95)",
    lineHeight: 22,
    fontStyle: "italic",
    fontFamily: "Georgia",
  },
  heroFooter: {
    marginTop: spacing.md,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  heroRef: {
    fontSize: 12,
    color: "#F1D570",
    fontWeight: "700",
    letterSpacing: 0.5,
  },

  quickRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: spacing.xl,
    marginBottom: spacing.xl,
    paddingHorizontal: spacing.lg,
  },
  qaItem: { alignItems: "center", flex: 1 },
  qaIcon: {
    width: 54,
    height: 54,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  qaLabel: { fontSize: 12, fontWeight: "600" },

  sectionHeader: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  sectionTitle: { fontSize: 20, fontWeight: "700", fontFamily: "Georgia", letterSpacing: 0.2 },
  sectionSubtitle: { fontSize: 12, marginTop: 2 },

  planCard: {
    width: 200,
    borderRadius: radius.md,
    padding: spacing.lg,
    borderWidth: StyleSheet.hairlineWidth,
  },
  planIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.md,
  },
  planTitle: { fontSize: 15, fontWeight: "700", fontFamily: "Georgia", lineHeight: 20 },
  planTitleAr: { fontSize: 12, marginTop: 4 },
  planDays: { fontSize: 11, fontWeight: "700", marginTop: spacing.sm, letterSpacing: 0.5, textTransform: "uppercase" },

  sermonCard: {
    marginHorizontal: spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.xl,
  },
  sermonIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginRight: spacing.md,
  },
  sermonTitle: { fontSize: 15, fontWeight: "700", fontFamily: "Georgia" },
  sermonTitleAr: { fontSize: 12, marginTop: 2 },
  sermonMeta: { fontSize: 11, marginTop: 4 },

  aiCta: {
    marginHorizontal: spacing.lg,
    borderRadius: radius.lg,
    padding: spacing.lg,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.xl,
  },
  aiCtaLeft: { flex: 1 },
  aiCtaBadge: {
    alignSelf: "flex-start",
    backgroundColor: "#F1D570",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radius.pill,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginBottom: 8,
  },
  aiCtaBadgeTxt: { fontSize: 10, fontWeight: "800", color: "#0A0D14", letterSpacing: 0.5 },
  aiCtaTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Georgia",
  },
  aiCtaSubtitle: { fontSize: 12, color: "rgba(255,255,255,0.75)", marginTop: 3 },
  aiCtaArrow: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(212,175,55,0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: spacing.md,
  },

  footer: {
    textAlign: "center",
    fontSize: 12,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xl,
    lineHeight: 20,
  },
});
