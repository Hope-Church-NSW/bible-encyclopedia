import { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";

import { api } from "@/src/api/client";
import { getClientId } from "@/src/api/client-id";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

type Mode = "ai" | "search";
type ChatMsg = { role: "user" | "assistant"; content: string };

const SUGGESTED = [
  "Explain John 3:16 in detail",
  "What does 'agape' mean in the New Testament?",
  "Prepare a 5-minute sermon on grace",
  "Compare faith and works",
  "Timeline of Paul's missionary journeys",
  "Give me a Bible study on prayer",
];

export default function AIScreen() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const params = useLocalSearchParams<{ seed?: string }>();

  const [sessionId, setSessionId] = useState<string>("");
  const [mode, setMode] = useState<Mode>("ai");

  // AI state
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  // Search state
  const [q, setQ] = useState("");
  const [lang, setLang] = useState<"en" | "ar">("ar");
  const [results, setResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  // Load history
  useEffect(() => {
    (async () => {
      try {
        const cid = await getClientId();
        setSessionId(cid);
        const h = await api.chatHistory(cid);
        setMessages(
          (h.messages || []).map((m: any) => ({ role: m.role, content: m.content }))
        );
      } catch (e) {
        console.log(e);
      }
    })();
  }, []);

  // Seed from verse "Ask AI"
  useEffect(() => {
    if (params.seed && typeof params.seed === "string") {
      setMode("ai");
      setInput(String(params.seed));
    }
  }, [params.seed]);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || sending) return;
    setInput("");
    setSending(true);
    setMessages((m) => [...m, { role: "user", content: text }]);
    Haptics.selectionAsync();

    try {
      const res = await api.chat(sessionId, text, "en");
      setMessages((m) => [...m, { role: "assistant", content: res.reply }]);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e: any) {
      const msg = String(e?.message || "");
      const friendly = msg.includes("429")
        ? "You've reached today's chat limit. Please try again later."
        : "Sorry — I couldn't respond right now. Please try again.";
      setMessages((m) => [
        ...m,
        { role: "assistant", content: friendly },
      ]);
    } finally {
      setSending(false);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);
    }
  }, [input, sending, sessionId]);

  const doSearch = useCallback(async () => {
    if (!q.trim()) return;
    setSearching(true);
    try {
      const res = await api.search(q.trim(), lang);
      setResults(res.results || []);
    } catch (e) {
      console.log(e);
    } finally {
      setSearching(false);
    }
  }, [q, lang]);

  // Auto-search with debounce (300ms) — reactive & fast, no manual button tap
  useEffect(() => {
    if (mode !== "search") return;
    const trimmed = q.trim();
    if (trimmed.length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    const handle = setTimeout(async () => {
      try {
        const res = await api.search(trimmed, lang);
        setResults(res.results || []);
      } catch (e) {
        console.log(e);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => clearTimeout(handle);
  }, [q, lang, mode]);

  const clearChat = async () => {
    if (!sessionId) return;
    await api.clearChat(sessionId);
    setMessages([]);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: c.surface }}
    >
      {/* Header */}
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + spacing.sm, backgroundColor: c.surface, borderBottomColor: c.divider },
        ]}
      >
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.onSurface }]}>Search & AI</Text>
          <Text style={[styles.subtitle, { color: c.onSurfaceSecondary }]}>
            Scripture · Bible study · sermon prep
          </Text>
        </View>
        {mode === "ai" && messages.length > 0 && (
          <Pressable onPress={clearChat} style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary }]} testID="clear-chat-btn">
            <Feather name="trash-2" size={16} color={c.onSurface} />
          </Pressable>
        )}
      </View>

      {/* Mode tabs */}
      <View style={styles.tabs}>
        <Pressable
          onPress={() => setMode("ai")}
          style={[styles.tab, mode === "ai" && { borderBottomColor: c.brandTertiary }]}
          testID="mode-ai"
        >
          <Feather name="cpu" size={14} color={mode === "ai" ? c.brandTertiary : c.onSurfaceTertiary} />
          <Text style={{ color: mode === "ai" ? c.onSurface : c.onSurfaceTertiary, fontWeight: "700" }}>
            AI Assistant
          </Text>
        </Pressable>
        <Pressable
          onPress={() => setMode("search")}
          style={[styles.tab, mode === "search" && { borderBottomColor: c.brandTertiary }]}
          testID="mode-search"
        >
          <Feather name="search" size={14} color={mode === "search" ? c.brandTertiary : c.onSurfaceTertiary} />
          <Text style={{ color: mode === "search" ? c.onSurface : c.onSurfaceTertiary, fontWeight: "700" }}>
            Scripture Search
          </Text>
        </Pressable>
      </View>

      {mode === "ai" ? (
        <>
          <ScrollView
            ref={scrollRef}
            style={{ flex: 1 }}
            contentContainerStyle={{ padding: spacing.lg, paddingBottom: 20 }}
            keyboardShouldPersistTaps="handled"
          >
            {messages.length === 0 && (
              <View>
                <View style={[styles.introCard, { backgroundColor: c.brand }]}>
                  <View style={styles.introBadge}>
                    <Feather name="feather" size={12} color="#0A0D14" />
                    <Text style={styles.introBadgeTxt}>Hope Church AI</Text>
                  </View>
                  <Text style={styles.introTitle}>
                    Ask the Bible anything.
                  </Text>
                  <Text style={styles.introSubtitle}>
                    Verse explanations, word studies, sermon preparation, and pastoral guidance — grounded in Scripture.
                  </Text>
                </View>

                <Text style={[styles.suggestedLabel, { color: c.onSurfaceTertiary }]}>
                  TRY ASKING
                </Text>
                {SUGGESTED.map((s) => (
                  <Pressable
                    key={s}
                    onPress={() => setInput(s)}
                    style={[
                      styles.suggestion,
                      { backgroundColor: c.surfaceSecondary, borderColor: c.border },
                    ]}
                    testID={`suggestion-${s.slice(0, 8)}`}
                  >
                    <Feather name="corner-down-right" size={14} color={c.brandTertiary} />
                    <Text style={{ color: c.onSurface, flex: 1, fontSize: 14 }}>{s}</Text>
                  </Pressable>
                ))}
              </View>
            )}

            {messages.map((m, i) => (
              <View
                key={i}
                style={[
                  styles.msg,
                  m.role === "user"
                    ? { alignSelf: "flex-end", backgroundColor: c.brand }
                    : { alignSelf: "flex-start", backgroundColor: c.surfaceSecondary, borderColor: c.border, borderWidth: StyleSheet.hairlineWidth },
                ]}
              >
                {m.role === "assistant" && (
                  <View style={styles.msgHeader}>
                    <View style={[styles.avatarSm, { backgroundColor: c.brandTertiary }]}>
                      <Feather name="feather" size={10} color="#0A0D14" />
                    </View>
                    <Text style={{ color: c.onSurfaceTertiary, fontSize: 11, fontWeight: "700", letterSpacing: 0.5 }}>
                      HOPE AI
                    </Text>
                  </View>
                )}
                <Text style={{ color: m.role === "user" ? "#FFFFFF" : c.onSurface, fontSize: 15, lineHeight: 22 }}>
                  {m.content}
                </Text>
              </View>
            ))}
            {sending && (
              <View
                style={[
                  styles.msg,
                  { alignSelf: "flex-start", backgroundColor: c.surfaceSecondary, flexDirection: "row", alignItems: "center", gap: 8 },
                ]}
              >
                <ActivityIndicator size="small" color={c.brandTertiary} />
                <Text style={{ color: c.onSurfaceSecondary, fontSize: 13 }}>Meditating on Scripture…</Text>
              </View>
            )}
          </ScrollView>

          <View style={[styles.inputBar, { backgroundColor: c.surface, borderTopColor: c.divider, paddingBottom: insets.bottom + 78 }]}>
            <View style={[styles.inputWrap, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
              <TextInput
                value={input}
                onChangeText={setInput}
                placeholder="Ask about a verse, doctrine, or topic…"
                placeholderTextColor={c.onSurfaceTertiary}
                style={[styles.input, { color: c.onSurface }]}
                multiline
                testID="ai-input"
              />
              <Pressable
                onPress={send}
                disabled={sending || !input.trim()}
                style={[
                  styles.sendBtn,
                  { backgroundColor: input.trim() && !sending ? c.brand : c.borderStrong },
                ]}
                testID="ai-send-btn"
              >
                <Feather name="arrow-up" size={18} color="#FFFFFF" />
              </Pressable>
            </View>
          </View>
        </>
      ) : (
        <View style={{ flex: 1 }}>
          <View style={{ padding: spacing.lg, gap: spacing.md }}>
            <View style={[styles.searchWrap, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
              <Feather name="search" size={16} color={c.onSurfaceTertiary} />
              <TextInput
                value={q}
                onChangeText={setQ}
                onSubmitEditing={doSearch}
                placeholder="Search Scripture…"
                placeholderTextColor={c.onSurfaceTertiary}
                style={[styles.searchInput, { color: c.onSurface }]}
                testID="search-input"
              />
              <Pressable onPress={doSearch} style={[styles.searchBtn, { backgroundColor: c.brand }]} testID="search-go-btn">
                <Text style={{ color: "#FFFFFF", fontWeight: "700", fontSize: 12 }}>Go</Text>
              </Pressable>
            </View>
            <View style={{ flexDirection: "row", gap: spacing.sm }}>
              {(["en", "ar"] as const).map((l) => (
                <Pressable
                  key={l}
                  onPress={() => setLang(l)}
                  style={[
                    styles.langChip,
                    {
                      backgroundColor: lang === l ? c.brand : c.surfaceSecondary,
                      borderColor: lang === l ? c.brand : c.border,
                    },
                  ]}
                  testID={`search-lang-${l}`}
                >
                  <Text style={{ color: lang === l ? "#FFFFFF" : c.onSurfaceSecondary, fontWeight: "700", fontSize: 12 }}>
                    {l === "en" ? "English" : "العربية"}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <ScrollView contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 120 }}>
            {searching && (
              <View style={{ paddingTop: 40, alignItems: "center" }}>
                <ActivityIndicator color={c.brandTertiary} />
              </View>
            )}
            {!searching && results.length === 0 && q && (
              <Text style={{ color: c.onSurfaceTertiary, textAlign: "center", marginTop: 40 }}>
                No results. Try another keyword.
              </Text>
            )}
            {results.map((r, i) => (
              <View
                key={i}
                style={[styles.resultCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
              >
                <Text style={{ color: c.brandTertiary, fontSize: 12, fontWeight: "800", letterSpacing: 1 }}>
                  {`${r.book_name_en} ${r.chapter}:${r.verse}`}
                </Text>
                <Text style={{ color: c.onSurface, fontSize: 15, fontFamily: "Georgia", lineHeight: 22, marginTop: 6 }}>
                  {lang === "en" ? r.en : r.ar}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  title: { fontSize: 24, fontWeight: "700", fontFamily: "Georgia" },
  subtitle: { fontSize: 12, marginTop: 2 },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  tabs: {
    flexDirection: "row",
    paddingHorizontal: spacing.lg,
  },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },

  introCard: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    marginBottom: spacing.lg,
  },
  introBadge: {
    alignSelf: "flex-start",
    backgroundColor: "#F1D570",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radius.pill,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginBottom: spacing.sm,
  },
  introBadgeTxt: { fontSize: 10, fontWeight: "800", color: "#0A0D14", letterSpacing: 0.5 },
  introTitle: { fontSize: 22, fontWeight: "700", color: "#FFFFFF", fontFamily: "Georgia" },
  introSubtitle: { fontSize: 13, color: "rgba(255,255,255,0.8)", marginTop: 6, lineHeight: 20 },

  suggestedLabel: { fontSize: 11, fontWeight: "800", letterSpacing: 1.5, marginBottom: spacing.sm, marginTop: spacing.sm },
  suggestion: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },

  msg: {
    maxWidth: "88%",
    padding: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.md,
  },
  msgHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 4 },
  avatarSm: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  inputBar: {
    borderTopWidth: StyleSheet.hairlineWidth,
    padding: spacing.md,
  },
  inputWrap: {
    flexDirection: "row",
    alignItems: "flex-end",
    padding: 6,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
  },
  input: {
    flex: 1,
    fontSize: 15,
    paddingHorizontal: spacing.sm,
    paddingVertical: 8,
    maxHeight: 120,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },

  searchWrap: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: spacing.md,
    paddingRight: 4,
    paddingVertical: 4,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 15, paddingVertical: 8 },
  searchBtn: { paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.sm },
  langChip: {
    height: 32,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
  },
  resultCard: {
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
});
