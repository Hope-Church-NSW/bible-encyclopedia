import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather, FontAwesome5 } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

const CHURCH_HERO =
  "https://images.pexels.com/photos/11730160/pexels-photo-11730160.jpeg";

export default function ChurchScreen() {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const d = await api.church();
      setData(d);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openUrl = (url: string) => Linking.openURL(url).catch(() => {});

  const socialIcon = (platform: string): any => {
    const p = platform.toLowerCase();
    if (p.includes("x") && !p.includes("facebook")) return "twitter";
    if (p.includes("facebook")) return "facebook";
    if (p.includes("tiktok")) return "tiktok";
    if (p.includes("youtube")) return "youtube";
    if (p.includes("instagram")) return "instagram";
    if (p.includes("telegram")) return "telegram-plane";
    if (p.includes("whatsapp")) return "whatsapp";
    return "globe";
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: c.surface, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={c.brandTertiary} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: c.surface }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        {/* Hero */}
        <View style={styles.hero}>
          <Image source={{ uri: CHURCH_HERO }} style={StyleSheet.absoluteFill} contentFit="cover" />
          <LinearGradient
            colors={["rgba(0,35,102,0.35)", "rgba(0,35,102,0.85)", "rgba(0,17,50,0.98)"]}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.heroContent, { paddingTop: insets.top + spacing.md }]}>
            <Image
              source={require("../../assets/images/brand/hope-church-logo.png")}
              style={styles.heroLogo}
              contentFit="contain"
            />
            <Text style={styles.heroName}>{data.name_en}</Text>
            <Text style={styles.heroNameAr}>{data.name_ar}</Text>
            <Text style={styles.heroTagline}>{data.tagline_en}</Text>
          </View>
        </View>

        {/* Vision & Mission */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Our Vision</Text>
          <Text style={[styles.paragraph, { color: c.onSurfaceSecondary }]}>{data.vision_en}</Text>
          <Text style={[styles.paragraphAr, { color: c.onSurfaceSecondary }]}>{data.vision_ar}</Text>

          <Text style={[styles.sectionTitle, { color: c.onSurface, marginTop: spacing.lg }]}>Our Mission</Text>
          <Text style={[styles.paragraph, { color: c.onSurfaceSecondary }]}>{data.mission_en}</Text>
          <Text style={[styles.paragraphAr, { color: c.onSurfaceSecondary }]}>{data.mission_ar}</Text>
        </View>

        {/* Ministries */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Ministries</Text>
          <View style={styles.grid}>
            {data.ministries.map((m: any, i: number) => (
              <View key={i} style={[styles.gridCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
                <View style={[styles.gridIcon, { backgroundColor: i % 3 === 0 ? c.brandPrimary : i % 3 === 1 ? c.brandSecondary : c.brandTertiary }]}>
                  <Feather name={i % 5 === 0 ? "sun" : i % 5 === 1 ? "users" : i % 5 === 2 ? "smile" : i % 5 === 3 ? "book" : "heart"} size={16} color={i % 3 === 2 ? "#0A0D14" : "#FFFFFF"} />
                </View>
                <Text style={[styles.gridTitle, { color: c.onSurface }]}>{m.name_en}</Text>
                <Text style={[styles.gridTitleAr, { color: c.onSurfaceSecondary }]}>{m.name_ar}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Weekly meetings */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Weekly Meetings</Text>
          {data.events.map((e: any, i: number) => (
            <View key={i} style={[styles.eventRow, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
              <View style={[styles.eventDay, { backgroundColor: c.brand }]}>
                <Text style={styles.eventDayTxt}>{e.day.slice(0, 3).toUpperCase()}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.eventTitle, { color: c.onSurface }]}>{e.title_en}</Text>
                <Text style={[styles.eventTitleAr, { color: c.onSurfaceSecondary }]}>{e.title_ar}</Text>
                <Text style={[styles.eventMeta, { color: c.onSurfaceTertiary }]}>
                  {e.time} · {e.location}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Sermons */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Recent Sermons</Text>
          {data.sermons.map((s: any, i: number) => (
            <Pressable
              key={i}
              style={[styles.sermonCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
              testID={`sermon-${i}`}
            >
              <View style={[styles.sermonIcon, { backgroundColor: c.brandSecondary + "20" }]}>
                <Feather name="play" size={22} color={c.brandSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sermonTitle, { color: c.onSurface }]}>{s.title_en}</Text>
                <Text style={[styles.sermonTitleAr, { color: c.onSurfaceSecondary }]}>{s.title_ar}</Text>
                <Text style={[styles.eventMeta, { color: c.onSurfaceTertiary }]}>
                  {s.speaker} · {s.date}
                </Text>
              </View>
              <Feather name="chevron-right" size={18} color={c.onSurfaceTertiary} />
            </Pressable>
          ))}
        </View>

        {/* Social */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Connect With Us</Text>
          <View style={styles.socialRow}>
            {data.socials.map((s: any, i: number) => (
              <Pressable
                key={i}
                onPress={() => openUrl(s.url)}
                style={[styles.socialBtn, { backgroundColor: c.brand }]}
                testID={`social-${s.platform.replace(/\s/g, '')}`}
              >
                <FontAwesome5 name={socialIcon(s.platform)} size={18} color="#F1D570" />
                <Text style={styles.socialLabel} numberOfLines={1}>{s.platform}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Share the App */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: c.onSurface }]}>Share the App · شارك التطبيق</Text>
          <Pressable
            onPress={() => router.push("/share")}
            style={[styles.shareCard, { backgroundColor: c.brand }]}
            testID="church-share-cta"
          >
            <LinearGradient
              colors={[c.brand, c.brandPrimary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.shareQrThumb}>
              <Image
                source={require("../../assets/images/brand/share-qr.jpg")}
                style={{ width: 64, height: 64 }}
                contentFit="contain"
              />
            </View>
            <View style={{ flex: 1, marginLeft: spacing.md }}>
              <Text style={styles.shareTitle}>Scan · Share · Bless</Text>
              <Text style={styles.shareSubtitle}>Send Hope Church Bible to a friend</Text>
              <Text style={styles.shareSubtitleAr}>شارك تطبيق الكنيسة مع صديق</Text>
            </View>
            <Feather name="arrow-right" size={20} color="#F1D570" />
          </Pressable>
        </View>

        {/* Footer */}
        <View style={[styles.footer, { backgroundColor: c.surfaceSecondary }]}>
          <Image
            source={require("../../assets/images/brand/hope-church-logo.png")}
            style={styles.footerLogo}
            contentFit="contain"
          />
          <Text style={[styles.footerTitle, { color: c.onSurface }]}>Hope Church Sydney</Text>
          <Text style={[styles.footerTitleAr, { color: c.onSurfaceSecondary }]}>كنيسة رجاء الأمم – سيدني</Text>
          <Text style={[styles.footerNote, { color: c.onSurfaceTertiary }]}>
            {data.contact.location}{"\n"}
            {data.contact.email}
          </Text>
          <View style={[styles.divider, { backgroundColor: c.brandTertiary }]} />
          <Text style={[styles.footerPowered, { color: c.onSurfaceTertiary }]}>
            Produced and Sponsored by{"\n"}
            <Text style={{ color: c.onSurfaceSecondary, fontWeight: "700" }}>Hope Church Sydney</Text>
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: {
    height: 340,
    overflow: "hidden",
  },
  heroContent: {
    flex: 1,
    padding: spacing.lg,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  heroLogo: { width: 96, height: 96, marginBottom: spacing.md },
  heroName: {
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Georgia",
    textAlign: "center",
  },
  heroNameAr: {
    fontSize: 16,
    color: "#F1D570",
    marginTop: 6,
    fontWeight: "600",
    textAlign: "center",
  },
  heroTagline: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginTop: 8,
    fontStyle: "italic",
    textAlign: "center",
  },
  section: { padding: spacing.lg },
  sectionTitle: { fontSize: 20, fontWeight: "700", fontFamily: "Georgia", marginBottom: spacing.sm },
  paragraph: { fontSize: 14, lineHeight: 22 },
  paragraphAr: { fontSize: 14, lineHeight: 22, marginTop: 6, textAlign: "right" },

  grid: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  gridCard: {
    width: "48%",
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  gridIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.sm,
  },
  gridTitle: { fontSize: 14, fontWeight: "700", fontFamily: "Georgia" },
  gridTitleAr: { fontSize: 12, marginTop: 2 },

  eventRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
    gap: spacing.md,
  },
  eventDay: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  eventDayTxt: { color: "#FFFFFF", fontWeight: "800", fontSize: 12, letterSpacing: 0.5 },
  eventTitle: { fontSize: 15, fontWeight: "700", fontFamily: "Georgia" },
  eventTitleAr: { fontSize: 12, marginTop: 2 },
  eventMeta: { fontSize: 11, marginTop: 4 },

  sermonCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
    gap: spacing.md,
  },
  sermonIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  sermonTitle: { fontSize: 15, fontWeight: "700", fontFamily: "Georgia" },
  sermonTitleAr: { fontSize: 12, marginTop: 2 },

  socialRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
  },
  socialBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
    borderRadius: radius.md,
    minWidth: "48%",
  },
  socialLabel: { color: "#FFFFFF", fontWeight: "700", fontSize: 12 },

  footer: {
    padding: spacing.xl,
    alignItems: "center",
    marginTop: spacing.md,
  },
  footerLogo: { width: 64, height: 64, marginBottom: spacing.sm },
  shareCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    borderRadius: radius.md,
    overflow: "hidden",
  },
  shareQrThumb: {
    width: 72,
    height: 72,
    borderRadius: 10,
    backgroundColor: "#FFFFFF",
    padding: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  shareTitle: { color: "#FFFFFF", fontSize: 15, fontWeight: "700", fontFamily: "Georgia" },
  shareSubtitle: { color: "rgba(255,255,255,0.9)", fontSize: 12, marginTop: 2 },
  shareSubtitleAr: { color: "#F1D570", fontSize: 12, marginTop: 2, fontWeight: "600" },
  footerTitle: { fontSize: 16, fontWeight: "700", fontFamily: "Georgia" },
  footerTitleAr: { fontSize: 13, marginTop: 2 },
  footerNote: { fontSize: 12, textAlign: "center", marginTop: spacing.sm, lineHeight: 18 },
  divider: { width: 40, height: 2, borderRadius: 1, marginVertical: spacing.md },
  footerPowered: { fontSize: 11, textAlign: "center", lineHeight: 18, fontStyle: "italic" },
});
