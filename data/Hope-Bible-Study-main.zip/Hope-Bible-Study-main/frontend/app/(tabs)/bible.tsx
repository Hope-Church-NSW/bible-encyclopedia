import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

type Book = {
  id: string;
  name_en: string;
  name_ar: string;
  testament: string;
  total_chapters: number;
};

export default function BibleScreen() {
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const router = useRouter();

  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"ALL" | "OT" | "NT">("ALL");
  const [query, setQuery] = useState("");

  const load = useCallback(async () => {
    try {
      const b = await api.books();
      setBooks(b);
    } catch (e) {
      console.log("books err", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = books.filter((b) => {
    if (filter !== "ALL" && b.testament !== filter) return false;
    if (query) {
      const q = query.toLowerCase();
      return b.name_en.toLowerCase().includes(q) || b.name_ar.includes(query);
    }
    return true;
  });

  return (
    <View style={[styles.root, { backgroundColor: c.surface }]}>
      {/* Sticky header */}
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + spacing.sm, backgroundColor: c.surface, borderBottomColor: c.divider },
        ]}
      >
        <Text style={[styles.title, { color: c.onSurface }]}>Holy Bible</Text>
        <Text style={[styles.titleAr, { color: c.onSurfaceSecondary }]}>
          الكتاب المقدس
        </Text>

        <View style={[styles.searchBox, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
          <Feather name="search" size={16} color={c.onSurfaceTertiary} />
          <TextInput
            placeholder="Search book…"
            placeholderTextColor={c.onSurfaceTertiary}
            style={[styles.searchInput, { color: c.onSurface }]}
            value={query}
            onChangeText={setQuery}
            testID="book-search-input"
          />
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}
          style={styles.chipRow}
        >
          {(["ALL", "OT", "NT"] as const).map((f) => (
            <Pressable
              key={f}
              onPress={() => setFilter(f)}
              testID={`filter-${f}`}
              style={[
                styles.chip,
                {
                  backgroundColor: filter === f ? c.brand : c.surfaceSecondary,
                  borderColor: filter === f ? c.brand : c.border,
                },
              ]}
            >
              <Text style={{ color: filter === f ? "#FFFFFF" : c.onSurfaceSecondary, fontWeight: "700", fontSize: 12 }}>
                {f === "ALL" ? "All Books" : f === "OT" ? "Old Testament" : "New Testament"}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={c.brandTertiary} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
          {filtered.map((b) => (
            <BookRow
              key={b.id}
              book={b}
              onPress={() =>
                router.push(
                  `/reader/${b.id}/${Object.keys({ 1: 1 })[0]}` // fallback - just use 1
                )
              }
              onChapter={(ch) => router.push(`/reader/${b.id}/${ch}`)}
            />
          ))}
          {filtered.length === 0 && (
            <Text style={{ color: c.onSurfaceTertiary, textAlign: "center", marginTop: 40 }}>
              No books match your search.
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function BookRow({
  book,
  onChapter,
}: {
  book: Book;
  onPress: () => void;
  onChapter: (ch: number) => void;
}) {
  const { c } = useTheme();
  const [expanded, setExpanded] = useState(false);

  return (
    <View style={[styles.bookCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
      <Pressable
        onPress={() => setExpanded((e) => !e)}
        style={styles.bookHeader}
        testID={`book-${book.id}`}
      >
        <View
          style={[
            styles.bookBadge,
            { backgroundColor: book.testament === "OT" ? c.brandPrimary : c.brandSecondary },
          ]}
        >
          <Text style={styles.bookBadgeTxt}>{book.testament}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.bookName, { color: c.onSurface }]}>{book.name_en}</Text>
          <Text style={[styles.bookNameAr, { color: c.onSurfaceSecondary }]}>{book.name_ar}</Text>
        </View>
        <Text style={[styles.bookChapters, { color: c.onSurfaceTertiary }]}>
          {book.total_chapters} ch
        </Text>
        <Feather
          name={expanded ? "chevron-up" : "chevron-down"}
          size={18}
          color={c.onSurfaceTertiary}
          style={{ marginLeft: spacing.sm }}
        />
      </Pressable>
      {expanded && (
        <View style={styles.chGrid}>
          {Array.from({ length: book.total_chapters }, (_, i) => i + 1).map((ch) => (
            <Pressable
              key={ch}
              onPress={() => onChapter(ch)}
              style={[styles.chBtn, { borderColor: c.borderStrong, backgroundColor: c.surface }]}
              testID={`chapter-${book.id}-${ch}`}
            >
              <Text style={{ color: c.brand, fontWeight: "700" }}>{ch}</Text>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: spacing.lg,
    paddingBottom: 0,
  },
  title: { fontSize: 28, fontFamily: "Georgia", fontWeight: "700", letterSpacing: 0.2 },
  titleAr: { fontSize: 14, marginTop: 2 },
  searchBox: {
    marginTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 14 },
  chipRow: { marginHorizontal: -spacing.lg },
  chip: {
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  bookCard: {
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.md,
    overflow: "hidden",
  },
  bookHeader: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    gap: spacing.md,
  },
  bookBadge: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  bookBadgeTxt: { color: "#FFFFFF", fontWeight: "800", fontSize: 11, letterSpacing: 0.5 },
  bookName: { fontSize: 16, fontFamily: "Georgia", fontWeight: "700" },
  bookNameAr: { fontSize: 12, marginTop: 2 },
  bookChapters: { fontSize: 12, fontWeight: "600" },
  chGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    padding: spacing.md,
    paddingTop: 0,
    gap: spacing.sm,
  },
  chBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
  },
});
