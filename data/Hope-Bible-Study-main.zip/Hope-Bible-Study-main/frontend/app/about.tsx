import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Linking,
  Modal,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import * as Haptics from "expo-haptics";

import { api } from "@/src/api/client";
import { useTheme } from "@/src/theme/use-theme";
import { spacing, radius } from "@/src/theme/tokens";

const APP_VERSION = "1.0.0";
const APP_URL =
  (typeof process !== "undefined" &&
    (process.env as any)?.EXPO_PUBLIC_BACKEND_URL) ||
  "https://hope-bible-study.preview.emergentagent.com";

export default function AboutScreen() {
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const router = useRouter();

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteResult, setDeleteResult] = useState<string | null>(null);

  const doDeleteMyData = async () => {
    try {
      setDeleting(true);
      const r = await api.deleteMyData();
      const total = Object.values(r.deleted || {}).reduce((a: any, b: any) => a + b, 0);
      setDeleteResult(`Deleted ${total} item(s). Your local device data was cleared.`);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      setDeleteResult("Could not delete. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: c.surface }}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm, borderBottomColor: c.divider }]}>
        <Pressable
          onPress={() => router.back()}
          style={[styles.iconBtn, { backgroundColor: c.surfaceSecondary }]}
          testID="about-back-btn"
        >
          <Feather name="chevron-left" size={20} color={c.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.onSurface }]}>About</Text>
          <Text style={[styles.subtitle, { color: c.onSurfaceSecondary }]}>حول التطبيق</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
        {/* Hero */}
        <View style={styles.hero} testID="about-hero">
          <LinearGradient
            colors={[c.brand, c.brandPrimary, "#01123f"]}
            style={StyleSheet.absoluteFill}
          />
          <Image
            source={require("../assets/images/brand/hope-church-logo.png")}
            style={styles.logo}
            contentFit="contain"
          />
          <Text style={styles.appName}>Hope Church Sydney Bible</Text>
          <Text style={styles.appNameAr}>الكتاب المقدس · كنيسة رجاء الأمم</Text>
          <View style={styles.divider} />
          <Text style={styles.version}>v{APP_VERSION}</Text>
        </View>

        {/* Description */}
        <Text style={[styles.paragraph, { color: c.onSurface }]}>
          The official Bible study app of Hope Church Sydney (كنيسة رجاء الأمم – سيدني). Read the whole Bible in Arabic (Van Dyke) and English, study with the AI Assistant, explore the Biblical Atlas, and grow with your church community.
        </Text>
        <Text style={[styles.paragraphAr, { color: c.onSurfaceSecondary }]}>
          التطبيق الرسمي لدراسة الكتاب المقدس لكنيسة رجاء الأمم – سيدني. اقرأ الكتاب المقدس كاملاً بالعربية (فاندايك) والإنجليزية، وادرس بمساعدة الذكاء الاصطناعي، واستكشف الأطلس الكتابي، وانمُ مع مجتمع كنيستك.
        </Text>

        {/* Quick facts */}
        <View style={styles.factsGrid}>
          <Fact icon="book-open" label_en="66 Books" label_ar="66 سفر" c={c} />
          <Fact icon="type" label_en="31,105 Verses" label_ar="31,105 آية" c={c} />
          <Fact icon="cpu" label_en="AI Study" label_ar="دراسة بالذكاء الاصطناعي" c={c} />
          <Fact icon="map" label_en="Biblical Atlas" label_ar="أطلس كتابي" c={c} />
        </View>

        {/* Share block */}
        <Pressable
          onPress={() => router.push("/share")}
          style={[styles.shareCta, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
          testID="about-open-share"
        >
          <View style={[styles.shareQr, { borderColor: c.brandTertiary }]}>
            <Image
              source={require("../assets/images/brand/share-qr.jpg")}
              style={{ width: 64, height: 64 }}
              contentFit="contain"
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.shareTitle, { color: c.onSurface }]}>Share the App</Text>
            <Text style={[styles.shareSubtitle, { color: c.onSurfaceSecondary }]}>شارك التطبيق مع أحبائك</Text>
            <Text style={[styles.shareHint, { color: c.brandTertiary }]}>
              Scan the QR or tap to share
            </Text>
          </View>
          <Feather name="arrow-right" size={20} color={c.brandTertiary} />
        </Pressable>

        {/* Links */}
        <Text style={[styles.sectionLabel, { color: c.onSurfaceTertiary }]}>CHURCH LINKS</Text>

        <LinkRow
          icon="facebook"
          label_en="Facebook — @hopechurchNSW"
          label_ar="فيسبوك"
          onPress={() => Linking.openURL("https://www.facebook.com/hopechurchNSW")}
          c={c}
          testID="about-facebook"
        />
        <LinkRow
          icon="youtube"
          label_en="YouTube — Rev. Ashraf"
          label_ar="يوتيوب"
          onPress={() => Linking.openURL("https://youtube.com/user/revashraf1")}
          c={c}
          testID="about-youtube"
        />
        <LinkRow
          icon="twitter"
          label_en="X — @pastorAshraf"
          label_ar="إكس (تويتر)"
          onPress={() => Linking.openURL("https://x.com/pastorAshraf")}
          c={c}
          testID="about-x"
        />
        <LinkRow
          icon="globe"
          label_en={APP_URL}
          label_ar="رابط التطبيق"
          onPress={() => Linking.openURL(APP_URL)}
          c={c}
          testID="about-url"
        />

        <Text style={[styles.sectionLabel, { color: c.onSurfaceTertiary, marginTop: spacing.xl }]}>
          CREDITS · ATTRIBUTION
        </Text>
        <View style={[styles.creditsCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            • Arabic text — Smith & Van Dyke translation (public domain)
          </Text>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            • English text — World English Bible (public domain)
          </Text>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            • Audio Bible — Dr. Adel Noshi (via YouTube channel)
          </Text>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            • AI — Claude Sonnet 4.5
          </Text>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            • Biblical Atlas — Leaflet + CARTO tiles
          </Text>
        </View>

        <Text style={[styles.sectionLabel, { color: c.onSurfaceTertiary, marginTop: spacing.xl }]}>
          PRIVACY · خصوصية
        </Text>
        <View style={[styles.creditsCard, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary }]}>
            No sign-in required. Bookmarks, notes and prayers are stored under an anonymous per-device ID and are private to your device.
          </Text>
          <Text style={[styles.creditRow, { color: c.onSurfaceSecondary, marginTop: 6, textAlign: "right" }]}>
            التطبيق لا يتطلب تسجيل دخول. علاماتك وملاحظاتك وصلواتك مرتبطة بهوية مجهولة خاصة بجهازك فقط.
          </Text>
        </View>

        <Pressable
          onPress={() => Linking.openURL("https://www.hopechurchnsw.org.au/privacy")}
          style={[styles.linkRow, { backgroundColor: c.surfaceSecondary, borderColor: c.border, marginTop: spacing.md }]}
          testID="privacy-policy-link"
        >
          <View style={[styles.linkIcon, { backgroundColor: c.brand }]}>
            <Feather name="shield" size={14} color="#F1D570" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.onSurface, fontSize: 13, fontWeight: "700" }}>Privacy Policy</Text>
            <Text style={{ color: c.onSurfaceSecondary, fontSize: 11, marginTop: 1 }}>سياسة الخصوصية</Text>
          </View>
          <Feather name="external-link" size={15} color={c.onSurfaceTertiary} />
        </Pressable>

        <Pressable
          onPress={() => setShowDeleteConfirm(true)}
          style={[styles.linkRow, { backgroundColor: c.surfaceSecondary, borderColor: c.error, borderWidth: 1, marginTop: spacing.sm }]}
          testID="delete-my-data-btn"
        >
          <View style={[styles.linkIcon, { backgroundColor: c.error }]}>
            <Feather name="trash-2" size={14} color="#FFFFFF" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.error, fontSize: 13, fontWeight: "800" }}>Delete My Data</Text>
            <Text style={{ color: c.onSurfaceSecondary, fontSize: 11, marginTop: 1 }}>احذف جميع بياناتي</Text>
          </View>
          <Feather name="chevron-right" size={15} color={c.error} />
        </Pressable>

        {/* Footer */}
        <View style={styles.footer}>
          <View style={[styles.goldLine, { backgroundColor: c.brandTertiary }]} />
          <Text style={[styles.powered, { color: c.onSurfaceTertiary }]}>
            Produced and Sponsored by{"\n"}
            <Text style={{ color: c.onSurfaceSecondary, fontWeight: "700" }}>
              Hope Church Sydney · كنيسة رجاء الأمم – سيدني
            </Text>
          </Text>
        </View>
      </ScrollView>

      {/* Delete confirmation modal */}
      <Modal
        visible={showDeleteConfirm}
        transparent
        animationType="fade"
        onRequestClose={() => { setShowDeleteConfirm(false); setDeleteResult(null); }}
      >
        <Pressable
          style={styles.backdrop}
          onPress={() => { if (!deleting) { setShowDeleteConfirm(false); setDeleteResult(null); } }}
        >
          <Pressable
            style={[styles.confirmSheet, { backgroundColor: c.surface, borderColor: c.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={[styles.confirmIcon, { backgroundColor: c.error + "22" }]}>
              <Feather name="alert-triangle" size={22} color={c.error} />
            </View>
            <Text style={[styles.confirmTitle, { color: c.onSurface }]}>Delete all your data?</Text>
            <Text style={[styles.confirmTitleAr, { color: c.onSurfaceSecondary }]}>هل تريد حذف جميع بياناتك؟</Text>
            <Text style={[styles.confirmBody, { color: c.onSurfaceSecondary }]}>
              This permanently removes your bookmarks, highlights, notes, prayer requests and AI chat history from this device. This cannot be undone.
            </Text>
            {deleteResult ? (
              <Text style={[styles.confirmBody, { color: c.success, marginTop: spacing.sm, fontWeight: "700" }]}>
                {deleteResult}
              </Text>
            ) : null}
            <View style={{ flexDirection: "row", gap: spacing.md, marginTop: spacing.lg, width: "100%" }}>
              <Pressable
                onPress={() => { setShowDeleteConfirm(false); setDeleteResult(null); }}
                style={[styles.cbtn, { backgroundColor: c.surfaceSecondary }]}
                testID="delete-cancel-btn"
              >
                <Text style={{ color: c.onSurface, fontWeight: "700" }}>Cancel</Text>
              </Pressable>
              <Pressable
                onPress={doDeleteMyData}
                disabled={deleting || !!deleteResult}
                style={[styles.cbtn, { backgroundColor: c.error, flex: 1.4, opacity: deleting || deleteResult ? 0.6 : 1 }]}
                testID="delete-confirm-btn"
              >
                {deleting ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Text style={{ color: "#FFFFFF", fontWeight: "800" }}>{deleteResult ? "Done" : "Delete Forever"}</Text>
                )}
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function Fact({
  icon,
  label_en,
  label_ar,
  c,
}: {
  icon: any;
  label_en: string;
  label_ar: string;
  c: any;
}) {
  return (
    <View style={[styles.fact, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}>
      <View style={[styles.factIcon, { backgroundColor: c.brand + "22" }]}>
        <Feather name={icon} size={16} color={c.brandTertiary} />
      </View>
      <Text style={{ color: c.onSurface, fontSize: 13, fontWeight: "700", fontFamily: "Georgia" }}>
        {label_en}
      </Text>
      <Text style={{ color: c.onSurfaceSecondary, fontSize: 11, marginTop: 2 }}>{label_ar}</Text>
    </View>
  );
}

function LinkRow({
  icon,
  label_en,
  label_ar,
  onPress,
  c,
  testID,
}: {
  icon: any;
  label_en: string;
  label_ar: string;
  onPress: () => void;
  c: any;
  testID: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.linkRow, { backgroundColor: c.surfaceSecondary, borderColor: c.border }]}
      testID={testID}
    >
      <View style={[styles.linkIcon, { backgroundColor: c.brand }]}>
        <Feather name={icon} size={14} color="#F1D570" />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: c.onSurface, fontSize: 13, fontWeight: "700" }} numberOfLines={1}>
          {label_en}
        </Text>
        <Text style={{ color: c.onSurfaceSecondary, fontSize: 11, marginTop: 1 }}>{label_ar}</Text>
      </View>
      <Feather name="external-link" size={15} color={c.onSurfaceTertiary} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  iconBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 22, fontWeight: "700", fontFamily: "Georgia" },
  subtitle: { fontSize: 12, marginTop: 2 },

  hero: {
    alignItems: "center",
    padding: spacing.xl,
    borderRadius: radius.lg,
    overflow: "hidden",
    marginBottom: spacing.lg,
  },
  logo: { width: 96, height: 96 },
  appName: { color: "#FFFFFF", fontSize: 18, fontWeight: "700", fontFamily: "Georgia", marginTop: spacing.md, textAlign: "center" },
  appNameAr: { color: "#F1D570", fontSize: 13, marginTop: 4, fontWeight: "600", textAlign: "center" },
  divider: { width: 40, height: 2, backgroundColor: "#D4AF37", marginVertical: spacing.md, borderRadius: 1 },
  version: { color: "rgba(255,255,255,0.65)", fontSize: 11, letterSpacing: 1.2, fontWeight: "700" },

  paragraph: { fontSize: 14, lineHeight: 22, fontFamily: "Georgia", marginBottom: spacing.sm },
  paragraphAr: { fontSize: 13, lineHeight: 22, marginBottom: spacing.lg, textAlign: "right" },

  factsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  fact: {
    flexBasis: "48%",
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  factIcon: {
    width: 32,
    height: 32,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },

  shareCta: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.xl,
  },
  shareQr: {
    width: 72,
    height: 72,
    borderRadius: 10,
    borderWidth: 2,
    padding: 4,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },
  shareTitle: { fontSize: 15, fontWeight: "700", fontFamily: "Georgia" },
  shareSubtitle: { fontSize: 12, marginTop: 2 },
  shareHint: { fontSize: 11, marginTop: 4, fontWeight: "700", letterSpacing: 0.5 },

  sectionLabel: { fontSize: 11, fontWeight: "800", letterSpacing: 1.5, marginBottom: spacing.sm },

  linkRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  linkIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  creditsCard: {
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  creditRow: { fontSize: 12, lineHeight: 22 },

  footer: { alignItems: "center", marginTop: spacing.xl },
  goldLine: { width: 40, height: 2, borderRadius: 1, marginBottom: spacing.md },
  powered: { fontSize: 12, textAlign: "center", lineHeight: 20, fontStyle: "italic" },

  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", alignItems: "center", justifyContent: "center", padding: spacing.lg },
  confirmSheet: {
    width: "100%",
    maxWidth: 420,
    padding: spacing.xl,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
  },
  confirmIcon: { width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center", marginBottom: spacing.md },
  confirmTitle: { fontSize: 18, fontWeight: "800", fontFamily: "Georgia", textAlign: "center" },
  confirmTitleAr: { fontSize: 13, marginTop: 4, fontWeight: "600", textAlign: "center" },
  confirmBody: { fontSize: 13, lineHeight: 20, marginTop: spacing.sm, textAlign: "center" },
  cbtn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 12, borderRadius: radius.md },
});
