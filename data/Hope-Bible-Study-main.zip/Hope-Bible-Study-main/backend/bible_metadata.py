"""Rich Bible metadata — sections (pericope titles), cross-references, original
Hebrew/Greek words with Strong's numbers, and biblical locations.

Structure:
- SECTIONS[book_id][chapter] = [{start,end,title_en,title_ar}]
- CROSS_REFS[book_id][chapter][verse] = [{book_id,chapter,verse,label_en,label_ar}]
- ORIGINAL_WORDS[book_id][chapter][verse] = [{original, translit, lang, strong,
      meaning_en, meaning_ar, root_en, root_ar}]
- PLACES = [{id, name_en, name_ar, lat, lng, testament, description_en,
    description_ar, related_refs:[{book_id,chapter,verse,label_en,label_ar}]}]
"""

SECTIONS = {
    "gen": {
        1: [
            {"start": 1, "end": 2, "title_en": "The Beginning", "title_ar": "البدء"},
            {"start": 3, "end": 5, "title_en": "The First Day: Light", "title_ar": "اليوم الأول: النور"},
        ],
    },
    "psa": {
        23: [
            {"start": 1, "end": 3, "title_en": "The Lord My Shepherd", "title_ar": "الرب راعيَّ"},
            {"start": 4, "end": 6, "title_en": "Through the Valley", "title_ar": "في وادي ظل الموت"},
        ],
        91: [
            {"start": 1, "end": 2, "title_en": "Refuge in the Most High", "title_ar": "الملجأ في العلي"},
            {"start": 11, "end": 11, "title_en": "Angels Guarding", "title_ar": "الملائكة الحارسة"},
        ],
    },
    "isa": {
        53: [
            {"start": 3, "end": 6, "title_en": "The Suffering Servant", "title_ar": "العبد المتألم"},
        ],
    },
    "mat": {
        5: [
            {"start": 3, "end": 12, "title_en": "The Beatitudes", "title_ar": "التطويبات"},
            {"start": 14, "end": 16, "title_en": "Salt and Light", "title_ar": "الملح والنور"},
        ],
        6: [
            {"start": 9, "end": 13, "title_en": "The Lord's Prayer", "title_ar": "الصلاة الربانية"},
            {"start": 33, "end": 33, "title_en": "Seek First the Kingdom", "title_ar": "اطلبوا ملكوت الله أولاً"},
        ],
    },
    "joh": {
        1: [
            {"start": 1, "end": 14, "title_en": "The Word Became Flesh", "title_ar": "الكلمة صار جسداً"},
            {"start": 29, "end": 29, "title_en": "Behold, the Lamb of God", "title_ar": "هوذا حمل الله"},
        ],
        3: [
            {"start": 3, "end": 3, "title_en": "Born Again", "title_ar": "المولود من فوق"},
            {"start": 16, "end": 17, "title_en": "God So Loved the World", "title_ar": "هكذا أحب الله العالم"},
        ],
        14: [
            {"start": 1, "end": 6, "title_en": "The Way, the Truth, the Life", "title_ar": "الطريق والحق والحياة"},
            {"start": 27, "end": 27, "title_en": "My Peace I Give You", "title_ar": "سلامي أعطيكم"},
        ],
    },
    "rom": {
        8: [
            {"start": 1, "end": 1, "title_en": "No Condemnation", "title_ar": "لا شيء من الدينونة"},
            {"start": 28, "end": 28, "title_en": "All Things Work for Good", "title_ar": "كل الأشياء تعمل معاً للخير"},
            {"start": 38, "end": 39, "title_en": "More Than Conquerors", "title_ar": "أعظم من منتصرين"},
        ],
    },
    "phi": {
        4: [
            {"start": 4, "end": 7, "title_en": "Rejoice, Pray, Have Peace", "title_ar": "افرحوا، صلّوا، سلام الله"},
            {"start": 13, "end": 13, "title_en": "Strength in Christ", "title_ar": "قوة في المسيح"},
        ],
    },
}

CROSS_REFS = {
    "gen": {1: {
        1: [
            {"book_id": "joh", "chapter": 1, "verse": 1, "label_en": "John 1:1 — The Word in the beginning", "label_ar": "يوحنا 1:1 — الكلمة في البدء"},
            {"book_id": "psa", "chapter": 23, "verse": 1, "label_en": "Psalm 23:1 — The Shepherd Creator", "label_ar": "مزمور 23:1"},
        ],
        3: [
            {"book_id": "joh", "chapter": 1, "verse": 1, "label_en": "John 1:1-5 — Light shining", "label_ar": "يوحنا 1:1-5"},
        ],
    }},
    "psa": {23: {
        1: [
            {"book_id": "joh", "chapter": 14, "verse": 6, "label_en": "John 14:6 — I am the way", "label_ar": "يوحنا 14:6"},
            {"book_id": "isa", "chapter": 53, "verse": 6, "label_en": "Isaiah 53:6 — Like sheep gone astray", "label_ar": "إشعياء 53:6"},
        ],
        4: [
            {"book_id": "phi", "chapter": 4, "verse": 7, "label_en": "Philippians 4:7 — Peace of God", "label_ar": "فيلبي 4:7"},
        ],
    }, 91: {
        1: [
            {"book_id": "mat", "chapter": 6, "verse": 33, "label_en": "Matthew 6:33 — Seek first", "label_ar": "متى 6:33"},
        ],
        11: [
            {"book_id": "mat", "chapter": 4, "verse": 6, "label_en": "Quoted by Satan (Matt 4:6)", "label_ar": "استشهد بها الشيطان (متى 4:6)"},
        ],
    }},
    "isa": {53: {
        5: [
            {"book_id": "joh", "chapter": 3, "verse": 16, "label_en": "John 3:16 — God gave His Son", "label_ar": "يوحنا 3:16"},
            {"book_id": "rom", "chapter": 8, "verse": 1, "label_en": "Romans 8:1 — No condemnation", "label_ar": "رومية 8:1"},
        ],
        6: [
            {"book_id": "psa", "chapter": 23, "verse": 1, "label_en": "Psalm 23 — The Shepherd", "label_ar": "مزمور 23"},
        ],
    }},
    "joh": {1: {
        1: [
            {"book_id": "gen", "chapter": 1, "verse": 1, "label_en": "Genesis 1:1 — In the beginning", "label_ar": "تكوين 1:1"},
            {"book_id": "phi", "chapter": 4, "verse": 13, "label_en": "Philippians 4:13", "label_ar": "فيلبي 4:13"},
        ],
        14: [
            {"book_id": "isa", "chapter": 53, "verse": 3, "label_en": "Isaiah 53:3 — Man of sorrows", "label_ar": "إشعياء 53:3"},
        ],
        29: [
            {"book_id": "isa", "chapter": 53, "verse": 5, "label_en": "Isaiah 53:5 — Wounded for us", "label_ar": "إشعياء 53:5"},
        ],
    }, 3: {
        16: [
            {"book_id": "isa", "chapter": 53, "verse": 5, "label_en": "Isaiah 53:5 — He was pierced", "label_ar": "إشعياء 53:5"},
            {"book_id": "rom", "chapter": 8, "verse": 39, "label_en": "Romans 8:39 — Nothing separates", "label_ar": "رومية 8:39"},
            {"book_id": "joh", "chapter": 1, "verse": 14, "label_en": "John 1:14 — Word became flesh", "label_ar": "يوحنا 1:14"},
        ],
    }, 14: {
        6: [
            {"book_id": "joh", "chapter": 1, "verse": 1, "label_en": "John 1:1 — The Word", "label_ar": "يوحنا 1:1"},
            {"book_id": "psa", "chapter": 23, "verse": 1, "label_en": "Psalm 23:1 — The Lord my shepherd", "label_ar": "مزمور 23:1"},
        ],
        27: [
            {"book_id": "phi", "chapter": 4, "verse": 7, "label_en": "Philippians 4:7 — Peace of God", "label_ar": "فيلبي 4:7"},
        ],
    }},
    "mat": {5: {
        3: [
            {"book_id": "psa", "chapter": 23, "verse": 1, "label_en": "Psalm 23 — Shepherd's care", "label_ar": "مزمور 23"},
        ],
        16: [
            {"book_id": "joh", "chapter": 1, "verse": 14, "label_en": "John 1:14 — His glory", "label_ar": "يوحنا 1:14"},
        ],
    }, 6: {
        33: [
            {"book_id": "phi", "chapter": 4, "verse": 6, "label_en": "Philippians 4:6", "label_ar": "فيلبي 4:6"},
            {"book_id": "psa", "chapter": 91, "verse": 1, "label_en": "Psalm 91:1", "label_ar": "مزمور 91:1"},
        ],
    }},
    "rom": {8: {
        1: [
            {"book_id": "isa", "chapter": 53, "verse": 5, "label_en": "Isaiah 53:5 — By His wounds", "label_ar": "إشعياء 53:5"},
            {"book_id": "joh", "chapter": 3, "verse": 17, "label_en": "John 3:17 — Not to condemn", "label_ar": "يوحنا 3:17"},
        ],
        28: [
            {"book_id": "phi", "chapter": 4, "verse": 13, "label_en": "Philippians 4:13", "label_ar": "فيلبي 4:13"},
        ],
    }},
    "phi": {4: {
        7: [
            {"book_id": "joh", "chapter": 14, "verse": 27, "label_en": "John 14:27 — My peace", "label_ar": "يوحنا 14:27"},
        ],
        13: [
            {"book_id": "rom", "chapter": 8, "verse": 28, "label_en": "Romans 8:28", "label_ar": "رومية 8:28"},
        ],
    }},
}

ORIGINAL_WORDS = {
    "gen": {1: {
        1: [
            {"original": "בְּרֵאשִׁית", "translit": "bereshit", "lang": "hebrew", "strong": "H7225",
             "meaning_en": "In the beginning; first, chief, best", "meaning_ar": "في البدء؛ الأول، الأعظم",
             "root_en": "רֹאשׁ (rosh) — head", "root_ar": "رأس (رأس، بداية)"},
            {"original": "בָּרָא", "translit": "bara", "lang": "hebrew", "strong": "H1254",
             "meaning_en": "To create, shape (used only of God's creating)", "meaning_ar": "خلق، أنشأ من العدم (يستخدم لله وحده)",
             "root_en": "bara — to create ex nihilo", "root_ar": "الخلق من العدم"},
            {"original": "אֱלֹהִים", "translit": "Elohim", "lang": "hebrew", "strong": "H430",
             "meaning_en": "God; plural of majesty referring to the One True God", "meaning_ar": "الله؛ صيغة الجمع للتعظيم تشير إلى الله الواحد",
             "root_en": "El — mighty, strong", "root_ar": "إيل (القوي)"},
        ],
        3: [
            {"original": "אוֹר", "translit": "or", "lang": "hebrew", "strong": "H216",
             "meaning_en": "Light; brightness, illumination", "meaning_ar": "نور، ضياء",
             "root_en": "or — to be luminous", "root_ar": "أور (يضيء)"},
        ],
    }},
    "joh": {1: {
        1: [
            {"original": "λόγος", "translit": "logos", "lang": "greek", "strong": "G3056",
             "meaning_en": "Word, divine expression, the eternal Son", "meaning_ar": "الكلمة، التعبير الإلهي، الابن الأزلي",
             "root_en": "legō — to speak", "root_ar": "لِيغو (يتكلم)"},
            {"original": "θεός", "translit": "theos", "lang": "greek", "strong": "G2316",
             "meaning_en": "God, the Divine Being", "meaning_ar": "الله، الكائن الإلهي",
             "root_en": "theos — deity", "root_ar": "ثيؤس (الإله)"},
        ],
        14: [
            {"original": "σάρξ", "translit": "sarx", "lang": "greek", "strong": "G4561",
             "meaning_en": "Flesh; human nature", "meaning_ar": "جسد؛ الطبيعة البشرية",
             "root_en": "sarx — flesh", "root_ar": "سارْكس (جسد)"},
            {"original": "χάρις", "translit": "charis", "lang": "greek", "strong": "G5485",
             "meaning_en": "Grace, unmerited favor", "meaning_ar": "نعمة، حظوة مجانية",
             "root_en": "chairō — to rejoice", "root_ar": "خايرو (يفرح)"},
        ],
    }, 3: {
        16: [
            {"original": "ἀγαπάω", "translit": "agapaō", "lang": "greek", "strong": "G25",
             "meaning_en": "To love (self-giving, unconditional love)", "meaning_ar": "أحبَّ (المحبة الباذلة غير المشروطة)",
             "root_en": "agapē — divine love", "root_ar": "أغابي (المحبة الإلهية)"},
            {"original": "κόσμος", "translit": "kosmos", "lang": "greek", "strong": "G2889",
             "meaning_en": "World; the ordered universe, humanity", "meaning_ar": "العالم؛ الكون المنظم، البشرية",
             "root_en": "kosmos — order", "root_ar": "كوسموس (نظام)"},
            {"original": "μονογενής", "translit": "monogenēs", "lang": "greek", "strong": "G3439",
             "meaning_en": "Only-begotten, unique, one-of-a-kind", "meaning_ar": "الوحيد، الفريد، الأحد المولود",
             "root_en": "monos + genos — sole kind", "root_ar": "مونوس + جينوس (نوع فريد)"},
            {"original": "αἰώνιος", "translit": "aiōnios", "lang": "greek", "strong": "G166",
             "meaning_en": "Eternal, everlasting, without end", "meaning_ar": "أبدي، سرمدي، بلا نهاية",
             "root_en": "aiōn — age", "root_ar": "أيون (دهر)"},
        ],
    }, 14: {
        6: [
            {"original": "ὁδός", "translit": "hodos", "lang": "greek", "strong": "G3598",
             "meaning_en": "Way, road, journey", "meaning_ar": "طريق، سبيل، مسيرة",
             "root_en": "hodos — path", "root_ar": "هودوس (مسلك)"},
            {"original": "ἀλήθεια", "translit": "alētheia", "lang": "greek", "strong": "G225",
             "meaning_en": "Truth, reality, that which is true", "meaning_ar": "الحق، الحقيقة",
             "root_en": "alēthēs — unconcealed", "root_ar": "أليثيس (المكشوف)"},
            {"original": "ζωή", "translit": "zōē", "lang": "greek", "strong": "G2222",
             "meaning_en": "Life; divine, eternal life", "meaning_ar": "الحياة؛ الحياة الأبدية الإلهية",
             "root_en": "zaō — to live", "root_ar": "زاو (يحيا)"},
        ],
    }},
    "psa": {23: {
        1: [
            {"original": "יְהוָה", "translit": "YHWH (Adonai)", "lang": "hebrew", "strong": "H3068",
             "meaning_en": "The LORD; the covenant name of God", "meaning_ar": "الرب؛ اسم عهد الله",
             "root_en": "hayah — to be", "root_ar": "هاياه (الكائن)"},
            {"original": "רֹעֶה", "translit": "ro'eh", "lang": "hebrew", "strong": "H7462",
             "meaning_en": "Shepherd; one who tends and feeds", "meaning_ar": "الراعي؛ الذي يرعى ويطعم",
             "root_en": "ra'ah — to pasture", "root_ar": "راعا (يرعى)"},
        ],
    }},
    "isa": {53: {
        5: [
            {"original": "מְחֹלָל", "translit": "mecholal", "lang": "hebrew", "strong": "H2490",
             "meaning_en": "Pierced, wounded through", "meaning_ar": "مطعون، مجروح",
             "root_en": "chalal — to bore through", "root_ar": "خالال (يثقب)"},
            {"original": "שָׁלוֹם", "translit": "shalom", "lang": "hebrew", "strong": "H7965",
             "meaning_en": "Peace, wholeness, welfare", "meaning_ar": "سلام، كمال، عافية",
             "root_en": "shalam — to be complete", "root_ar": "شالام (يكتمل)"},
        ],
    }},
    "mat": {5: {
        3: [
            {"original": "μακάριος", "translit": "makarios", "lang": "greek", "strong": "G3107",
             "meaning_en": "Blessed, happy, fortunate", "meaning_ar": "طوبى، مبارك، سعيد",
             "root_en": "makar — blessed one", "root_ar": "ماكار (مبارك)"},
            {"original": "πνεῦμα", "translit": "pneuma", "lang": "greek", "strong": "G4151",
             "meaning_en": "Spirit, breath, wind", "meaning_ar": "روح، نفس، ريح",
             "root_en": "pneō — to breathe", "root_ar": "بنيو (يتنفس)"},
        ],
    }},
    "rom": {8: {
        1: [
            {"original": "κατάκριμα", "translit": "katakrima", "lang": "greek", "strong": "G2631",
             "meaning_en": "Condemnation, judgment against", "meaning_ar": "دينونة، حكم بالإدانة",
             "root_en": "kata + krima — judgment", "root_ar": "كاتا + كريما (الدينونة)"},
        ],
        28: [
            {"original": "συνεργέω", "translit": "synergeō", "lang": "greek", "strong": "G4903",
             "meaning_en": "To work together, cooperate", "meaning_ar": "يعمل معاً، يتعاون",
             "root_en": "syn + ergon — with work", "root_ar": "سين + إرغون (يشترك في العمل)"},
        ],
    }},
    "phi": {4: {
        7: [
            {"original": "εἰρήνη", "translit": "eirēnē", "lang": "greek", "strong": "G1515",
             "meaning_en": "Peace, tranquility, harmony", "meaning_ar": "سلام، طمأنينة، وئام",
             "root_en": "eirēnē — peace", "root_ar": "إيريني (سلام)"},
        ],
        13: [
            {"original": "ἐνδυναμόω", "translit": "endynamoō", "lang": "greek", "strong": "G1743",
             "meaning_en": "To empower, strengthen", "meaning_ar": "يقوّي، يمكّن",
             "root_en": "en + dynamis — in power", "root_ar": "إن + ديناميس (في القوة)"},
        ],
    }},
}

PLACES = [
    # Old Testament
    {"id": "eden", "name_en": "Garden of Eden", "name_ar": "جنة عدن",
     "lat": 31.0, "lng": 47.4, "testament": "OT",
     "description_en": "The first dwelling of humanity, planted by God. Traditional location near the Tigris and Euphrates rivers.",
     "description_ar": "المسكن الأول للبشرية، غرسها الله. الموقع التقليدي قرب نهري دجلة والفرات.",
     "event_en": "Creation of Adam and Eve", "event_ar": "خلق آدم وحواء",
     "related_refs": [
         {"book_id": "gen", "chapter": 1, "verse": 1, "label_en": "Genesis 1", "label_ar": "تكوين 1"},
     ]},
    {"id": "ur", "name_en": "Ur of the Chaldeans", "name_ar": "أور الكلدانيين",
     "lat": 30.9625, "lng": 46.1053, "testament": "OT",
     "description_en": "Abraham's birthplace in southern Mesopotamia.",
     "description_ar": "مسقط رأس إبراهيم في جنوب بلاد ما بين النهرين.",
     "event_en": "Call of Abraham", "event_ar": "دعوة إبراهيم",
     "related_refs": []},
    {"id": "mt-sinai", "name_en": "Mount Sinai", "name_ar": "جبل سيناء",
     "lat": 28.5392, "lng": 33.9756, "testament": "OT",
     "description_en": "The mountain where God gave Moses the Ten Commandments.",
     "description_ar": "الجبل الذي أعطى الله عليه موسى الوصايا العشر.",
     "event_en": "Giving of the Law", "event_ar": "إعطاء الشريعة",
     "related_refs": []},
    {"id": "jerusalem", "name_en": "Jerusalem", "name_ar": "أورشليم / القدس",
     "lat": 31.7683, "lng": 35.2137, "testament": "BOTH",
     "description_en": "The Holy City. Site of David's kingdom, the Temple, and the crucifixion and resurrection of Christ.",
     "description_ar": "المدينة المقدسة. موقع مملكة داود، الهيكل، وصلب المسيح وقيامته.",
     "event_en": "Temple, Crucifixion, Resurrection", "event_ar": "الهيكل، الصلب، القيامة",
     "related_refs": [
         {"book_id": "psa", "chapter": 23, "verse": 6, "label_en": "Psalm 23:6", "label_ar": "مزمور 23:6"},
     ]},
    {"id": "bethlehem", "name_en": "Bethlehem", "name_ar": "بيت لحم",
     "lat": 31.7054, "lng": 35.2024, "testament": "BOTH",
     "description_en": "City of David and birthplace of Jesus Christ.",
     "description_ar": "مدينة داود ومسقط رأس يسوع المسيح.",
     "event_en": "Birth of Christ", "event_ar": "ميلاد المسيح",
     "related_refs": []},
    {"id": "nazareth", "name_en": "Nazareth", "name_ar": "الناصرة",
     "lat": 32.7020, "lng": 35.2977, "testament": "NT",
     "description_en": "The town where Jesus grew up.",
     "description_ar": "البلدة التي نشأ فيها يسوع.",
     "event_en": "Childhood of Jesus", "event_ar": "طفولة يسوع",
     "related_refs": [
         {"book_id": "joh", "chapter": 1, "verse": 14, "label_en": "John 1:14", "label_ar": "يوحنا 1:14"},
     ]},
    {"id": "capernaum", "name_en": "Capernaum", "name_ar": "كفرناحوم",
     "lat": 32.8809, "lng": 35.5751, "testament": "NT",
     "description_en": "Jesus' base of ministry by the Sea of Galilee.",
     "description_ar": "مقر خدمة يسوع بجانب بحيرة الجليل.",
     "event_en": "Ministry & Miracles", "event_ar": "الخدمة والمعجزات",
     "related_refs": [
         {"book_id": "mat", "chapter": 5, "verse": 3, "label_en": "Matthew 5 — Sermon on the Mount", "label_ar": "متى 5"},
     ]},
    {"id": "mt-of-beatitudes", "name_en": "Mount of Beatitudes", "name_ar": "جبل التطويبات",
     "lat": 32.8869, "lng": 35.5561, "testament": "NT",
     "description_en": "Traditional site of the Sermon on the Mount overlooking the Sea of Galilee.",
     "description_ar": "الموقع التقليدي للموعظة على الجبل المطل على بحيرة الجليل.",
     "event_en": "Sermon on the Mount", "event_ar": "الموعظة على الجبل",
     "related_refs": [
         {"book_id": "mat", "chapter": 5, "verse": 3, "label_en": "Matthew 5:3-12", "label_ar": "متى 5:3-12"},
     ]},
    {"id": "jordan-river", "name_en": "Jordan River", "name_ar": "نهر الأردن",
     "lat": 31.8371, "lng": 35.5528, "testament": "BOTH",
     "description_en": "River where Jesus was baptized by John.",
     "description_ar": "النهر الذي اعتمد فيه يسوع من يوحنا.",
     "event_en": "Baptism of Jesus", "event_ar": "معمودية يسوع",
     "related_refs": [
         {"book_id": "joh", "chapter": 1, "verse": 29, "label_en": "John 1:29", "label_ar": "يوحنا 1:29"},
     ]},
    {"id": "sea-of-galilee", "name_en": "Sea of Galilee", "name_ar": "بحيرة الجليل / طبريا",
     "lat": 32.8330, "lng": 35.5900, "testament": "NT",
     "description_en": "Freshwater lake where Jesus called His disciples and performed many miracles.",
     "description_ar": "بحيرة عذبة دعا يسوع تلاميذه بجانبها وصنع فيها معجزات كثيرة.",
     "event_en": "Calling of Disciples, Walking on Water", "event_ar": "دعوة التلاميذ، السير على الماء",
     "related_refs": []},
    {"id": "golgotha", "name_en": "Golgotha (Calvary)", "name_ar": "الجلجثة",
     "lat": 31.7784, "lng": 35.2296, "testament": "NT",
     "description_en": "The place where Jesus was crucified, outside the walls of Jerusalem.",
     "description_ar": "المكان الذي صلب فيه يسوع، خارج أسوار أورشليم.",
     "event_en": "Crucifixion of Christ", "event_ar": "صلب المسيح",
     "related_refs": [
         {"book_id": "isa", "chapter": 53, "verse": 5, "label_en": "Isaiah 53:5", "label_ar": "إشعياء 53:5"},
         {"book_id": "joh", "chapter": 3, "verse": 16, "label_en": "John 3:16", "label_ar": "يوحنا 3:16"},
     ]},
    {"id": "antioch", "name_en": "Antioch", "name_ar": "أنطاكية",
     "lat": 36.2027, "lng": 36.1614, "testament": "NT",
     "description_en": "Where believers were first called 'Christians'. Base of Paul's mission.",
     "description_ar": "أول موضع دُعي فيه المؤمنون 'مسيحيين'. مقر إرساليات بولس.",
     "event_en": "Missionary Sending", "event_ar": "الإرساليات",
     "related_refs": []},
    {"id": "philippi", "name_en": "Philippi", "name_ar": "فيلبي",
     "lat": 41.0136, "lng": 24.2867, "testament": "NT",
     "description_en": "City in Macedonia where Paul planted the first European church.",
     "description_ar": "مدينة في مقدونية زرع فيها بولس أول كنيسة أوروبية.",
     "event_en": "Paul's Second Journey — Letter to Philippians", "event_ar": "رحلة بولس الثانية — رسالة فيلبي",
     "related_refs": [
         {"book_id": "phi", "chapter": 4, "verse": 13, "label_en": "Philippians 4:13", "label_ar": "فيلبي 4:13"},
     ]},
    {"id": "rome", "name_en": "Rome", "name_ar": "روما",
     "lat": 41.9028, "lng": 12.4964, "testament": "NT",
     "description_en": "Capital of the Empire. Recipient of Paul's greatest theological letter.",
     "description_ar": "عاصمة الإمبراطورية. متلقية أعظم رسالة لاهوتية لبولس.",
     "event_en": "Paul's Letter to the Romans", "event_ar": "رسالة بولس إلى رومية",
     "related_refs": [
         {"book_id": "rom", "chapter": 8, "verse": 1, "label_en": "Romans 8:1", "label_ar": "رومية 8:1"},
     ]},
]

# Map verse → place(s)
VERSE_PLACES = {
    "gen": {1: {1: ["eden"]}},
    "psa": {23: {1: ["jerusalem"]}},
    "isa": {53: {5: ["golgotha"], 6: ["golgotha"]}},
    "mat": {5: {3: ["mt-of-beatitudes"], 14: ["mt-of-beatitudes"], 16: ["mt-of-beatitudes"]},
             6: {33: ["capernaum"]}},
    "joh": {1: {1: ["nazareth"], 14: ["nazareth"], 29: ["jordan-river"]},
             3: {16: ["golgotha", "jerusalem"]},
             14: {6: ["jerusalem"], 27: ["jerusalem"]}},
    "rom": {8: {1: ["rome"], 28: ["rome"], 38: ["rome"], 39: ["rome"]}},
    "phi": {4: {4: ["philippi"], 7: ["philippi"], 13: ["philippi"]}},
}
