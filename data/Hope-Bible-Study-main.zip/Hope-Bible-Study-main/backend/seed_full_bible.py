"""One-time seeder: fetch the whole 66-book Bible (Van Dyke Arabic + WEB English)
from https://bolls.life and store it in MongoDB.

Run once:
    cd /app/backend && python seed_full_bible.py

Collections created:
- bible_books_full: { book_id, order, name_en, name_ar, testament, total_chapters }
- bible_verses_full: { book_id, chapter, verse, ar, en }
"""
import asyncio
import os
import sys
from pathlib import Path
import aiohttp
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]

# Arabic names for the 66 canonical books (in KJV/Van Dyke order, bookid 1-66 in bolls.life)
BOOK_META = [
    # (bookid, id, name_en, name_ar, testament)
    (1, "gen", "Genesis", "التكوين", "OT"),
    (2, "exo", "Exodus", "الخروج", "OT"),
    (3, "lev", "Leviticus", "اللاويين", "OT"),
    (4, "num", "Numbers", "العدد", "OT"),
    (5, "deu", "Deuteronomy", "التثنية", "OT"),
    (6, "jos", "Joshua", "يشوع", "OT"),
    (7, "jdg", "Judges", "القضاة", "OT"),
    (8, "rut", "Ruth", "راعوث", "OT"),
    (9, "1sa", "1 Samuel", "صموئيل الأول", "OT"),
    (10, "2sa", "2 Samuel", "صموئيل الثاني", "OT"),
    (11, "1ki", "1 Kings", "الملوك الأول", "OT"),
    (12, "2ki", "2 Kings", "الملوك الثاني", "OT"),
    (13, "1ch", "1 Chronicles", "أخبار الأيام الأول", "OT"),
    (14, "2ch", "2 Chronicles", "أخبار الأيام الثاني", "OT"),
    (15, "ezr", "Ezra", "عزرا", "OT"),
    (16, "neh", "Nehemiah", "نحميا", "OT"),
    (17, "est", "Esther", "أستير", "OT"),
    (18, "job", "Job", "أيوب", "OT"),
    (19, "psa", "Psalms", "المزامير", "OT"),
    (20, "pro", "Proverbs", "الأمثال", "OT"),
    (21, "ecc", "Ecclesiastes", "الجامعة", "OT"),
    (22, "sng", "Song of Songs", "نشيد الأنشاد", "OT"),
    (23, "isa", "Isaiah", "إشعياء", "OT"),
    (24, "jer", "Jeremiah", "إرميا", "OT"),
    (25, "lam", "Lamentations", "مراثي إرميا", "OT"),
    (26, "ezk", "Ezekiel", "حزقيال", "OT"),
    (27, "dan", "Daniel", "دانيال", "OT"),
    (28, "hos", "Hosea", "هوشع", "OT"),
    (29, "jol", "Joel", "يوئيل", "OT"),
    (30, "amo", "Amos", "عاموس", "OT"),
    (31, "oba", "Obadiah", "عوبديا", "OT"),
    (32, "jon", "Jonah", "يونان", "OT"),
    (33, "mic", "Micah", "ميخا", "OT"),
    (34, "nam", "Nahum", "ناحوم", "OT"),
    (35, "hab", "Habakkuk", "حبقوق", "OT"),
    (36, "zep", "Zephaniah", "صفنيا", "OT"),
    (37, "hag", "Haggai", "حجي", "OT"),
    (38, "zec", "Zechariah", "زكريا", "OT"),
    (39, "mal", "Malachi", "ملاخي", "OT"),
    (40, "mat", "Matthew", "متى", "NT"),
    (41, "mrk", "Mark", "مرقس", "NT"),
    (42, "luk", "Luke", "لوقا", "NT"),
    (43, "joh", "John", "يوحنا", "NT"),
    (44, "act", "Acts", "أعمال الرسل", "NT"),
    (45, "rom", "Romans", "رومية", "NT"),
    (46, "1co", "1 Corinthians", "كورنثوس الأولى", "NT"),
    (47, "2co", "2 Corinthians", "كورنثوس الثانية", "NT"),
    (48, "gal", "Galatians", "غلاطية", "NT"),
    (49, "eph", "Ephesians", "أفسس", "NT"),
    (50, "phi", "Philippians", "فيلبي", "NT"),
    (51, "col", "Colossians", "كولوسي", "NT"),
    (52, "1th", "1 Thessalonians", "تسالونيكي الأولى", "NT"),
    (53, "2th", "2 Thessalonians", "تسالونيكي الثانية", "NT"),
    (54, "1ti", "1 Timothy", "تيموثاوس الأولى", "NT"),
    (55, "2ti", "2 Timothy", "تيموثاوس الثانية", "NT"),
    (56, "tit", "Titus", "تيطس", "NT"),
    (57, "phm", "Philemon", "فليمون", "NT"),
    (58, "heb", "Hebrews", "العبرانيين", "NT"),
    (59, "jas", "James", "يعقوب", "NT"),
    (60, "1pe", "1 Peter", "بطرس الأولى", "NT"),
    (61, "2pe", "2 Peter", "بطرس الثانية", "NT"),
    (62, "1jn", "1 John", "يوحنا الأولى", "NT"),
    (63, "2jn", "2 John", "يوحنا الثانية", "NT"),
    (64, "3jn", "3 John", "يوحنا الثالثة", "NT"),
    (65, "jud", "Jude", "يهوذا", "NT"),
    (66, "rev", "Revelation", "الرؤيا", "NT"),
]


def strip_tags(txt: str) -> str:
    """Remove Bolls HTML markers like <S>1234</S>, <br/>, paragraph markers, and extra whitespace."""
    if not txt:
        return ""
    import re
    txt = re.sub(r"<[^>]+>", "", txt)
    txt = txt.replace("\r", "").replace("\n", " ").strip()
    # Bolls prepends 'P' markers for new paragraphs — drop them
    txt = re.sub(r"^P\s*", "", txt)
    txt = re.sub(r"\bP\s+", " ", txt)
    return re.sub(r"\s+", " ", txt).strip()


async def fetch_chapter(session, translation: str, bookid: int, chapter: int) -> list:
    url = f"https://bolls.life/get-text/{translation}/{bookid}/{chapter}/"
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as r:
        if r.status != 200:
            return []
        return await r.json()


async def process_book(session, db, meta, sem: asyncio.Semaphore):
    bookid, book_id, name_en, name_ar, testament = meta
    # Fetch book list to know chapter count from bolls
    async with sem:
        async with session.get(
            f"https://bolls.life/get-books/SVD/", timeout=aiohttp.ClientTimeout(total=30)
        ) as r:
            books_data = await r.json()
        book_info = next((b for b in books_data if b["bookid"] == bookid), None)
        if not book_info:
            print(f"  ⚠️ book {bookid} {name_en} not found")
            return
        total_chapters = book_info["chapters"]

    # Insert book meta
    await db.bible_books_full.update_one(
        {"book_id": book_id},
        {"$set": {
            "book_id": book_id, "bookid": bookid, "order": bookid,
            "name_en": name_en, "name_ar": name_ar, "testament": testament,
            "total_chapters": total_chapters,
        }},
        upsert=True,
    )

    # Fetch each chapter — SVD (Arabic) + WEB (English) in parallel
    verses_to_insert = []
    for ch in range(1, total_chapters + 1):
        async with sem:
            ar_task = fetch_chapter(session, "SVD", bookid, ch)
            en_task = fetch_chapter(session, "WEB", bookid, ch)
            ar_data, en_data = await asyncio.gather(ar_task, en_task)

        ar_by_v = {v["verse"]: strip_tags(v.get("text", "")) for v in ar_data}
        en_by_v = {v["verse"]: strip_tags(v.get("text", "")) for v in en_data}
        all_v = sorted(set(ar_by_v.keys()) | set(en_by_v.keys()))
        for v in all_v:
            verses_to_insert.append({
                "book_id": book_id,
                "chapter": ch,
                "verse": v,
                "ar": ar_by_v.get(v, ""),
                "en": en_by_v.get(v, ""),
            })
    if verses_to_insert:
        # Clear existing then insert fresh
        await db.bible_verses_full.delete_many({"book_id": book_id})
        # Insert in batches
        BATCH = 1000
        for i in range(0, len(verses_to_insert), BATCH):
            await db.bible_verses_full.insert_many(verses_to_insert[i:i + BATCH])
    print(f"  ✅ {name_en} ({name_ar}): {total_chapters} chapters, {len(verses_to_insert)} verses")


async def main():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    # Indexes
    await db.bible_books_full.create_index("book_id", unique=True)
    await db.bible_verses_full.create_index([("book_id", 1), ("chapter", 1), ("verse", 1)])

    only = sys.argv[1] if len(sys.argv) > 1 else None
    metas = BOOK_META if not only else [m for m in BOOK_META if m[1] == only]

    print(f"Seeding {len(metas)} book(s)…")
    sem = asyncio.Semaphore(4)  # 4 concurrent chapter fetches
    async with aiohttp.ClientSession() as session:
        for m in metas:
            try:
                await process_book(session, db, m, sem)
            except Exception as e:
                print(f"  ❌ {m[2]}: {e}")

    total_books = await db.bible_books_full.count_documents({})
    total_verses = await db.bible_verses_full.count_documents({})
    print(f"\n✅ Done. Books: {total_books}, Verses: {total_verses}")
    client.close()


if __name__ == "__main__":
    asyncio.run(main())
