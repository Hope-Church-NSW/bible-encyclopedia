"""Iteration 3 tests: full 66-book Bible in MongoDB, audio Bible, updated socials.

Covers:
- GET /api/bible/books returns 66 books (Genesis..Revelation) with Arabic names
- GET /api/bible/rev/22 returns 21 verses with both AR + EN populated
- GET /api/bible/gen/50 returns Genesis 50 with verse 26 present
- GET /api/bible/joh/3 still returns sections metadata and full 36 verses (John 3)
- GET /api/bible/search?q=grace&lang=en returns >=40 (~50) results
- GET /api/bible/search?q=نعمة&lang=ar returns Arabic verses
- GET /api/audio/joh/3 returns Dr. Adel Noshi metadata (YouTube search + channel_url)
- POST /api/audio/override then GET /api/audio returns custom URL
- GET /api/church socials contain updated Facebook + YouTube
- GET /api/bible/verse/joh/3/16 still returns cross_refs (3), Greek words (4), places
"""
import os
import pytest
import requests
import uuid

BASE_URL = (os.environ.get("EXPO_PUBLIC_BACKEND_URL") or os.environ.get("EXPO_BACKEND_URL") or "").rstrip("/")
assert BASE_URL, "EXPO_PUBLIC_BACKEND_URL required"
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def s():
    ses = requests.Session()
    ses.headers.update({"Content-Type": "application/json"})
    return ses


# ---------- Full 66-book Bible ----------
class TestFullBibleBooks:
    def test_books_count_66(self, s):
        r = s.get(f"{API}/bible/books", timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert len(data) == 66, f"expected 66 books, got {len(data)}"

    def test_books_first_last(self, s):
        r = s.get(f"{API}/bible/books", timeout=20)
        data = r.json()
        assert data[0]["id"] == "gen"
        assert data[0]["name_en"] == "Genesis"
        assert data[0]["name_ar"]
        assert data[-1]["id"] == "rev"
        assert data[-1]["name_en"] == "Revelation"
        assert data[-1]["name_ar"]

    def test_books_testament_split(self, s):
        r = s.get(f"{API}/bible/books", timeout=20)
        data = r.json()
        ot = [b for b in data if b["testament"] == "OT"]
        nt = [b for b in data if b["testament"] == "NT"]
        assert len(ot) == 39, f"OT should be 39, got {len(ot)}"
        assert len(nt) == 27, f"NT should be 27, got {len(nt)}"

    def test_genesis_50_chapters(self, s):
        r = s.get(f"{API}/bible/books", timeout=20)
        gen = next(b for b in r.json() if b["id"] == "gen")
        assert gen["total_chapters"] == 50

    def test_psalms_150_chapters(self, s):
        r = s.get(f"{API}/bible/books", timeout=20)
        psa = next(b for b in r.json() if b["id"] == "psa")
        assert psa["total_chapters"] == 150


class TestFullBibleChapters:
    def test_revelation_22(self, s):
        r = s.get(f"{API}/bible/rev/22", timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert d["book_id"] == "rev"
        assert d["chapter"] == 22
        assert len(d["verses"]) == 21, f"Rev 22 should have 21 verses, got {len(d['verses'])}"
        # Both languages populated
        for v in d["verses"]:
            assert v["ar"].strip(), f"verse {v['number']} missing AR"
            assert v["en"].strip(), f"verse {v['number']} missing EN"

    def test_genesis_50(self, s):
        r = s.get(f"{API}/bible/gen/50", timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert d["book_id"] == "gen"
        assert d["chapter"] == 50
        numbers = [v["number"] for v in d["verses"]]
        assert 26 in numbers, "Genesis 50:26 missing"
        # Verify Gen 50 has 26 verses
        assert max(numbers) == 26

    def test_john_3_still_has_sections_and_full_verses(self, s):
        r = s.get(f"{API}/bible/joh/3", timeout=20)
        assert r.status_code == 200
        d = r.json()
        # John 3 has 36 verses
        assert len(d["verses"]) == 36, f"John 3 should have 36 verses, got {len(d['verses'])}"
        # Sections still present from metadata
        titles = [sec["title_en"] for sec in d["sections"]]
        assert "Born Again" in titles
        assert "God So Loved the World" in titles
        loved = next(sec for sec in d["sections"] if sec["title_en"] == "God So Loved the World")
        assert loved["start"] == 16 and loved["end"] == 17


class TestFullBibleSearch:
    def test_search_grace_en_returns_many(self, s):
        r = s.get(f"{API}/bible/search", params={"q": "grace", "lang": "en"}, timeout=20)
        assert r.status_code == 200
        results = r.json()["results"]
        # Should be near 50 (the limit) from a real Bible corpus
        assert len(results) >= 40, f"expected ~50 grace results, got {len(results)}"
        # All results should actually contain 'grace' (case-insensitive)
        assert all("grace" in x["en"].lower() for x in results)

    def test_search_arabic_naema(self, s):
        r = s.get(f"{API}/bible/search", params={"q": "نعمة", "lang": "ar"}, timeout=20)
        assert r.status_code == 200
        results = r.json()["results"]
        assert len(results) > 0, "expected Arabic 'نعمة' results"
        assert all("نعمة" in x["ar"] for x in results)


# ---------- Audio Bible ----------
class TestAudioBible:
    def test_get_audio_default_youtube(self, s):
        r = s.get(f"{API}/audio/joh/3", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert d["narrator"] == "Dr. Adel Noshi"
        assert d.get("narrator_ar")
        assert d["url"].startswith("https://www.youtube.com/results?search_query=")
        assert d.get("channel_url", "").startswith("https://www.youtube.com/")
        assert d["source"] == "youtube"
        assert d["kind"] == "youtube_search"

    def test_audio_override_then_get(self, s):
        # Use a random-ish chapter to avoid clashing
        book_id = "psa"
        chapter = 119
        custom_url = f"https://example.com/audio/{uuid.uuid4()}.mp3"
        r = s.post(f"{API}/audio/override", json={
            "book_id": book_id, "chapter": chapter,
            "url": custom_url, "kind": "audio", "source": "custom",
        }, timeout=15)
        assert r.status_code == 200
        assert r.json().get("ok") is True

        r2 = s.get(f"{API}/audio/{book_id}/{chapter}", timeout=15)
        assert r2.status_code == 200
        d = r2.json()
        assert d["url"] == custom_url, f"custom URL not returned, got {d.get('url')}"
        assert d["source"] == "custom"
        assert d["kind"] == "audio"


# ---------- Church socials ----------
class TestChurchSocials:
    def test_facebook_and_youtube_urls(self, s):
        r = s.get(f"{API}/church", timeout=15)
        assert r.status_code == 200
        d = r.json()
        socials = d.get("socials", [])
        urls = [x.get("url", "") for x in socials]
        assert "https://www.facebook.com/hopechurchNSW" in urls, f"Facebook URL missing. Got: {urls}"
        assert "https://youtube.com/user/revashraf1" in urls, f"YouTube URL missing. Got: {urls}"


# ---------- Verse detail regression (from iteration 2) ----------
class TestVerseDetailRegression:
    def test_john_3_16(self, s):
        r = s.get(f"{API}/bible/verse/joh/3/16", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert len(d["cross_refs"]) == 3
        assert len(d["words"]) == 4
        strongs = {w["strong"] for w in d["words"]}
        assert strongs == {"G25", "G2889", "G3439", "G166"}
        place_ids = {p["id"] for p in d["places"]}
        assert place_ids == {"jerusalem", "golgotha"}
