"""Iteration 5 tests — Arabic Commentary Library + full 66-book Bible + Arabic search."""
import os
import uuid
import time
import pytest
import requests

BASE_URL = os.environ.get('EXPO_PUBLIC_BACKEND_URL', 'https://hope-bible-study.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

CID = f"cid-test-iter5-{uuid.uuid4().hex[:12]}"
HDR = {"X-Client-Id": CID, "Content-Type": "application/json"}

EXPECTED_AUTHORS = {"matta", "menes", "macdonald", "newton", "kelly"}
EXPECTED_ARABIC_NAMES = {
    "matta": "الأب متى المسكين",
    "menes": "القس منيس عبد النور",
    "macdonald": "وليم مكدونالد",
    "newton": "بنيامين بنكترتن",
    "kelly": "وليم أدي",
}


# -------------------- TASK 3a: authors list --------------------
class TestCommentaryAuthors:
    def test_list_authors_returns_5(self):
        r = requests.get(f"{API}/commentary/authors", timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "authors" in data
        ids = {a["id"] for a in data["authors"]}
        assert ids == EXPECTED_AUTHORS, f"Expected {EXPECTED_AUTHORS}, got {ids}"
        for a in data["authors"]:
            assert a["name_ar"] == EXPECTED_ARABIC_NAMES[a["id"]]
            assert "tradition_ar" in a and a["tradition_ar"]
            assert "style_ar" in a and a["style_ar"]


# -------------------- TASK 3e: auth + not-found --------------------
class TestCommentaryAuth:
    def test_missing_client_id_returns_401(self):
        r = requests.get(f"{API}/commentary/joh/3/16?author=matta", timeout=15)
        assert r.status_code == 401, r.text

    def test_nonexistent_verse_returns_404(self):
        r = requests.get(
            f"{API}/commentary/joh/99/999?author=matta", headers=HDR, timeout=30
        )
        assert r.status_code == 404, r.text


# -------------------- TASK 3b/3c: LLM commentary + caching --------------------
class TestCommentaryGeneration:
    """Uses a UNIQUE client-id so we get a clean rate-limit bucket. Only 2 LLM calls."""

    def test_matta_commentary_generation_and_cache(self):
        # First call — LLM generation (~15-25s expected)
        t0 = time.time()
        r1 = requests.get(
            f"{API}/commentary/joh/3/16?author=matta", headers=HDR, timeout=90
        )
        elapsed1 = time.time() - t0
        assert r1.status_code == 200, r1.text
        d1 = r1.json()
        assert d1["author_id"] == "matta"
        assert d1["author_name_ar"] == "الأب متى المسكين"
        assert "الأرثوذكسية" in d1["tradition_ar"]
        assert len(d1["body_ar"]) >= 300, f"Body too short: {len(d1['body_ar'])} chars"
        assert d1["disclaimer_ar"], "Missing disclaimer_ar"
        # Body should contain Arabic characters
        assert any("\u0600" <= ch <= "\u06FF" for ch in d1["body_ar"])
        print(f"Matta commentary generated in {elapsed1:.1f}s, {len(d1['body_ar'])} chars")

        # Second call — should be instant (cached)
        t1 = time.time()
        r2 = requests.get(
            f"{API}/commentary/joh/3/16?author=matta", headers=HDR, timeout=10
        )
        elapsed2 = time.time() - t1
        assert r2.status_code == 200, r2.text
        d2 = r2.json()
        assert d2["body_ar"] == d1["body_ar"], "Cache miss — body differs"
        assert elapsed2 < 5, f"Cached call too slow: {elapsed2:.1f}s"
        print(f"Cached call in {elapsed2:.2f}s")

    def test_menes_produces_different_content(self):
        # Use SAME cid so we share cache with the previous test where possible,
        # but this is a different (author) key so it's a fresh LLM call.
        r = requests.get(
            f"{API}/commentary/joh/3/16?author=menes", headers=HDR, timeout=90
        )
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["author_id"] == "menes"
        assert d["author_name_ar"] == "القس منيس عبد النور"
        assert len(d["body_ar"]) >= 300

        # Compare to matta (cached now — no extra LLM call)
        r_matta = requests.get(
            f"{API}/commentary/joh/3/16?author=matta", headers=HDR, timeout=10
        )
        assert r_matta.status_code == 200
        assert d["body_ar"] != r_matta.json()["body_ar"], "Menes and Matta produced identical text"


# -------------------- TASK 4a: 66 books --------------------
class TestFullBible:
    def test_books_returns_66(self):
        r = requests.get(f"{API}/bible/books", timeout=20)
        assert r.status_code == 200, r.text
        books = r.json()
        assert len(books) == 66, f"Expected 66 books, got {len(books)}"
        ot = [b for b in books if b["testament"] == "OT"]
        nt = [b for b in books if b["testament"] == "NT"]
        assert len(ot) == 39, f"OT count = {len(ot)}"
        assert len(nt) == 27, f"NT count = {len(nt)}"
        # All should have arabic names
        for b in books:
            assert b["name_ar"], f"Missing name_ar for {b['id']}"
            assert b["total_chapters"] > 0

    def test_genesis_50_has_26_verses(self):
        r = requests.get(f"{API}/bible/gen/50", timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["book_id"] == "gen"
        assert d["chapter"] == 50
        assert len(d["verses"]) == 26, f"Expected 26 verses, got {len(d['verses'])}"

    def test_revelation_22_has_21_verses(self):
        r = requests.get(f"{API}/bible/rev/22", timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["book_id"] == "rev"
        assert d["chapter"] == 22
        assert len(d["verses"]) == 21, f"Expected 21 verses, got {len(d['verses'])}"


# -------------------- TASK 4c: Arabic search with normalization --------------------
class TestArabicSearch:
    def test_arabic_search_ne3ma_returns_results(self):
        r = requests.get(f"{API}/bible/search", params={"q": "نعمة", "lang": "ar"}, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert isinstance(d.get("results"), list)
        assert len(d["results"]) > 0, "No results for نعمة"
        # Should contain Arabic text and correct fields
        for res in d["results"][:3]:
            assert "book_id" in res
            assert "chapter" in res
            assert "verse" in res
            assert res.get("ar")
        print(f"Arabic search for نعمة → {len(d['results'])} results")

    def test_arabic_search_with_diacritics_normalized(self):
        # Same word but with alef-hamza above → should still return results
        r = requests.get(f"{API}/bible/search", params={"q": "الله", "lang": "ar"}, timeout=20)
        assert r.status_code == 200, r.text
        assert len(r.json()["results"]) > 0


# -------------------- REGRESSION: security fixes still work --------------------
class TestRegression:
    def test_bookmark_still_requires_client_id(self):
        r = requests.post(
            f"{API}/bookmarks",
            json={"book_id": "joh", "chapter": 3, "verse": 16},
            timeout=10,
        )
        assert r.status_code == 401, r.text

    def test_audio_override_requires_admin(self):
        r = requests.post(
            f"{API}/audio/override",
            json={"book_id": "joh", "chapter": 3, "url": "https://youtube.com/watch?v=abc"},
            timeout=10,
        )
        assert r.status_code == 403, r.text

    def test_delete_my_data_works(self):
        cid = f"cid-regress-{uuid.uuid4().hex[:12]}"
        hdr = {"X-Client-Id": cid, "Content-Type": "application/json"}
        # Create one bookmark
        c = requests.post(
            f"{API}/bookmarks",
            json={"book_id": "joh", "chapter": 3, "verse": 16, "label": "TEST"},
            headers=hdr,
            timeout=10,
        )
        assert c.status_code == 200, c.text
        # Delete all data
        d = requests.delete(f"{API}/user/data", headers=hdr, timeout=10)
        assert d.status_code == 200, d.text
        counts = d.json()["deleted"]
        assert counts["bookmarks"] >= 1

    def test_verse_detail_has_tabs_data(self):
        r = requests.get(f"{API}/bible/verse/joh/3/16", timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "cross_refs" in d
        assert "words" in d
        assert "places" in d
        assert d["verse"]["number"] == 16
