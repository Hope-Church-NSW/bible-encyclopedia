"""Tests for new metadata endpoints: sections, verse detail, places."""
import os
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL") or os.environ.get("EXPO_BACKEND_URL")
assert BASE_URL, "EXPO_PUBLIC_BACKEND_URL required"
BASE_URL = BASE_URL.rstrip("/")


@pytest.fixture(scope="module")
def sess():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---------- Sections in chapter ----------
class TestSections:
    def test_john_3_sections(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/joh/3", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert "sections" in data
        titles = [s["title_en"] for s in data["sections"]]
        assert "Born Again" in titles
        assert "God So Loved the World" in titles
        born = next(s for s in data["sections"] if s["title_en"] == "Born Again")
        assert born["start"] == 3
        loved = next(s for s in data["sections"] if s["title_en"] == "God So Loved the World")
        assert loved["start"] == 16 and loved["end"] == 17

    def test_chapter_without_sections_is_empty_list(self, sess):
        # Genesis 1 does have sections; a chapter without should be []
        r = sess.get(f"{BASE_URL}/api/bible/psa/91", timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json()["sections"], list)


# ---------- Verse detail ----------
class TestVerseDetail:
    def test_john_3_16_full(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/verse/joh/3/16", timeout=15)
        assert r.status_code == 200
        d = r.json()
        # Cross refs
        assert len(d["cross_refs"]) == 3
        # Original words - 4 Greek words with expected Strong's
        assert len(d["words"]) == 4
        strongs = {w["strong"] for w in d["words"]}
        assert strongs == {"G25", "G2889", "G3439", "G166"}
        translits = {w["translit"] for w in d["words"]}
        assert translits == {"agapaō", "kosmos", "monogenēs", "aiōnios"}
        for w in d["words"]:
            assert w["lang"] == "greek"
        # Places: Jerusalem + Golgotha
        place_ids = {p["id"] for p in d["places"]}
        assert place_ids == {"jerusalem", "golgotha"}

    def test_genesis_1_1_hebrew(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/verse/gen/1/1", timeout=15)
        assert r.status_code == 200
        d = r.json()
        translits = {w["translit"] for w in d["words"]}
        assert {"bereshit", "bara", "Elohim"}.issubset(translits)
        strongs = {w["strong"] for w in d["words"]}
        assert {"H7225", "H1254", "H430"}.issubset(strongs)
        for w in d["words"]:
            assert w["lang"] == "hebrew"

    def test_psalm_23_1_hebrew_and_refs(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/verse/psa/23/1", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert len(d["words"]) >= 1
        assert any(w["lang"] == "hebrew" for w in d["words"])
        assert len(d["cross_refs"]) >= 1

    def test_verse_without_metadata_returns_empty_arrays(self, sess):
        # A valid verse but no metadata → verse still returned, arrays empty
        # Psalm 23:2 exists in seed but has no cross_refs / words / places
        r = sess.get(f"{BASE_URL}/api/bible/verse/psa/23/2", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert d["verse"]["number"] == 2
        assert d["cross_refs"] == []
        assert d["words"] == []
        assert d["places"] == []

    def test_verse_404_when_missing(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/verse/joh/1/99999", timeout=15)
        assert r.status_code == 404

    def test_verse_404_book(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/verse/xxx/1/1", timeout=15)
        assert r.status_code == 404


# ---------- Places listing ----------
class TestPlaces:
    def test_places_count_and_shape(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/places", timeout=15)
        assert r.status_code == 200
        places = r.json()["places"]
        assert len(places) == 14
        # Every place has core fields
        required = {"id", "name_en", "name_ar", "lat", "lng", "testament",
                    "description_en", "event_en", "related_refs"}
        for p in places:
            missing = required - set(p.keys())
            assert not missing, f"{p.get('id')} missing {missing}"
            assert p["testament"] in {"OT", "NT", "BOTH"}
            assert isinstance(p["lat"], (int, float))
            assert isinstance(p["lng"], (int, float))
            assert isinstance(p["related_refs"], list)

    def test_places_include_key_locations(self, sess):
        r = sess.get(f"{BASE_URL}/api/bible/places", timeout=15)
        ids = {p["id"] for p in r.json()["places"]}
        for expected in ["eden", "jerusalem", "bethlehem", "golgotha", "nazareth",
                         "capernaum", "jordan-river", "rome", "philippi", "antioch",
                         "sea-of-galilee", "mt-sinai", "ur", "mt-of-beatitudes"]:
            assert expected in ids
