"""Security-fix verification: SEC-001..SEC-004"""
import os
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://hope-bible-study.preview.emergentagent.com").rstrip("/")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "otrzHzwoN8qS-A2u_ov_W7xDBm9bNMIl")

ALICE = "cid_alicetest1"
BOB = "cid_bobtest2222"


@pytest.fixture(scope="module")
def s():
    return requests.Session()


# ---------- SEC-001: X-Client-Id required + per-owner isolation ----------
class TestSec001Isolation:
    def test_no_client_id_returns_401(self, s):
        r = s.get(f"{BASE_URL}/api/bookmarks")
        assert r.status_code == 401, r.text

    def test_malformed_client_id_returns_401(self, s):
        r = s.get(f"{BASE_URL}/api/bookmarks", headers={"X-Client-Id": "sh!rt"})
        assert r.status_code == 401

    def test_bookmark_isolation_between_two_users(self, s):
        # cleanup first
        s.delete(f"{BASE_URL}/api/user/data", headers={"X-Client-Id": ALICE})
        s.delete(f"{BASE_URL}/api/user/data", headers={"X-Client-Id": BOB})

        # Alice creates bookmark
        r = s.post(f"{BASE_URL}/api/bookmarks",
                   json={"book_id": "john", "chapter": 3, "verse": 16, "label": "alice-bm"},
                   headers={"X-Client-Id": ALICE, "Content-Type": "application/json"})
        assert r.status_code == 200, r.text
        alice_bm_id = r.json()["id"]
        assert r.json()["owner_id"] == ALICE

        # Bob creates one
        r = s.post(f"{BASE_URL}/api/bookmarks",
                   json={"book_id": "psa", "chapter": 23, "verse": 1, "label": "bob-bm"},
                   headers={"X-Client-Id": BOB, "Content-Type": "application/json"})
        assert r.status_code == 200
        bob_bm_id = r.json()["id"]

        # Alice list = only Alice's
        r = s.get(f"{BASE_URL}/api/bookmarks", headers={"X-Client-Id": ALICE})
        assert r.status_code == 200
        alice_list = r.json()
        assert any(b["id"] == alice_bm_id for b in alice_list)
        assert not any(b["id"] == bob_bm_id for b in alice_list)

        # Bob list = only Bob's
        r = s.get(f"{BASE_URL}/api/bookmarks", headers={"X-Client-Id": BOB})
        bob_list = r.json()
        assert any(b["id"] == bob_bm_id for b in bob_list)
        assert not any(b["id"] == alice_bm_id for b in bob_list)

        # Bob cannot delete Alice's bookmark -> 404
        r = s.delete(f"{BASE_URL}/api/bookmarks/{alice_bm_id}", headers={"X-Client-Id": BOB})
        assert r.status_code == 404

        # Alice can delete her own -> 200
        r = s.delete(f"{BASE_URL}/api/bookmarks/{alice_bm_id}", headers={"X-Client-Id": ALICE})
        assert r.status_code == 200

    def test_highlights_notes_prayers_require_client_id(self, s):
        for path in ["/api/highlights", "/api/notes", "/api/prayers"]:
            r = s.get(f"{BASE_URL}{path}")
            assert r.status_code == 401, f"{path} did not require X-Client-Id"


# ---------- SEC-001 AI: chat + history scoped by header ----------
class TestSec001AI:
    def test_ai_history_requires_client_id(self, s):
        r = s.get(f"{BASE_URL}/api/ai/history/anything")
        assert r.status_code == 401

    def test_ai_history_ignores_path_session_id(self, s):
        # Alice's history should only contain Alice's messages (session_id path ignored)
        r = s.get(f"{BASE_URL}/api/ai/history/bogus-session",
                  headers={"X-Client-Id": ALICE})
        assert r.status_code == 200
        for m in r.json().get("messages", []):
            assert m["session_id"] == ALICE

        r = s.get(f"{BASE_URL}/api/ai/history/bogus-session",
                  headers={"X-Client-Id": BOB})
        assert r.status_code == 200
        for m in r.json().get("messages", []):
            assert m["session_id"] == BOB


# ---------- SEC-002: audio override auth + URL allowlist ----------
class TestSec002AudioOverride:
    def test_no_admin_token_returns_403(self, s):
        r = s.post(f"{BASE_URL}/api/audio/override",
                   json={"book_id": "john", "chapter": 3, "url": "https://www.youtube.com/watch?v=x"})
        assert r.status_code == 403

    def test_disallowed_host_returns_400(self, s):
        r = s.post(f"{BASE_URL}/api/audio/override",
                   json={"book_id": "john", "chapter": 3, "url": "https://evil.com/x"},
                   headers={"X-Admin-Token": ADMIN_TOKEN})
        assert r.status_code == 400, r.text

    def test_allowed_host_returns_200(self, s):
        r = s.post(f"{BASE_URL}/api/audio/override",
                   json={"book_id": "john", "chapter": 3,
                         "url": "https://www.youtube.com/watch?v=abc123"},
                   headers={"X-Admin-Token": ADMIN_TOKEN})
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True


# ---------- SEC-003: message length + rate limit ----------
class TestSec003ChatLimits:
    def test_message_too_long_returns_422(self, s):
        body = {"session_id": "ignored", "message": "a" * 2001, "language": "en"}
        r = s.post(f"{BASE_URL}/api/ai/chat", json=body,
                   headers={"X-Client-Id": ALICE, "Content-Type": "application/json"})
        assert r.status_code == 422, r.text

    def test_rate_limit_returns_429(self, s):
        # Use a fresh client-id so we don't burn Alice/Bob's quota
        cid = "cid_rltestzzzzz"
        # Send ~32 short chats — chat endpoint counts BEFORE the LLM call so we
        # can trigger 429 quickly. Use max_length OK but small.
        codes = []
        # Also clear any existing state
        s.delete(f"{BASE_URL}/api/user/data", headers={"X-Client-Id": cid})
        got_429 = False
        for i in range(35):
            r = s.post(f"{BASE_URL}/api/ai/chat",
                       json={"session_id": "ignored", "message": f"ping {i}", "language": "en"},
                       headers={"X-Client-Id": cid, "Content-Type": "application/json"},
                       timeout=60)
            codes.append(r.status_code)
            if r.status_code == 429:
                got_429 = True
                break
        assert got_429, f"Expected 429 within 35 requests, saw: {codes}"


# ---------- SEC-004: privacy endpoints ----------
class TestSec004Privacy:
    def test_data_summary_requires_client_id(self, s):
        r = s.get(f"{BASE_URL}/api/user/data-summary")
        assert r.status_code == 401

    def test_delete_my_data_removes_all_collections(self, s):
        cid = "cid_privacytest99"
        # seed data
        s.post(f"{BASE_URL}/api/bookmarks", json={"book_id": "john", "chapter": 1, "verse": 1},
               headers={"X-Client-Id": cid})
        s.post(f"{BASE_URL}/api/highlights", json={"book_id": "john", "chapter": 1, "verse": 1},
               headers={"X-Client-Id": cid})
        s.post(f"{BASE_URL}/api/notes",
               json={"book_id": "john", "chapter": 1, "verse": 1, "text": "TEST note"},
               headers={"X-Client-Id": cid})
        s.post(f"{BASE_URL}/api/prayers", json={"title": "TEST", "body": "TEST body"},
               headers={"X-Client-Id": cid})

        # summary must reflect it
        r = s.get(f"{BASE_URL}/api/user/data-summary", headers={"X-Client-Id": cid})
        assert r.status_code == 200
        summary = r.json()
        assert summary["bookmarks"] >= 1 and summary["notes"] >= 1

        # delete
        r = s.delete(f"{BASE_URL}/api/user/data", headers={"X-Client-Id": cid})
        assert r.status_code == 200
        deleted = r.json()["deleted"]
        assert set(deleted.keys()) >= {"bookmarks", "highlights", "notes", "prayers", "chat_messages"}

        # verify empty
        r = s.get(f"{BASE_URL}/api/user/data-summary", headers={"X-Client-Id": cid})
        assert all(v == 0 for v in r.json().values())


# ---------- REGRESSION: existing endpoints still work ----------
class TestRegression:
    def test_books_ok(self, s):
        r = s.get(f"{BASE_URL}/api/bible/books")
        assert r.status_code == 200 and len(r.json()) > 0

    def test_search_ok(self, s):
        r = s.get(f"{BASE_URL}/api/bible/search", params={"q": "love", "lang": "en"})
        assert r.status_code == 200

    def test_audio_ok(self, s):
        r = s.get(f"{BASE_URL}/api/audio/john/3")
        assert r.status_code == 200 and "url" in r.json()

    def test_verse_detail_ok(self, s):
        r = s.get(f"{BASE_URL}/api/bible/verse/john/3/16")
        assert r.status_code == 200

    def test_cors_preflight(self, s):
        r = s.options(f"{BASE_URL}/api/bookmarks",
                      headers={"Origin": "https://hope-bible-study.preview.emergentagent.com",
                               "Access-Control-Request-Method": "GET",
                               "Access-Control-Request-Headers": "X-Client-Id,Content-Type"})
        assert r.status_code in (200, 204), r.text
        allow_hdrs = (r.headers.get("access-control-allow-headers") or "").lower()
        assert "x-client-id" in allow_hdrs
