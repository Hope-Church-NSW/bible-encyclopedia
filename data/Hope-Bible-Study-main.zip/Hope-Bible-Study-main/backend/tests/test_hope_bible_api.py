"""Backend tests for Hope Church Sydney Bible API."""
import os
import uuid
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://hope-bible-study.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="session")
def s():
    ses = requests.Session()
    ses.headers.update({"Content-Type": "application/json"})
    return ses


# ---------- Bible ----------
class TestBible:
    def test_root(self, s):
        r = s.get(f"{API}/")
        assert r.status_code == 200
        assert r.json().get("status") == "ok"

    def test_books(self, s):
        r = s.get(f"{API}/bible/books")
        assert r.status_code == 200
        data = r.json()
        ids = {b["id"] for b in data}
        for req in ["gen", "psa", "isa", "mat", "joh", "rom", "phi"]:
            assert req in ids, f"missing book {req}"
        # check schema
        b0 = data[0]
        for k in ["id", "name_en", "name_ar", "testament", "total_chapters"]:
            assert k in b0

    def test_john_3(self, s):
        r = s.get(f"{API}/bible/joh/3")
        assert r.status_code == 200
        d = r.json()
        assert d["book_id"] == "joh"
        assert d["chapter"] == 3
        assert len(d["verses"]) > 0
        v = d["verses"][0]
        assert v["ar"] and v["en"]

    def test_chapter_not_found(self, s):
        r = s.get(f"{API}/bible/joh/999")
        assert r.status_code == 404

    def test_book_not_found(self, s):
        r = s.get(f"{API}/bible/xxx/1")
        assert r.status_code == 404

    def test_verse_of_day(self, s):
        r = s.get(f"{API}/bible/verse-of-day")
        assert r.status_code == 200
        d = r.json()
        for k in ["book_id", "book_name_en", "book_name_ar", "chapter", "verse"]:
            assert k in d
        assert d["verse"] is not None
        assert "ar" in d["verse"] and "en" in d["verse"]

    def test_search_en(self, s):
        r = s.get(f"{API}/bible/search", params={"q": "love", "lang": "en"})
        assert r.status_code == 200
        results = r.json()["results"]
        assert len(results) > 0
        assert any("love" in x["en"].lower() for x in results)

    def test_search_short_query(self, s):
        r = s.get(f"{API}/bible/search", params={"q": "a"})
        assert r.status_code == 200
        assert r.json()["results"] == []


# ---------- Bookmarks ----------
class TestBookmarks:
    def test_crud(self, s):
        payload = {"book_id": "joh", "chapter": 3, "verse": 16, "label": "TEST_bm"}
        r = s.post(f"{API}/bookmarks", json=payload)
        assert r.status_code == 200
        bm = r.json()
        assert bm["book_id"] == "joh" and bm["verse"] == 16
        bm_id = bm["id"]

        r = s.get(f"{API}/bookmarks")
        assert r.status_code == 200
        assert any(x["id"] == bm_id for x in r.json())

        r = s.delete(f"{API}/bookmarks/{bm_id}")
        assert r.status_code == 200
        r = s.get(f"{API}/bookmarks")
        assert not any(x["id"] == bm_id for x in r.json())


# ---------- Highlights ----------
class TestHighlights:
    def test_crud(self, s):
        payload = {"book_id": "joh", "chapter": 3, "verse": 16, "color": "gold"}
        r = s.post(f"{API}/highlights", json=payload)
        assert r.status_code == 200
        h = r.json()
        hid = h["id"]
        r = s.get(f"{API}/highlights")
        assert any(x["id"] == hid for x in r.json())
        s.delete(f"{API}/highlights/{hid}")
        r = s.get(f"{API}/highlights")
        assert not any(x["id"] == hid for x in r.json())


# ---------- Notes ----------
class TestNotes:
    def test_crud(self, s):
        payload = {"book_id": "joh", "chapter": 3, "verse": 16, "text": "TEST_note"}
        r = s.post(f"{API}/notes", json=payload)
        assert r.status_code == 200
        n = r.json()
        nid = n["id"]
        assert n["text"] == "TEST_note"
        r = s.get(f"{API}/notes")
        assert any(x["id"] == nid for x in r.json())
        s.delete(f"{API}/notes/{nid}")
        r = s.get(f"{API}/notes")
        assert not any(x["id"] == nid for x in r.json())


# ---------- Prayers ----------
class TestPrayers:
    def test_crud_and_toggle(self, s):
        payload = {"title": "TEST_prayer", "body": "Pray for testing"}
        r = s.post(f"{API}/prayers", json=payload)
        assert r.status_code == 200
        p = r.json()
        pid = p["id"]
        assert p["answered"] is False

        r = s.post(f"{API}/prayers/{pid}/toggle")
        assert r.status_code == 200
        r = s.get(f"{API}/prayers")
        toggled = next(x for x in r.json() if x["id"] == pid)
        assert toggled["answered"] is True

        r = s.delete(f"{API}/prayers/{pid}")
        assert r.status_code == 200

    def test_toggle_not_found(self, s):
        r = s.post(f"{API}/prayers/nonexistent-id/toggle")
        assert r.status_code == 404


# ---------- Reading Plans ----------
class TestReadingPlans:
    def test_get(self, s):
        r = s.get(f"{API}/reading-plans")
        assert r.status_code == 200
        d = r.json()
        assert "plans" in d
        assert isinstance(d["plans"], list) and len(d["plans"]) > 0


# ---------- Church ----------
class TestChurch:
    def test_get_church(self, s):
        r = s.get(f"{API}/church")
        assert r.status_code == 200
        d = r.json()
        # Verify expected church data fields
        keys = " ".join(d.keys()).lower()
        assert any(k in keys for k in ["vision", "mission", "ministries", "sermons", "social"]) or \
               any(k in d for k in ["vision", "mission", "ministries", "sermons", "socials", "social"])


# ---------- AI ----------
class TestAI:
    def test_chat_and_history(self, s):
        sid = f"TEST_{uuid.uuid4()}"
        payload = {"session_id": sid, "message": "In one sentence, what does John 3:16 teach?", "language": "en"}
        t0 = time.time()
        r = s.post(f"{API}/ai/chat", json=payload, timeout=60)
        elapsed = time.time() - t0
        assert r.status_code == 200, f"AI chat failed: {r.status_code} {r.text[:300]}"
        d = r.json()
        assert d["session_id"] == sid
        assert isinstance(d["reply"], str) and len(d["reply"]) > 10
        print(f"AI reply in {elapsed:.1f}s, length={len(d['reply'])}")

        r = s.get(f"{API}/ai/history/{sid}")
        assert r.status_code == 200
        msgs = r.json()["messages"]
        assert len(msgs) >= 2
        roles = [m["role"] for m in msgs]
        assert "user" in roles and "assistant" in roles

        # cleanup
        s.delete(f"{API}/ai/history/{sid}")
