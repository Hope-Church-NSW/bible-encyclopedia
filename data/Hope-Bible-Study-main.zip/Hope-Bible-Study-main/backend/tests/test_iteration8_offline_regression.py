"""Iteration 8: Verify backend Bible-read endpoints still respond (regression).

The frontend now reads Bible content from bundled JSON. Backend endpoints
must continue to exist as fallback/admin per agreement.
"""
import os
import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/")


@pytest.fixture(scope="module")
def s():
    return requests.Session()


# ---- Bible read endpoints must still exist ----
class TestBibleReadEndpointsAlive:
    def test_books(self, s):
        r = s.get(f"{BASE_URL}/api/bible/books", timeout=15)
        assert r.status_code == 200
        data = r.json()
        # Support either {books: [...]} or [...]
        books = data.get("books", data) if isinstance(data, dict) else data
        assert len(books) == 66

    def test_chapter(self, s):
        r = s.get(f"{BASE_URL}/api/bible/joh/3", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert d["book_id"] == "joh"
        assert d["chapter"] == 3
        assert any(v["number"] == 16 for v in d["verses"])

    def test_verse_detail(self, s):
        r = s.get(f"{BASE_URL}/api/bible/verse/joh/3/16", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert d["verse"]["number"] == 16
        assert isinstance(d.get("cross_refs", []), list)

    def test_search_en(self, s):
        r = s.get(f"{BASE_URL}/api/bible/search", params={"q": "grace", "lang": "en"}, timeout=20)
        assert r.status_code == 200
        assert "results" in r.json()

    def test_verse_of_day(self, s):
        r = s.get(f"{BASE_URL}/api/bible/verse-of-day", timeout=15)
        assert r.status_code == 200
        assert "verse" in r.json()

    def test_places(self, s):
        r = s.get(f"{BASE_URL}/api/bible/places", timeout=15)
        assert r.status_code == 200

    def test_church(self, s):
        r = s.get(f"{BASE_URL}/api/church", timeout=15)
        assert r.status_code == 200

    def test_reading_plans(self, s):
        r = s.get(f"{BASE_URL}/api/reading-plans", timeout=15)
        assert r.status_code == 200
