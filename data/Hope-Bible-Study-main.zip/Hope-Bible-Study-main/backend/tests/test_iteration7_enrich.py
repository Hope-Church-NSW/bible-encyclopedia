"""
Iteration 7 — Verify AI verse-enrichment endpoint + regression on curated verses.

Endpoint under test:
  POST /api/bible/verse/{book_id}/{chapter}/{verse}/enrich

Test cases (per review request):
  1. 2 Chronicles 19:1 (OT, non-curated) → Hebrew words + >=3 cross-refs
  2. Second identical call returns cached result quickly
  3. Missing X-Client-Id → 401
  4. Revelation 22:1 (NT) → Greek words, G#### Strong's
  5. Proverbs 3:5 (OT) → Hebrew words, H#### Strong's
  6. Regression — verse-detail on John 3:16 still returns curated cross_refs + words
  7. Regression — verse-detail on Genesis 1:1 still returns curated Hebrew words (bereshit/bara/Elohim)
"""
import os
import time
import uuid
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL") or os.environ.get("EXPO_BACKEND_URL")
assert BASE_URL, "EXPO_PUBLIC_BACKEND_URL must be set"
BASE_URL = BASE_URL.rstrip("/")


@pytest.fixture(scope="module")
def client_id():
    return f"TEST_iter7_{uuid.uuid4().hex[:12]}"


@pytest.fixture()
def api(client_id):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "X-Client-Id": client_id})
    return s


CANONICAL_BOOKS = set(
    "gen exo lev num deu jos jdg rut 1sa 2sa 1ki 2ki 1ch 2ch ezr neh est job psa pro ecc sng "
    "isa jer lam ezk dan hos jol amo oba jon mic nam hab zep hag zec mal "
    "mat mrk luk joh act rom 1co 2co gal eph phi col 1th 2th 1ti 2ti tit phm heb jas "
    "1pe 2pe 1jn 2jn 3jn jud rev".split()
)


# ---------------- Enrich endpoint ----------------

class TestEnrichAuth:
    def test_missing_client_id_returns_401(self):
        r = requests.post(f"{BASE_URL}/api/bible/verse/2ch/19/1/enrich",
                          headers={"Content-Type": "application/json"})
        assert r.status_code == 401, f"expected 401, got {r.status_code}: {r.text[:200]}"


class TestEnrichOldTestament:
    def test_2ch_19_1_returns_hebrew_words_and_cross_refs(self, api):
        r = api.post(f"{BASE_URL}/api/bible/verse/2ch/19/1/enrich", timeout=60)
        assert r.status_code == 200, f"status={r.status_code} body={r.text[:400]}"
        data = r.json()
        assert data["book_id"] == "2ch"
        assert data["chapter"] == 19
        assert data["verse"] == 1
        assert isinstance(data["cross_refs"], list)
        assert len(data["cross_refs"]) >= 3, f"expected >=3 cross_refs, got {len(data['cross_refs'])}"
        for ref in data["cross_refs"]:
            assert ref["book_id"] in CANONICAL_BOOKS, f"non-canonical book_id: {ref['book_id']}"
            assert isinstance(ref["chapter"], int)
            assert isinstance(ref["verse"], int)
        assert isinstance(data["words"], list)
        assert len(data["words"]) >= 2, f"expected >=2 words, got {len(data['words'])}"
        for w in data["words"]:
            assert w.get("lang") == "hebrew", f"OT word must be hebrew, got {w.get('lang')}"
            strong = str(w.get("strong", ""))
            assert strong.startswith("H"), f"Hebrew Strong's must start with H, got {strong}"

    def test_second_call_is_cached_and_fast(self, api):
        t0 = time.time()
        r = api.post(f"{BASE_URL}/api/bible/verse/2ch/19/1/enrich", timeout=30)
        elapsed = time.time() - t0
        assert r.status_code == 200
        # Cached response should be < 3s (first LLM call takes 10-15s)
        assert elapsed < 3.0, f"cached call took {elapsed:.1f}s — likely not cached"
        data = r.json()
        assert len(data["cross_refs"]) >= 3

    def test_pro_3_5_hebrew_words(self, api):
        r = api.post(f"{BASE_URL}/api/bible/verse/pro/3/5/enrich", timeout=60)
        assert r.status_code == 200, f"status={r.status_code} body={r.text[:400]}"
        data = r.json()
        assert data["book_id"] == "pro"
        for w in data["words"]:
            assert w.get("lang") == "hebrew"
            assert str(w.get("strong", "")).startswith("H")
        for ref in data["cross_refs"]:
            assert ref["book_id"] in CANONICAL_BOOKS


class TestEnrichNewTestament:
    def test_rev_22_1_greek_words(self, api):
        r = api.post(f"{BASE_URL}/api/bible/verse/rev/22/1/enrich", timeout=60)
        assert r.status_code == 200, f"status={r.status_code} body={r.text[:400]}"
        data = r.json()
        assert data["book_id"] == "rev"
        assert len(data["cross_refs"]) >= 3
        assert len(data["words"]) >= 2
        for w in data["words"]:
            assert w.get("lang") == "greek", f"NT word must be greek, got {w.get('lang')}"
            assert str(w.get("strong", "")).startswith("G")
        for ref in data["cross_refs"]:
            assert ref["book_id"] in CANONICAL_BOOKS


# ---------------- Regression — curated verse-detail unaffected ----------------

class TestVerseDetailCuratedRegression:
    def test_john_3_16_curated_still_works(self, api):
        r = api.get(f"{BASE_URL}/api/bible/verse/joh/3/16")
        assert r.status_code == 200
        d = r.json()
        assert isinstance(d.get("cross_refs"), list) and len(d["cross_refs"]) >= 1, \
            "John 3:16 must ship curated cross-refs (no AI call)"
        assert isinstance(d.get("words"), list) and len(d["words"]) >= 1, \
            "John 3:16 must ship curated words"
        # Places for John 3:16 include Jerusalem/Golgotha per iteration 6 report
        assert isinstance(d.get("places"), list)

    def test_gen_1_1_curated_hebrew_words(self, api):
        r = api.get(f"{BASE_URL}/api/bible/verse/gen/1/1")
        assert r.status_code == 200
        d = r.json()
        words = d.get("words", [])
        assert len(words) >= 1
        translits = " ".join(str(w.get("translit", "")).lower() for w in words)
        # At least one of the classic Gen 1:1 originals should appear
        assert any(k in translits for k in ("bereshit", "bara", "elohim")), \
            f"expected curated Gen 1:1 words, got translits={translits}"

    def test_psa_23_1_curated(self, api):
        r = api.get(f"{BASE_URL}/api/bible/verse/psa/23/1")
        assert r.status_code == 200
        d = r.json()
        assert isinstance(d.get("cross_refs"), list)
        assert isinstance(d.get("words"), list)
