# Hope Church Sydney — AI Bible Study App (PRD)

## Vision
Official Bible app of **Hope Church Sydney (كنيسة رجاء الأمم – سيدني)**. A premium, elegant, AI-powered Bible study platform combining the best of Logos, YouVersion, BibleHub, and Blue Letter Bible with a modern AI assistant.

## Branding
- Colors: Royal Blue `#0033A0`, Deep Red `#9B111E`, Gold `#D4AF37`, White
- Logo: dove + cross + globe + gold rays (used in splash, home, church tab, footer, icons)
- Bilingual: English + Arabic (Van Dyke)

## MVP Feature Set (delivered)
1. **Splash screen** — animated brand logo with "Powered by Hope Church Sydney"
2. **Home** — Verse of the Day, quick actions, Reading Plans carousel, latest sermon, AI CTA
3. **Bible Reader** — Book list, chapter picker, parallel/EN/AR modes, verse tap → Highlight / Bookmark / Note / Ask AI
4. **AI Assistant** (Claude Sonnet 4.5 via `EMERGENT_LLM_KEY`) — verse explanations, word studies, sermon prep, suggested prompts, session persistence
5. **Scripture Search** — classic keyword search (EN + AR)
6. **Study** — bookmarks, highlights, notes, prayer journal
7. **Church** — vision/mission, ministries, weekly meetings, sermons, social links (X, Facebook x3, TikTok)

## Backend
FastAPI + MongoDB. Endpoints under `/api`:
- `GET /bible/books`, `GET /bible/{book_id}/{chapter}`, `GET /bible/verse-of-day`, `GET /bible/search`
- CRUD: `/bookmarks`, `/highlights`, `/notes`, `/prayers`
- `GET /reading-plans`, `GET /church`
- `POST /ai/chat`, `GET/DELETE /ai/history/{session_id}`

## Bible Data
Curated seed of key chapters (Genesis 1, Psalms 23 & 91, Isaiah 53, Matthew 5 & 6, John 1/3/14, Romans 8, Philippians 4). Extensible via seed file or future Admin Dashboard.

## Deferred / Future
- Hebrew/Greek morphology + Strong's word study drawer
- Interactive Biblical maps + timeline
- Audio Bible with narrator selection
- Commentary library (Matthew Henry, Barnes, etc.)
- User accounts + sync (Emergent Google Auth)
- Admin dashboard for translations, sermons, socials, branding
- Full Bible import (all books/chapters)

## Business Enhancement
"Give / Support Hope Church" CTA in Church tab (future) → in-app donation via Stripe.
